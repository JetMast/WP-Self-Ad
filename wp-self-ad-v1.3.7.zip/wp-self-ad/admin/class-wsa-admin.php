<?php
/**
 * 后台管理：菜单、各设置页与表单处理
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class WSA_Admin {

    public static function init() {
        add_action( 'admin_menu', [ __CLASS__, 'add_menu' ] );
        add_action( 'admin_init', [ __CLASS__, 'register_settings' ] );
        // 「广告管理」页要用到媒体库选图和确认弹窗，只在那一页加载资源
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_assets' ] );
        // 广告位保存走 admin-post.php：保存完立刻跳转，避免用户刷新页面时把设置重复提交一遍
        add_action( 'admin_post_wsa_save_slots', [ __CLASS__, 'handle_save_slots' ] );
        // 广告的上架 / 下架 / 删除：都是单次动作，也用 admin-post.php，带 nonce 防伪造
        add_action( 'admin_post_wsa_toggle_ad', [ __CLASS__, 'handle_toggle_ad' ] );
        add_action( 'admin_post_wsa_delete_ad', [ __CLASS__, 'handle_delete_ad' ] );
        // 易支付接口自检：同样走 admin-post.php，结果用 transient 带回页面显示
        add_action( 'admin_post_wsa_probe_epay', [ __CLASS__, 'handle_probe_epay' ] );
        // 手动刷新数据库结构
        add_action( 'admin_post_wsa_repair_db', [ __CLASS__, 'handle_repair_db' ] );
        // 清除“最近一次数据库报错”记录（问题解决后把红框去掉）
        add_action( 'admin_post_wsa_clear_db_error', [ __CLASS__, 'handle_clear_db_error' ] );
    }

    public static function add_menu() {
        add_menu_page( '自助广告', '自助广告', 'manage_options', 'wsa-dashboard',
            [ __CLASS__, 'page_dashboard' ], 'dashicons-megaphone', 30 );
        add_submenu_page( 'wsa-dashboard', '广告位设置', '广告位设置',
            'manage_options', 'wsa-slots', [ __CLASS__, 'page_slots' ] );
        add_submenu_page( 'wsa-dashboard', '广告管理', '广告管理',
            'manage_options', 'wsa-ads', [ __CLASS__, 'page_ads' ] );
        add_submenu_page( 'wsa-dashboard', '订单管理', '订单管理',
            'manage_options', 'wsa-orders', [ __CLASS__, 'page_orders' ] );
        add_submenu_page( 'wsa-dashboard', '支付设置', '支付设置',
            'manage_options', 'wsa-payment', [ __CLASS__, 'page_payment' ] );
        // 版权与联系方式。渲染放在 WSA_About 里，避免这里越来越长
        add_submenu_page( 'wsa-dashboard', '关于插件', '关于插件',
            'manage_options', 'wsa-about', [ 'WSA_About', 'render_page' ] );
    }

    /** 「广告管理」页需要 WP 自带的媒体库（选图片）和一小段交互脚本 */
    public static function enqueue_admin_assets() {
        $page = isset( $_GET['page'] ) ? sanitize_key( $_GET['page'] ) : '';
        if ( $page !== 'wsa-ads' ) return;

        wp_enqueue_media();
        wp_enqueue_script(
            'wsa-admin',
            WSA_PLUGIN_URL . 'assets/js/wsa-admin.js',
            [ 'jquery' ],
            WSA_VERSION,
            true
        );
        wp_localize_script( 'wsa-admin', 'wsaAdmin', [
            'pickTitle'  => '选择广告图片',
            'pickButton' => '使用这张图片',
        ] );
    }

    public static function register_settings() {
        register_setting( 'wsa_alipay_group', 'wsa_alipay_config', [
            'sanitize_callback' => [ __CLASS__, 'sanitize_alipay' ],
        ]);
        register_setting( 'wsa_epay_group', 'wsa_epay_config', [
            'sanitize_callback' => [ __CLASS__, 'sanitize_epay' ],
        ]);
    }

    public static function sanitize_alipay( $input ) {
        $input = (array) $input;
        return [
            'enabled'           => empty( $input['enabled'] ) ? 0 : 1,
            'app_id'            => sanitize_text_field( $input['app_id'] ?? '' ),
            'private_key'       => trim( $input['private_key'] ?? '' ),
            'alipay_public_key' => trim( $input['alipay_public_key'] ?? '' ),
        ];
    }

    public static function sanitize_epay( $input ) {
        $input = (array) $input;

        // 该商户开通了哪几种付款方式；一个都没勾时保存为空数组，此时易支付通道视为不可用
        $types = isset( $input['types'] ) ? (array) $input['types'] : [];
        $types = array_values( array_unique( array_filter( array_map( 'sanitize_key', $types ) ) ) );

        // 接口模式只允许三个值，写错就退回“自动”
        $mode = isset( $input['mode'] ) ? sanitize_key( $input['mode'] ) : 'auto';
        if ( ! in_array( $mode, [ 'auto', 'api', 'page' ], true ) ) {
            $mode = 'auto';
        }

        // 通道 ID 的参数名只有 tdid / cid 两种写法
        $param = isset( $input['tdid_param'] ) ? sanitize_key( $input['tdid_param'] ) : 'tdid';
        $param = $param === 'cid' ? 'cid' : 'tdid';

        return [
            'enabled'    => empty( $input['enabled'] ) ? 0 : 1,
            'api_url'    => esc_url_raw( $input['api_url'] ?? '' ),
            'pid'        => sanitize_text_field( $input['pid'] ?? '' ),
            'key'        => sanitize_text_field( $input['key'] ?? '' ),
            'tdid'       => sanitize_text_field( $input['tdid'] ?? '' ),
            'tdid_param' => $param,
            'mode'       => $mode,
            'types'      => $types,
        ];
    }

    /* ---- 易支付接口自检（由 admin-post.php 调用） ---- */
    public static function handle_probe_epay() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( '权限不足' );
        }
        check_admin_referer( 'wsa_probe_epay', 'wsa_probe_nonce' );

        $type = sanitize_key( $_POST['type'] ?? 'all' );
        // 'all' 表示把本商户开通的付款方式逐个都测一遍
        $result = WSA_Payment::probe_epay( $type === 'all' ? '' : $type );

        // 结果存进 transient，跳回支付设置页后再读出来显示（避免用户刷新时重复请求服务商）
        set_transient( 'wsa_epay_probe_' . get_current_user_id(), $result, 5 * MINUTE_IN_SECONDS );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'wsa-payment', 'wsa_probed' => 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /* ---- 手动刷新数据库结构（由 admin-post.php 调用） ---- */
    public static function handle_repair_db() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( '权限不足' );
        }
        check_admin_referer( 'wsa_repair_db', 'wsa_repair_nonce' );

        // 只做加法：补缺失的表、字段、索引，以及把取值范围过小的字段放大。
        // 不会删除或改写任何已有数据。
        $report = WSA_DB::sync_structure();
        WSA_DB::seed_default_slots();

        // 顺手刷新回调地址，避免补齐结构后回调仍然 404
        if ( function_exists( 'wsa_register_rewrite_rules' ) ) {
            wsa_register_rewrite_rules();
        }
        flush_rewrite_rules();

        // 只有真的补齐了才把结构版本写进去；没补齐就保留原值，稍后还会自动重试
        if ( WSA_DB::structure_is_ok() ) {
            update_option( 'wsa_db_version', WSA_DB_VERSION );
            // 结构既然已经好了，之前那条数据库报错就不必继续吓人了
            delete_option( 'wsa_last_db_error' );
        }

        WSA_Payment::log( '管理员手动刷新数据库结构', $report );

        // 把“这次到底补了什么”带回页面显示 —— 只回一句“已刷新”对排查毫无帮助
        set_transient( 'wsa_repair_report_' . get_current_user_id(), $report, 10 * MINUTE_IN_SECONDS );

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'wsa-payment', 'wsa_repaired' => 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /* ---- 清除“最近一次数据库报错”记录 ---- */
    public static function handle_clear_db_error() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( '权限不足' );
        }
        check_admin_referer( 'wsa_clear_db_error', 'wsa_clear_nonce' );

        delete_option( 'wsa_last_db_error' );

        wp_safe_redirect( add_query_arg( [ 'page' => 'wsa-payment' ], admin_url( 'admin.php' ) ) );
        exit;
    }

    /** 跳到「广告管理」页，并带上一句提示（用查询参数传递，刷新后提示消失，不会重复） */
    private static function redirect_ads( $args = [] ) {
        wp_safe_redirect( add_query_arg(
            array_merge( [ 'page' => 'wsa-ads' ], $args ),
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /** 把失败原因暂存起来，跳转后显示一次（跳转会丢掉 POST 内容，所以用 transient 带过去） */
    private static function stash_ad_error( $message ) {
        set_transient( 'wsa_ad_error_' . get_current_user_id(), (string) $message, 5 * MINUTE_IN_SECONDS );
    }

    /* ---- 广告上架 / 下架（由列表里的按钮触发） ---- */
    public static function handle_toggle_ad() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( '权限不足' );
        }
        check_admin_referer( 'wsa_toggle_ad' );

        $id = isset( $_GET['ad'] ) ? absint( $_GET['ad'] ) : 0;
        $to = isset( $_GET['to'] ) && $_GET['to'] === 'active' ? 'active' : 'paused';

        $result = WSA_Ad_Manager::set_status( $id, $to );

        if ( is_wp_error( $result ) ) {
            self::stash_ad_error( $result->get_error_message() );
            self::redirect_ads();
        }

        $args = [ 'wsa_ad_toggled' => $to ];
        if ( ! empty( $result['renewed'] ) ) {
            $args['wsa_ad_renewed'] = (int) $result['days'];
        }
        self::redirect_ads( $args );
    }

    /* ---- 删除广告（由列表里的按钮触发） ---- */
    public static function handle_delete_ad() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( '权限不足' );
        }
        check_admin_referer( 'wsa_delete_ad' );

        $id     = isset( $_GET['ad'] ) ? absint( $_GET['ad'] ) : 0;
        $result = WSA_Ad_Manager::delete( $id );

        if ( is_wp_error( $result ) ) {
            self::stash_ad_error( $result->get_error_message() );
            self::redirect_ads();
        }

        self::redirect_ads( [ 'wsa_ad_deleted' => 1 ] );
    }

    /** 把一组名字渲染成 <code>a</code>、<code>b</code> 的样子 */
    private static function code_list( $items ) {
        return '<code>' . implode( '</code>、<code>', array_map( 'esc_html', (array) $items ) ) . '</code>';
    }

    /** 把「本次到底补了什么」渲染成人话，给站长看 */
    private static function repair_report_html( $report ) {
        $lines = [];

        if ( ! empty( $report['created'] ) ) {
            $lines[] = '新建了表：' . self::code_list( $report['created'] );
        }
        if ( ! empty( $report['columns'] ) ) {
            $lines[] = '补上了缺失的字段：' . self::code_list( $report['columns'] );
        }
        if ( ! empty( $report['widened'] ) ) {
            $lines[] = '放大了字段的取值范围：' . self::code_list( $report['widened'] );
        }
        if ( ! empty( $report['keys'] ) ) {
            $lines[] = '补上了索引（只影响查询速度）：' . self::code_list( $report['keys'] );
        }
        foreach ( (array) ( $report['errors'] ?? [] ) as $error ) {
            $lines[] = '<span style="color:#d63638;">失败：' . esc_html( $error ) . '</span>';
        }

        if ( ! $lines ) {
            return '<p>本次无需改动，数据库结构本来就是完整的。</p>';
        }

        $html = '<ul style="margin:6px 0 6px 18px;list-style:disc;">';
        foreach ( $lines as $line ) {
            $html .= '<li>' . $line . '</li>'; // 每一项的内容都已在上方转义
        }
        return $html . '</ul>';
    }

    /** 订单状态的中文说明 */
    private static function status_label( $status ) {
        $map = [
            'pending' => '待支付',
            'paid'    => '已支付',
            'expired' => '已过期',
            'closed'  => '已关闭',
            'review'  => '待人工核对',
        ];
        return isset( $map[ $status ] ) ? $map[ $status ] : $status;
    }

    /* ---- 保存广告位设置（由 admin-post.php 调用） ---- */
    public static function handle_save_slots() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( '权限不足' );
        }
        check_admin_referer( 'wsa_save_slots', 'wsa_slots_nonce' );

        global $wpdb;
        $table = WSA_DB::table( 'ad_slots' );
        $slots = isset( $_POST['slots'] ) ? wp_unslash( $_POST['slots'] ) : [];

        foreach ( (array) $slots as $id => $data ) {
            $id = absint( $id );
            if ( ! $id ) continue;

            $durations = array_filter( array_map( 'absint', explode( ',', $data['durations'] ?? '' ) ) );
            // 兜底：不允许把“可购买天数”清空，否则该广告位的下拉框会变成空的，谁也买不了
            if ( empty( $durations ) ) {
                $durations = [ 7, 30, 90 ];
            }

            $wpdb->update( $table, [
                'is_enabled'       => empty( $data['is_enabled'] ) ? 0 : 1,
                'price'            => round( floatval( $data['price'] ?? 0 ), 2 ),
                'duration_options' => wp_json_encode( array_values( $durations ) ),
            ], [ 'id' => $id ], [ '%d', '%f', '%s' ], [ '%d' ] );
        }

        wp_safe_redirect( add_query_arg(
            [ 'page' => 'wsa-slots', 'wsa_saved' => 1 ],
            admin_url( 'admin.php' )
        ) );
        exit;
    }

    /* ---- 仪表盘 ---- */
    public static function page_dashboard() {
        global $wpdb;
        $orders_table = WSA_DB::table( 'orders' );

        $order_count  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$orders_table} WHERE status='paid'" );
        $pending_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$orders_table} WHERE status='pending'" );
        $review_count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$orders_table} WHERE status='review'" );
        $active_ads   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . WSA_DB::table( 'user_ads' ) . " WHERE status='active'" );
        $total_income = (float) $wpdb->get_var( "SELECT COALESCE(SUM(amount),0) FROM {$orders_table} WHERE status='paid'" );
        ?>
        <div class="wrap">
            <h1>自助广告系统 - 仪表盘</h1>
            <?php if ( ! WSA_DB::structure_is_ok() ) : ?>
                <div class="notice notice-error">
                    <p><strong>数据库结构不完整</strong>（缺少表或字段），这会让下单等功能直接失败。
                        请到 <a href="<?php echo esc_url( admin_url( 'admin.php?page=wsa-payment' ) ); ?>">支付设置</a>
                        页面底部的「数据库修复」点一次「刷新数据库结构」。</p>
                </div>
            <?php endif; ?>
            <?php $wsa_db_error = get_option( 'wsa_last_db_error' ); ?>
            <?php if ( is_array( $wsa_db_error ) && ! empty( $wsa_db_error['error'] ) ) : ?>
                <div class="notice notice-error">
                    <p>
                        <strong>最近一次数据库写入失败</strong>
                        <span class="description">（<?php echo esc_html( $wsa_db_error['time'] ?? '' ); ?>
                            <?php if ( ! empty( $wsa_db_error['order_no'] ) ) : ?>
                                ，订单 <?php echo esc_html( $wsa_db_error['order_no'] ); ?>
                            <?php endif; ?>）
                        </span>
                    </p>
                    <p>数据库原话：<code style="word-break:break-all;"><?php echo esc_html( $wsa_db_error['error'] ); ?></code></p>
                    <p class="description" style="max-width:900px;">
                        这句话是数据库自己说的，基本就是「订单创建失败」的真凶。最常见的两种：
                        <code>Table '...wp_wsa_orders' doesn't exist</code>（订单表根本没建出来）、
                        <code>Unknown column 'payment_channel' in 'field list'</code>（订单表少了一个字段）。
                        两者都可以用 <a href="<?php echo esc_url( admin_url( 'admin.php?page=wsa-payment' ) ); ?>">支付设置</a>
                        页底部的「刷新数据库结构」修好。
                    </p>
                </div>
            <?php endif; ?>
            <?php if ( $review_count > 0 ) : ?>
                <div class="notice notice-error">
                    <p>有 <strong><?php echo $review_count; ?></strong> 笔订单需要人工核对（可能是支付金额不符或位置冲突），请到
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wsa-orders' ) ); ?>">订单管理</a> 查看并处理。</p>
                </div>
            <?php endif; ?>
            <?php if ( ! WSA_Payment::available_methods() ) : ?>
                <div class="notice notice-warning">
                    <p>当前<strong>没有任何可用的支付方式</strong>，用户将无法下单。请到
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wsa-payment' ) ); ?>">支付设置</a> 启用一个通道并填写完整参数。</p>
                </div>
            <?php endif; ?>
            <div style="display:flex;gap:20px;margin-top:20px;flex-wrap:wrap;">
                <div class="card" style="flex:1;min-width:160px;padding:20px;">
                    <h3>已支付订单</h3>
                    <p style="font-size:32px;font-weight:bold;"><?php echo $order_count; ?></p>
                </div>
                <div class="card" style="flex:1;min-width:160px;padding:20px;">
                    <h3>在线广告</h3>
                    <p style="font-size:32px;font-weight:bold;"><?php echo $active_ads; ?></p>
                </div>
                <div class="card" style="flex:1;min-width:160px;padding:20px;">
                    <h3>总收入</h3>
                    <p style="font-size:32px;font-weight:bold;">¥<?php echo number_format( $total_income, 2 ); ?></p>
                </div>
                <div class="card" style="flex:1;min-width:160px;padding:20px;">
                    <h3>待支付</h3>
                    <p style="font-size:32px;font-weight:bold;"><?php echo $pending_count; ?></p>
                </div>
            </div>

            <p class="description" style="margin-top:18px;">
                WP Self Ad v<?php echo esc_html( WSA_VERSION ); ?> ·
                作者 <?php echo esc_html( WSA_About::signature() ); ?> ·
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=wsa-about' ) ); ?>">版权与联系方式</a>
            </p>
        </div>
        <?php
    }

    /* ---- 广告位设置 ---- */
    public static function page_slots() {
        if ( isset( $_GET['wsa_saved'] ) ) {
            echo '<div class="notice notice-success is-dismissible"><p>广告位设置已保存</p></div>';
        }

        $slots = WSA_Ad_Slots::get_all();
        ?>
        <div class="wrap">
            <h1>广告位设置</h1>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="wsa_save_slots" />
                <?php wp_nonce_field( 'wsa_save_slots', 'wsa_slots_nonce' ); ?>
                <table class="widefat striped">
                    <thead>
                        <tr>
                            <th>广告位</th>
                            <th>类型</th>
                            <th>启用</th>
                            <th>价格(元/月)</th>
                            <th>可购买天数(逗号分隔)</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ( $slots as $s ) :
                        $durations = implode( ',', WSA_Ad_Slots::duration_options( $s ) );
                    ?>
                        <tr>
                            <td><strong><?php echo esc_html( $s->slot_name ); ?></strong></td>
                            <td><?php echo $s->slot_type === 'text' ? '文字' : '图片'; ?></td>
                            <td>
                                <input type="checkbox" name="slots[<?php echo (int) $s->id; ?>][is_enabled]"
                                       value="1" <?php checked( $s->is_enabled, 1 ); ?> />
                            </td>
                            <td>
                                <input type="number" step="0.01" min="0"
                                       name="slots[<?php echo (int) $s->id; ?>][price]"
                                       value="<?php echo esc_attr( $s->price ); ?>" style="width:100px;" />
                            </td>
                            <td>
                                <input type="text" name="slots[<?php echo (int) $s->id; ?>][durations]"
                                       value="<?php echo esc_attr( $durations ); ?>" style="width:200px;" />
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <?php submit_button( '保存设置' ); ?>
            </form>
            <h2 style="margin-top:30px;">短代码调用</h2>
            <p>在文章/页面编辑器中插入以下短代码即可显示对应广告位：</p>
            <table class="widefat" style="max-width:600px;">
                <thead><tr><th>广告位</th><th>短代码</th></tr></thead>
                <tbody>
                    <?php foreach ( $slots as $s ) : ?>
                        <tr>
                            <td><?php echo esc_html( $s->slot_name ); ?></td>
                            <td><code>[wsa_ad slot="<?php echo esc_html( $s->slot_key ); ?>"]</code></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * 广告管理：列表 + 新增 / 编辑。
     *
     * 「新增 / 修改」的表单在本页直接提交（不走 admin-post.php），
     * 这样万一校验没过，可以把站长已经填好的内容原样回显，不用重填一遍。
     * 真正写入成功后才跳转，避免刷新页面造成重复提交。
     */
    public static function page_ads() {
        $form_error  = '';
        $form_values = [];

        if ( 'POST' === strtoupper( (string) ( $_SERVER['REQUEST_METHOD'] ?? '' ) )
            && isset( $_POST['wsa_ad_form'] ) ) {
            check_admin_referer( 'wsa_save_ad', 'wsa_ad_nonce' );
            if ( ! current_user_can( 'manage_options' ) ) {
                wp_die( '权限不足' );
            }

            $raw         = wp_unslash( $_POST );
            $form_values = $raw;
            $saved       = WSA_Ad_Manager::save( self::ad_input_from_post( $raw ) );

            if ( is_wp_error( $saved ) ) {
                $form_error = $saved->get_error_message();
            } else {
                self::redirect_ads( [ 'wsa_ad_saved' => 1, 'ad' => $saved ] );
            }
        }

        // 带 wsa_action=edit 时显示表单（新增时没有 ad 参数，表示新建）
        $action = isset( $_GET['wsa_action'] ) ? sanitize_key( $_GET['wsa_action'] ) : '';
        if ( $action === 'edit' ) {
            self::render_ad_form(
                isset( $_GET['ad'] ) ? absint( $_GET['ad'] ) : 0,
                $form_error,
                $form_values
            );
            return;
        }

        $views = WSA_Ad_Manager::views();
        $view  = isset( $_GET['view'] ) ? sanitize_key( $_GET['view'] ) : '';
        if ( ! array_key_exists( $view, $views ) ) {
            $view = '';
        }

        $ads    = WSA_Ad_Manager::query( [ 'view' => $view ] );
        $counts = WSA_Ad_Manager::counts();

        $list_url    = add_query_arg( [ 'page' => 'wsa-ads' ], admin_url( 'admin.php' ) );
        $add_url     = add_query_arg( [ 'page' => 'wsa-ads', 'wsa_action' => 'edit' ], admin_url( 'admin.php' ) );
        $db_error    = get_option( 'wsa_last_db_error' );
        ?>
        <div class="wrap">
            <h1>广告管理</h1>
            <p class="description" style="max-width:900px;">
                这里列出所有正在展示和已经结束的广告。你可以
                <strong>新增站长自己的广告</strong>、<strong>随时把任意一条广告下架或重新上架</strong>，
                也可以修正广告内容。下架只是不再展示，广告记录仍然保留，可随时上架。
            </p>

            <?php if ( is_array( $db_error ) && ! empty( $db_error['error'] ) ) : ?>
                <div class="notice notice-error">
                    <p><strong>最近一次数据库写入失败</strong>：<code style="word-break:break-all;"><?php echo esc_html( $db_error['error'] ); ?></code><br>
                        如果保存广告时报错，多半是表结构没跟上 —— 请到
                        <a href="<?php echo esc_url( admin_url( 'admin.php?page=wsa-payment' ) ); ?>">支付设置</a>
                        页底部的「刷新数据库结构」点一次。</p>
                </div>
            <?php endif; ?>

            <?php if ( isset( $_GET['wsa_ad_saved'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>广告已保存。</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['wsa_ad_deleted'] ) ) : ?>
                <div class="notice notice-success is-dismissible"><p>广告已删除。</p></div>
            <?php endif; ?>
            <?php if ( isset( $_GET['wsa_ad_toggled'] ) ) : ?>
                <div class="notice notice-success is-dismissible">
                    <p>
                        <?php echo $_GET['wsa_ad_toggled'] === 'active'
                            ? '广告已上架，现在会出现在前台对应位置。'
                            : '广告已下架，前台不再显示，它占的格子也已经释放出来。'; ?>
                        <?php if ( isset( $_GET['wsa_ad_renewed'] ) ) : ?>
                            <br>这条广告原本已经过期，已自动续期
                            <strong><?php echo absint( $_GET['wsa_ad_renewed'] ); ?></strong> 天，到期时间重新计算。
                        <?php endif; ?>
                    </p>
                </div>
            <?php endif; ?>
            <?php
            $ad_error = get_transient( 'wsa_ad_error_' . get_current_user_id() );
            if ( $ad_error ) {
                delete_transient( 'wsa_ad_error_' . get_current_user_id() );
            }
            ?>
            <?php if ( $ad_error ) : ?>
                <div class="notice notice-error"><p><?php echo esc_html( $ad_error ); ?></p></div>
            <?php endif; ?>

            <ul class="subsubsub">
                <?php $i = 0; $total_views = count( $views ); ?>
                <?php foreach ( $views as $key => $label ) : $i++; ?>
                    <?php
                    // 全部标签不带 view 参数，其余带上
                    $tab_args = [ 'page' => 'wsa-ads' ];
                    if ( $key !== '' ) $tab_args['view'] = $key;
                    ?>
                    <li>
                        <a href="<?php echo esc_url( add_query_arg( $tab_args, admin_url( 'admin.php' ) ) ); ?>"
                           class="<?php echo $view === $key ? 'current' : ''; ?>">
                            <?php echo esc_html( $label ); ?>
                            <span class="count">(<?php echo (int) ( $counts[ $key ] ?? 0 ); ?>)</span>
                        </a>
                        <?php echo $i < $total_views ? ' |' : ''; ?>
                    </li>
                <?php endforeach; ?>
            </ul>

            <p class="clear" style="margin-top:14px;">
                <a class="button button-primary" href="<?php echo esc_url( $add_url ); ?>">＋ 新增广告</a>
                <span class="description" style="margin-left:8px;">
                    在这里添加的广告记为「站长添加」，不影响任何用户的订单。
                </span>
            </p>

            <table class="widefat striped">
                <thead>
                    <tr>
                        <th style="width:52px;">ID</th>
                        <th style="width:190px;">广告位 / 格子</th>
                        <th style="width:150px;">内容预览</th>
                        <th>跳转链接 / 备注</th>
                        <th style="width:110px;">来源</th>
                        <th style="width:78px;">状态</th>
                        <th style="width:220px;">到期时间</th>
                        <th style="width:200px;">操作</th>
                    </tr>
                </thead>
                <tbody>
                <?php if ( ! $ads ) : ?>
                    <tr>
                        <td colspan="8">
                            这个筛选条件下还没有广告。用户下单付款后会自动出现在这里；
                            你也可以点上面的「＋ 新增广告」自己放一条。
                        </td>
                    </tr>
                <?php endif; ?>
                <?php foreach ( $ads as $ad ) :
                    $effective  = WSA_Ad_Manager::effective_status( $ad );
                    $edit_url   = add_query_arg(
                        [ 'page' => 'wsa-ads', 'wsa_action' => 'edit', 'ad' => (int) $ad->id ],
                        admin_url( 'admin.php' )
                    );
                    $toggle_url = wp_nonce_url(
                        add_query_arg(
                            [
                                'action' => 'wsa_toggle_ad',
                                'ad'     => (int) $ad->id,
                                // 在线的点一下是“下架”，其余（已下架 / 已过期）点一下都是“上架”
                                'to'     => $effective === 'active' ? 'paused' : 'active',
                            ],
                            admin_url( 'admin-post.php' )
                        ),
                        'wsa_toggle_ad'
                    );
                    $delete_url = wp_nonce_url(
                        add_query_arg(
                            [ 'action' => 'wsa_delete_ad', 'ad' => (int) $ad->id ],
                            admin_url( 'admin-post.php' )
                        ),
                        'wsa_delete_ad'
                    );
                    $confirm = $ad->source === WSA_Ad_Manager::SOURCE_USER
                        ? '确定删除这一条？它是用户花钱购买的广告：删除后广告不再展示、无法恢复，订单记录仍会保留（钱不会自动退）。如果只是想让它先不显示，请改用「下架」。'
                        : '确定删除这条广告？删除后无法恢复。';
                    ?>
                    <tr>
                        <td><?php echo (int) $ad->id; ?></td>
                        <td>
                            <strong><?php echo esc_html( $ad->slot_name ? $ad->slot_name : ( '广告位#' . (int) $ad->slot_id ) ); ?></strong>
                            <div class="description">
                                第 <?php echo (int) $ad->slot_position; ?> 格 ·
                                <?php echo esc_html( $ad->ad_type === 'text' ? '文字' : '图片' ); ?>
                            </div>
                        </td>
                        <td><?php echo self::ad_preview_html( $ad ); // 内部已逐项转义 ?></td>
                        <td>
                            <?php if ( ! empty( $ad->link_url ) ) : ?>
                                <a href="<?php echo esc_url( $ad->link_url ); ?>" target="_blank" rel="noopener noreferrer">
                                    <?php echo esc_html( wp_html_excerpt( $ad->link_url, 46, '…' ) ); ?>
                                </a>
                            <?php else : ?>
                                <span class="description">未设置（广告不可点击）</span>
                            <?php endif; ?>
                            <?php if ( ! empty( $ad->admin_note ) ) : ?>
                                <div class="description">备注：<?php echo esc_html( $ad->admin_note ); ?></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php echo esc_html( WSA_Ad_Manager::source_label( $ad->source ) ); ?>
                            <?php if ( $ad->source === WSA_Ad_Manager::SOURCE_USER ) : ?>
                                <div class="description">
                                    <?php echo esc_html( $ad->user_login ? $ad->user_login : ( '用户#' . (int) $ad->user_id ) ); ?>
                                </div>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html( WSA_Ad_Manager::status_label( $effective ) ); ?></td>
                        <td><?php echo esc_html( WSA_Ad_Manager::expiry_text( $ad ) ); ?></td>
                        <td>
                            <a class="button button-small" href="<?php echo esc_url( $edit_url ); ?>">编辑</a>
                            <a class="button button-small" href="<?php echo esc_url( $toggle_url ); ?>">
                                <?php echo $effective === 'active' ? '下架' : '上架'; ?>
                            </a>
                            <a class="button button-small wsa-confirm"
                               href="<?php echo esc_url( $delete_url ); ?>"
                               data-confirm="<?php echo esc_attr( $confirm ); ?>">删除</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <p class="description" style="margin-top:12px;">
                提示：「已下架」是你手动撤下的，位置已经空出来，别的广告可以占用它；
                「已过期」是投放时间到了，由系统自动下线。
                用户购买的广告到期后不会自动续费，需要用户重新下单，或你在这里手动续期。
            </p>
        </div>
        <?php
    }

    /** 列表里的「内容预览」一格 */
    private static function ad_preview_html( $ad ) {
        if ( $ad->ad_type === 'text' ) {
            return '<span style="word-break:break-all;">'
                . esc_html( wp_html_excerpt( (string) $ad->text_content, 40, '…' ) )
                . '</span>';
        }
        if ( empty( $ad->image_url ) ) {
            return '<span class="description">（无图片）</span>';
        }
        return '<img src="' . esc_url( $ad->image_url ) . '" alt="" '
            . 'style="max-width:120px;height:42px;object-fit:cover;border-radius:4px;border:1px solid #ddd;" />';
    }

    /** 把表单提交上来的内容整理成 WSA_Ad_Manager::save() 需要的格式 */
    private static function ad_input_from_post( $post ) {
        return [
            'id'            => absint( $post['ad_id'] ?? 0 ),
            'slot_id'       => absint( $post['slot_id'] ?? 0 ),
            'slot_position' => absint( $post['slot_position'] ?? 0 ),
            'ad_type'       => sanitize_key( $post['ad_type'] ?? 'image' ),
            'image_url'     => esc_url_raw( trim( (string) ( $post['image_url'] ?? '' ) ) ),
            'text_content'  => sanitize_text_field( $post['text_content'] ?? '' ),
            'link_url'      => esc_url_raw( trim( (string) ( $post['link_url'] ?? '' ) ) ),
            'admin_note'    => sanitize_text_field( $post['admin_note'] ?? '' ),
            'duration'      => absint( $post['duration'] ?? 0 ),
        ];
    }

    /** 根据广告位 ID 取名称（表单只读显示用） */
    private static function slot_name_by_id( $slot_id ) {
        $slot = WSA_Ad_Slots::get_by_id( $slot_id );
        return $slot ? $slot->slot_name : ( '广告位#' . (int) $slot_id );
    }

    /**
     * 新增 / 编辑广告的表单。
     *
     * @param int    $id     0 表示新增
     * @param string $error  上一次提交失败的原因（回显用）
     * @param array  $values 上一次提交的内容（回显用，避免站长重填）
     */
    private static function render_ad_form( $id, $error = '', $values = [] ) {
        $ad = $id ? WSA_Ad_Manager::get( $id ) : null;

        $list_url = add_query_arg( [ 'page' => 'wsa-ads' ], admin_url( 'admin.php' ) );

        if ( $id && ! $ad ) {
            ?>
            <div class="wrap">
                <h1>编辑广告</h1>
                <div class="notice notice-error"><p>这条广告不存在，可能已经被删除了。</p></div>
                <p><a class="button" href="<?php echo esc_url( $list_url ); ?>">返回广告列表</a></p>
            </div>
            <?php
            return;
        }

        // 用户购买的广告：广告位、格子、投放天数都不允许改，只让站长修正内容
        $is_admin_ad = ( ! $ad || $ad->source === WSA_Ad_Manager::SOURCE_ADMIN );

        /** 取值顺序：上一次提交的内容 → 数据库里的原值 → 默认值 */
        $val = function ( $key, $default = '' ) use ( $values, $ad ) {
            if ( ! empty( $values ) && isset( $values[ $key ] ) ) {
                return $values[ $key ];
            }
            if ( $ad && isset( $ad->$key ) ) {
                return $ad->$key;
            }
            return $default;
        };

        $slots   = WSA_Ad_Slots::get_all();
        $slot_id = absint( $val( 'slot_id', $slots ? $slots[0]->id : 0 ) );
        $type    = ( $val( 'ad_type', 'image' ) === 'text' ) ? 'text' : 'image';

        if ( ! empty( $values ) ) {
            $duration = absint( $values['duration'] ?? 0 );
        } elseif ( $ad ) {
            $duration = (int) $ad->duration;
        } else {
            $duration = WSA_Ad_Manager::DEFAULT_RENEW_DAYS;
        }

        // 每个广告位当前被占用的格子，写在下拉选项里，站长一眼就知道该填几
        $occupied = [];
        foreach ( $slots as $s ) {
            $occupied[ (int) $s->id ] = WSA_Ad_Manager::occupied_positions( $s->id, $ad ? (int) $ad->id : 0 );
        }

        $form_url = add_query_arg(
            array_filter( [
                'page'       => 'wsa-ads',
                'wsa_action' => 'edit',
                'ad'         => $ad ? (int) $ad->id : null,
            ] ),
            admin_url( 'admin.php' )
        );
        ?>
        <div class="wrap">
            <h1><?php echo $ad ? '编辑广告' : '新增广告'; ?></h1>
            <p><a href="<?php echo esc_url( $list_url ); ?>">&larr; 返回广告列表</a></p>

            <?php if ( $error ) : ?>
                <div class="notice notice-error"><p><?php echo esc_html( $error ); ?></p></div>
            <?php endif; ?>

            <form method="post" action="<?php echo esc_url( $form_url ); ?>">
                <input type="hidden" name="wsa_ad_form" value="1" />
                <input type="hidden" name="ad_id" value="<?php echo $ad ? (int) $ad->id : 0; ?>" />
                <?php wp_nonce_field( 'wsa_save_ad', 'wsa_ad_nonce' ); ?>

                <table class="form-table">
                    <tr>
                        <th>广告位</th>
                        <td>
                            <?php if ( $is_admin_ad ) : ?>
                                <select name="slot_id" id="wsa-slot-id">
                                    <?php foreach ( $slots as $s ) : ?>
                                        <option value="<?php echo (int) $s->id; ?>" <?php selected( $slot_id, (int) $s->id ); ?>>
                                            <?php
                                            echo esc_html( $s->slot_name );
                                            echo '（每行 ' . (int) $s->max_items . ' 格';
                                            echo $s->slot_type === 'text' ? '，文字广告位' : '';
                                            if ( ! empty( $occupied[ (int) $s->id ] ) ) {
                                                echo '，已占：' . esc_html( implode( '、', $occupied[ (int) $s->id ] ) );
                                            }
                                            echo '）';
                                            ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <p class="description">广告会显示在这个广告位里（前台需要页面已插入对应的短代码）。</p>
                            <?php else : ?>
                                <strong><?php echo esc_html( self::slot_name_by_id( $ad->slot_id ) ); ?></strong>
                                <input type="hidden" name="slot_id" value="<?php echo (int) $ad->slot_id; ?>" />
                                <p class="description">这条广告来自用户购买，广告位不能改。</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>位置序号</th>
                        <td>
                            <?php if ( $is_admin_ad ) : ?>
                                <input type="number" min="1" step="1" name="slot_position" id="wsa-slot-position"
                                       value="<?php echo absint( $val( 'slot_position', 1 ) ); ?>" style="width:100px;" />
                                <p class="description">
                                    填第几格。已被占用的格子要先下架才能用。
                                    序号填太大会把前面空出一大片空格子，一般从 1 往后填就行。
                                </p>
                            <?php else : ?>
                                <strong>第 <?php echo (int) $ad->slot_position; ?> 格</strong>
                                <input type="hidden" name="slot_position" value="<?php echo (int) $ad->slot_position; ?>" />
                                <p class="description">这条广告来自用户购买，格子不能改（改了就和他的订单对不上了）。</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>广告类型</th>
                        <td>
                            <select name="ad_type" class="wsa-ad-type">
                                <option value="image" <?php selected( $type, 'image' ); ?>>图片广告</option>
                                <option value="text"  <?php selected( $type, 'text' ); ?>>文字广告</option>
                            </select>
                            <p class="description">图片广告只显示图片；文字广告只显示一行文字。切换后下面会跟着变。</p>
                        </td>
                    </tr>
                    <tr class="wsa-row-image">
                        <th>图片地址</th>
                        <td>
                            <input type="text" class="regular-text wsa-image-url" id="wsa-image-url" name="image_url"
                                   value="<?php echo esc_attr( $val( 'image_url', '' ) ); ?>" placeholder="https://..." />
                            <button type="button" class="button wsa-pick-image">从媒体库选择</button>
                            <div class="wsa-image-preview">
                                <?php $preview_img = (string) $val( 'image_url', '' ); ?>
                                <?php if ( $preview_img !== '' ) : ?>
                                    <img src="<?php echo esc_url( $preview_img ); ?>" alt="" style="max-width:200px;height:auto;margin-top:6px;border:1px solid #ddd;border-radius:4px;" />
                                <?php endif; ?>
                            </div>
                            <p class="description">建议宽度与广告位一致（大/小横幅约 1200px，迷你、方块约 400px），高度按比例即可。</p>
                        </td>
                    </tr>
                    <tr class="wsa-row-text">
                        <th>文字内容</th>
                        <td>
                            <input type="text" class="regular-text" id="wsa-text-content" name="text_content"
                                   maxlength="200" value="<?php echo esc_attr( $val( 'text_content', '' ) ); ?>"
                                   placeholder="例如：双十一全场五折" />
                            <p class="description">最多 200 个字，建议 20 字以内（太长会被省略号截断）。</p>
                        </td>
                    </tr>
                    <tr>
                        <th>点击跳转链接</th>
                        <td>
                            <input type="text" class="regular-text" id="wsa-link-url" name="link_url"
                                   value="<?php echo esc_attr( $val( 'link_url', '' ) ); ?>"
                                   placeholder="https://...（可留空）" />
                            <p class="description">留空时这块广告不可点击，只作展示。</p>
                        </td>
                    </tr>
                    <?php if ( $is_admin_ad ) : ?>
                        <tr>
                            <th>投放天数</th>
                            <td>
                                <input type="number" min="0" step="1" id="wsa-duration" name="duration"
                                       value="<?php echo (int) $duration; ?>" style="width:100px;" />
                                <p class="description">
                                    从<strong>现在</strong>开始算。填 <code>0</code> 表示<strong>永久有效</strong>。
                                    每次保存都会按这里的天数重新计算到期时间。
                                </p>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <th>备注</th>
                        <td>
                            <input type="text" class="regular-text" id="wsa-admin-note" name="admin_note"
                                   maxlength="255" value="<?php echo esc_attr( $val( 'admin_note', '' ) ); ?>"
                                   placeholder="例如：合作客户 A，2026-10 到期" />
                            <p class="description">只有你自己看得到，不会显示在前台。</p>
                        </td>
                    </tr>
                </table>

                <?php echo submit_button( $ad ? '保存修改' : '添加广告', 'primary', 'submit', false ); ?>
                <a class="button" style="margin-left:6px;" href="<?php echo esc_url( $list_url ); ?>">取消</a>
            </form>

            <?php if ( $ad ) : ?>
                <h2 style="margin-top:34px;">这条广告的信息</h2>
                <table class="form-table">
                    <tr><th>来源</th>
                        <td>
                            <?php echo esc_html( WSA_Ad_Manager::source_label( $ad->source ) ); ?>
                            <?php if ( $ad->source === WSA_Ad_Manager::SOURCE_USER ) : ?>
                                <span class="description">
                                    （订单号可在
                                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wsa-orders' ) ); ?>">订单管理</a>
                                    里按时间对照）
                                </span>
                            <?php endif; ?>
                        </td></tr>
                    <tr><th>当前状态</th>
                        <td><?php echo esc_html( WSA_Ad_Manager::status_label( WSA_Ad_Manager::effective_status( $ad ) ) ); ?></td></tr>
                    <tr><th>开始时间</th><td><?php echo esc_html( $ad->started_at ); ?></td></tr>
                    <tr><th>到期时间</th>
                        <td>
                            <?php echo esc_html( WSA_Ad_Manager::expiry_text( $ad ) ); ?>
                            <?php if ( $ad->source === WSA_Ad_Manager::SOURCE_USER ) : ?>
                                <p class="description">
                                    这条广告来自用户购买，改内容<strong>不会</strong>影响到期时间。
                                    如果已经过期还想继续展示，可以在列表里点「上架」，系统会自动按它的投放天数续期。
                                </p>
                            <?php endif; ?>
                        </td></tr>
                    <tr><th>创建时间</th><td><?php echo esc_html( $ad->created_at ); ?></td></tr>
                </table>
            <?php endif; ?>
        </div>
        <?php
    }

    /* ---- 订单管理 ---- */
    public static function page_orders() {
        global $wpdb;
        $orders = $wpdb->get_results( "SELECT o.*, u.user_login FROM " . WSA_DB::table( 'orders' ) . " o
            LEFT JOIN {$wpdb->users} u ON o.user_id = u.ID
            ORDER BY o.created_at DESC LIMIT 100" );
        ?>
        <div class="wrap">
            <h1>订单管理</h1>
            <p class="description">
                「待支付」的订单超过 <?php echo (int) ( WSA_Orders::PENDING_TTL / 60 ); ?> 分钟未付款会自动关闭并释放位置；
                「待人工核对」表示支付金额不符或位置冲突，需要你手动处理（退款或联系用户）。
            </p>
            <table class="widefat striped">
                <thead>
                    <tr><th>订单号</th><th>用户</th><th>金额</th><th>时长</th><th>支付方式</th><th>支付通道</th><th>状态</th><th>到期时间</th><th>创建时间</th></tr>
                </thead>
                <tbody>
                <?php foreach ( $orders as $o ) : ?>
                    <tr <?php echo $o->status === 'review' ? 'style="background:#fcf0f0;"' : ''; ?>>
                        <td><?php echo esc_html( $o->order_no ); ?></td>
                        <td><?php echo esc_html( $o->user_login ? $o->user_login : ( '用户#' . $o->user_id ) ); ?></td>
                        <td>¥<?php echo number_format( $o->amount, 2 ); ?></td>
                        <td><?php echo absint( $o->duration ); ?>天</td>
                        <td><?php echo esc_html( WSA_Payment::type_label( $o->payment_method ) ); ?></td>
                        <td>
                            <?php if ( ! empty( $o->payment_channel ) ) : ?>
                                <?php echo esc_html( WSA_Payment::channel_label( $o->payment_channel ) ); ?>
                            <?php else : ?>
                                <span style="color:#999;">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html( self::status_label( $o->status ) ); ?></td>
                        <td><?php echo esc_html( $o->expires_at ? $o->expires_at : '-' ); ?></td>
                        <td><?php echo esc_html( $o->created_at ); ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /* ---- 支付设置 ---- */
    public static function page_payment() {
        $alipay = get_option( 'wsa_alipay_config', [] );
        $epay   = get_option( 'wsa_epay_config', [] );

        // 老配置没有 enabled 字段，默认视为开启，避免升级后支付方式莫名消失
        $alipay_enabled = ! isset( $alipay['enabled'] ) ? true : ! empty( $alipay['enabled'] );
        $epay_enabled   = ! isset( $epay['enabled'] ) ? true : ! empty( $epay['enabled'] );

        // 老配置没有 types 字段，默认给支付宝 + 微信，保证升级后仍能正常收款
        $epay_types     = isset( $epay['types'] ) ? (array) $epay['types'] : [ 'alipay', 'wechat' ];
        $epay_can_do    = WSA_Payment::epay_supported_types();
        $type_labels    = WSA_Payment::payment_types();
        ?>
        <div class="wrap">
            <h1>支付参数设置</h1>
            <p class="description">
                在这里配置「支付通道」（真正对接的服务商）。用户在收银台看到的是「付款方式」，
                系统会自动把它路由到可用的通道：<strong>支付宝官方优先，其次易支付</strong>。
                只有「已勾选启用」且「参数填写完整」的通道才会对外提供服务。
            </p>

            <h2>支付宝配置</h2>
            <p class="description">官方直连，仅支持支付宝付款。</p>
            <form method="post" action="options.php">
                <?php settings_fields( 'wsa_alipay_group' ); ?>
                <table class="form-table">
                    <tr><th>启用</th>
                        <td><label><input type="checkbox" name="wsa_alipay_config[enabled]" value="1" <?php checked( $alipay_enabled ); ?> /> 启用支付宝官方通道</label></td></tr>
                    <tr><th>App ID</th>
                        <td><input type="text" name="wsa_alipay_config[app_id]" value="<?php echo esc_attr( $alipay['app_id'] ?? '' ); ?>" class="regular-text" /></td></tr>
                    <tr><th>应用私钥</th>
                        <td><textarea name="wsa_alipay_config[private_key]" rows="4" class="large-text" autocomplete="off"><?php echo esc_textarea( $alipay['private_key'] ?? '' ); ?></textarea>
                            <p class="description">RSA2 私钥。带不带头尾标记都可以，PKCS#8 / PKCS#1 两种格式都支持。</p></td></tr>
                    <tr><th>支付宝公钥</th>
                        <td><textarea name="wsa_alipay_config[alipay_public_key]" rows="4" class="large-text" autocomplete="off"><?php echo esc_textarea( $alipay['alipay_public_key'] ?? '' ); ?></textarea>
                            <p class="description">用于验签异步通知</p></td></tr>
                </table>
                <?php submit_button( '保存支付宝设置' ); ?>
            </form>

            <h2>易支付配置</h2>
            <p class="description">聚合收单，可同时承接支付宝、微信等多种付款方式。</p>
            <form method="post" action="options.php">
                <?php settings_fields( 'wsa_epay_group' ); ?>
                <table class="form-table">
                    <tr><th>启用</th>
                        <td><label><input type="checkbox" name="wsa_epay_config[enabled]" value="1" <?php checked( $epay_enabled ); ?> /> 启用易支付通道</label></td></tr>
                    <tr><th>接口地址</th>
                        <td><input type="url" name="wsa_epay_config[api_url]" value="<?php echo esc_attr( $epay['api_url'] ?? '' ); ?>" class="regular-text" placeholder="https://pay.xxx.com" />
                            <p class="description">
                                填服务商的主域名即可（例如 <code>https://pay.phpwc.com</code>）。
                                如果你手上拿到的是完整地址（如 <code>.../submit.php</code> 或 <code>.../mapi.php</code>），也可以直接粘进来，插件会自动去掉文件名。
                            </p></td></tr>
                    <tr><th>商户 ID</th>
                        <td><input type="text" name="wsa_epay_config[pid]" value="<?php echo esc_attr( $epay['pid'] ?? '' ); ?>" class="regular-text" autocomplete="off" /></td></tr>
                    <tr><th>商户密钥</th>
                        <td><input type="password" name="wsa_epay_config[key]" value="<?php echo esc_attr( $epay['key'] ?? '' ); ?>" class="regular-text" autocomplete="new-password" />
                            <p class="description">输入框已改为密码形式，避免被旁人看到；密钥以明文存在数据库中，请勿随意导出数据库。</p></td></tr>
                    <tr><th>接口模式</th>
                        <td>
                            <select name="wsa_epay_config[mode]">
                                <option value="auto" <?php selected( WSA_Payment::epay_mode(), 'auto' ); ?>>自动（推荐）</option>
                                <option value="api"  <?php selected( WSA_Payment::epay_mode(), 'api' ); ?>>收银台接口 mapi.php</option>
                                <option value="page" <?php selected( WSA_Payment::epay_mode(), 'page' ); ?>>页面跳转 submit.php</option>
                            </select>
                            <p class="description">
                                <strong>自动</strong>：优先用新式「收银台接口」下单，出错时服务商会把原因原样告诉我们，
                                你也能在弹窗里看到人话提示；如果这家服务商没有这个接口，会自动改用老的「页面跳转」方式。<br>
                                <strong>收银台接口</strong>：只用 <code>mapi.php</code>（网程PAY 等平台推荐，支付宝/微信都走它）。<br>
                                <strong>页面跳转</strong>：只用 <code>submit.php</code>，把用户的浏览器直接送到服务商收银台。
                                这种方式出错时你看不到原因（报错在服务商那边），只在自动模式失效时才手动选它。
                            </p>
                        </td></tr>
                    <tr><th>商户通道 ID</th>
                        <td>
                            <input type="text" name="wsa_epay_config[tdid]" value="<?php echo esc_attr( $epay['tdid'] ?? ( $epay['cid'] ?? '' ) ); ?>" class="regular-text" autocomplete="off" placeholder="留空则不传该参数" />
                            参数名
                            <select name="wsa_epay_config[tdid_param]">
                                <option value="tdid" <?php selected( ( $epay['tdid_param'] ?? 'tdid' ), 'tdid' ); ?>>tdid（网程PAY 等）</option>
                                <option value="cid"  <?php selected( ( $epay['tdid_param'] ?? 'tdid' ), 'cid' ); ?>>cid（部分易支付）</option>
                            </select>
                            <p class="description">
                                只有当你在服务商那边开通了<strong>多条通道</strong>、需要指定其中一条时才要填。
                                <strong>不确定就留空</strong>，留空时完全不传这个参数，不会影响原本正常的支付。
                                如果服务商提示“没有查到可用的支付通道”或“通道ID”相关错误，再回来填它。
                            </p>
                        </td></tr>
                    <tr><th>支持的付款方式</th>
                        <td>
                            <?php foreach ( $epay_can_do as $type => $code ) : ?>
                                <label style="margin-right:16px;">
                                    <input type="checkbox" name="wsa_epay_config[types][]"
                                           value="<?php echo esc_attr( $type ); ?>"
                                        <?php checked( in_array( $type, $epay_types, true ) ); ?> />
                                    <?php echo esc_html( $type_labels[ $type ] ?? $type ); ?>
                                    <code style="font-size:11px;">type=<?php echo esc_html( $code ); ?></code>
                                </label>
                            <?php endforeach; ?>
                            <p class="description">
                                请按你的易支付商户实际开通的渠道勾选。只有勾选的付款方式才会出现在用户的支付选项里；
                                如果某个付款方式是支付宝，且支付宝官方通道也可用，系统会优先走官方通道。
                            </p>
                        </td></tr>
                </table>
                <?php submit_button( '保存易支付设置' ); ?>
            </form>

            <h3 style="margin-top:26px;">易支付接口自检</h3>
            <p class="description" style="max-width:900px;">
                插件只负责把用户送到服务商的收银台，能不能用某种付款方式由服务商决定。
                点下面的按钮，插件会用一笔 <strong>0.01 元的探测订单</strong>真实请求一次服务商，
                把它返回的<strong>原话</strong>抓回来给你看。探测<strong>不会真的付款</strong>，也不会影响本站订单。<br>
                请先把上面的易支付参数<strong>保存</strong>，再点这里检测。
            </p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-bottom:10px;">
                <input type="hidden" name="action" value="wsa_probe_epay" />
                <?php wp_nonce_field( 'wsa_probe_epay', 'wsa_probe_nonce' ); ?>
                <select name="type">
                    <option value="all">本商户开通的全部付款方式</option>
                    <?php foreach ( WSA_Payment::epay_supported_types() as $t_key => $t_code ) : ?>
                        <option value="<?php echo esc_attr( $t_code ); ?>">
                            <?php echo esc_html( $type_labels[ $t_key ] ?? $t_key ); ?>（type=<?php echo esc_html( $t_code ); ?>）
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="button button-primary">测试接口连通性</button>
            </form>

            <?php
            $probe = get_transient( 'wsa_epay_probe_' . get_current_user_id() );
            if ( $probe ) {
                delete_transient( 'wsa_epay_probe_' . get_current_user_id() );
            }
            ?>
            <?php if ( $probe ) : ?>
                <div class="notice notice-info" style="max-width:1000px;">
                    <p><strong>自检结果</strong></p>
                    <?php if ( empty( $probe['ok'] ) ) : ?>
                        <p style="color:#d63638;"><?php echo esc_html( $probe['error'] ); ?></p>
                    <?php else : ?>
                        <p class="description">
                            接口根地址：<code><?php echo esc_html( $probe['base'] ); ?></code><br>
                            收银台接口：<code><?php echo esc_html( $probe['api'] ); ?></code><br>
                            页面跳转接口：<code><?php echo esc_html( $probe['page'] ); ?></code>
                        </p>

                        <?php foreach ( $probe['tests'] as $code => $checks ) : ?>
                            <table class="widefat striped" style="margin:0 0 14px;">
                                <thead>
                                    <tr>
                                        <th colspan="3" style="background:#f0f0f1;">
                                            付款方式：<?php echo esc_html( $probe['labels'][ $code ] ?? $code ); ?>
                                            （type=<?php echo esc_html( $code ); ?>）
                                        </th>
                                    </tr>
                                    <tr><th style="width:200px;">接口</th><th style="width:90px;">返回码</th><th>结论与原文</th></tr>
                                </thead>
                                <tbody>
                                <?php foreach ( $checks as $c ) :
                                    $is_ok   = ( $c['code'] === 1 );
                                    $no_code = ( $c['code'] === '' );
                                    $color   = $is_ok ? '#008a20' : ( $no_code ? '#5f5e5a' : '#d63638' );
                                    ?>
                                    <tr>
                                        <td>
                                            <code><?php echo esc_html( $c['name'] ); ?></code>
                                            <div style="color:#8c8f94;font-size:11px;word-break:break-all;"><?php echo esc_html( $c['url'] ); ?></div>
                                        </td>
                                        <td>
                                            <div>HTTP <?php echo $c['status'] === '' ? '—' : (int) $c['status']; ?></div>
                                            <div style="color:<?php echo esc_attr( $color ); ?>;font-weight:600;">
                                                <?php echo $c['code'] === '' ? '非接口返回' : ( 'code=' . (int) $c['code'] ); ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div style="color:<?php echo esc_attr( $color ); ?>;font-weight:600;"><?php echo esc_html( $c['verdict'] ); ?></div>
                                            <?php if ( ! empty( $c['raw'] ) ) : ?>
                                                <div style="margin-top:6px;color:#3c434a;font-size:12px;word-break:break-all;">
                                                    服务商原话：<code style="white-space:pre-wrap;"><?php echo esc_html( $c['raw'] ); ?></code>
                                                </div>
                                            <?php endif; ?>
                                            <?php
                                            $advice = $is_ok ? '' : WSA_Payment::judge_epay_message( (string) $c['raw'] );
                                            if ( $advice !== '' ) :
                                            ?>
                                                <div style="margin-top:6px;padding:8px 10px;background:#fcf9e8;border-left:4px solid #dba617;font-size:12px;">
                                                    <strong>建议：</strong><?php echo esc_html( $advice ); ?>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php endforeach; ?>

                        <p class="description">
                            怎么看这张表：<strong>code=1</strong> 表示这条接口通了。
                            如果「接口通了、但收银台拒绝了这个付款方式」，说明插件的参数没问题，
                            是<strong>商户后台没有开通这种付款方式</strong>（或通道没启用），要去服务商那边处理。
                        </p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <h2>回调地址</h2>
            <p class="description">
                下面的地址由插件自动生成，无需修改；如果支付平台要求你填写，直接复制即可。
                注意：回调地址是按「支付通道」区分的，与用户选择的付款方式无关。
            </p>
            <table class="form-table">
                <tr><th>支付宝官方 - 异步通知</th>
                    <td><code><?php echo esc_url( home_url( '/wsa-notify/alipay' ) ); ?></code></td></tr>
                <tr><th>支付宝官方 - 同步跳转</th>
                    <td><code><?php echo esc_url( home_url( '/wsa-return/alipay' ) ); ?></code></td></tr>
                <tr><th>易支付 - 异步通知</th>
                    <td><code><?php echo esc_url( home_url( '/wsa-notify/epay' ) ); ?></code></td></tr>
                <tr><th>易支付 - 同步跳转</th>
                    <td><code><?php echo esc_url( home_url( '/wsa-return/epay' ) ); ?></code></td></tr>
            </table>

            <h2>自检</h2>
            <h3 style="margin-bottom:6px;">支付通道路由</h3>
            <p class="description">用户能选的每一种付款方式，最终由哪个通道承接。多行时取优先级最高的一行（数字越小越优先）。</p>
            <table class="widefat striped" style="max-width:820px;">
                <thead>
                    <tr><th>付款方式</th><th>可选通道（按优先级）</th><th>实际使用</th></tr>
                </thead>
                <tbody>
                <?php foreach ( WSA_Payment::routing_table() as $type => $row ) : ?>
                    <tr>
                        <td><strong><?php echo esc_html( $row['label'] ); ?></strong></td>
                        <td>
                            <?php if ( $row['candidates'] ) : ?>
                                <?php echo esc_html( implode( ' → ', $row['candidates'] ) ); ?>
                            <?php else : ?>
                                <span style="color:#d63638;">无可用通道</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ( $row['picked'] ) : ?>
                                <span style="color:#008a20;"><?php echo esc_html( $row['candidates'][ $row['picked'] ] ); ?></span>
                            <?php else : ?>
                                <span style="color:#d63638;">不可用</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h3 style="margin-bottom:6px;">通道状态</h3>
            <table class="widefat striped" style="max-width:820px;">
                <thead>
                    <tr><th>支付通道</th><th>优先级</th><th>支持付款方式</th><th>状态</th></tr>
                </thead>
                <tbody>
                <?php foreach ( WSA_Payment::channels() as $key => $channel ) : ?>
                    <?php
                    $available = WSA_Payment::channel_is_available( $key );
                    $supports  = [];
                    foreach ( array_keys( $channel['types'] ) as $t ) {
                        $supports[] = $type_labels[ $t ] ?? $t;
                    }
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $channel['label'] ); ?></strong> <code style="font-size:11px;"><?php echo esc_html( $key ); ?></code></td>
                        <td><?php echo (int) $channel['priority']; ?></td>
                        <td><?php echo $supports ? esc_html( implode( '、', $supports ) ) : '<span style="color:#d63638;">未开通任何方式</span>'; ?></td>
                        <td>
                            <?php if ( $available ) : ?>
                                <span style="color:#008a20;">可用</span>
                            <?php else : ?>
                                <span style="color:#d63638;">不可用</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h3 style="margin-bottom:6px;">其它检查</h3>
            <table class="form-table">
                <tr><th>用户可选的付款方式</th>
                    <td>
                        <?php $methods = WSA_Payment::available_methods(); ?>
                        <?php if ( $methods ) : ?>
                            <?php echo esc_html( implode( '、', $methods ) ); ?>
                        <?php else : ?>
                            <span style="color:#d63638;">暂无。请先启用一个通道并填写完整参数。</span>
                        <?php endif; ?>
                    </td></tr>
                <tr><th>回调地址检测</th>
                    <td>
                        <?php $rules = get_option( 'rewrite_rules' ); ?>
                        <?php if ( is_array( $rules ) && isset( $rules['^wsa-notify/([a-z0-9_\-]+)/?$'] ) ) : ?>
                            <span style="color:#008a20;">已生效</span>
                        <?php else : ?>
                            <span style="color:#d63638;">未生效</span>，请到「设置 → 固定链接」点一次“保存更改”即可刷新。
                        <?php endif; ?>
                    </td></tr>
                <tr><th>数据库结构</th>
                    <td>
                        <?php $struct = WSA_DB::column_check(); ?>
                        <?php
                        $struct_ok = true;
                        foreach ( $struct as $row ) {
                            if ( ! $row['table'] || $row['missing'] ) { $struct_ok = false; break; }
                        }
                        ?>
                        <?php if ( $struct_ok ) : ?>
                            <span style="color:#008a20;">完整</span>
                            <span class="description">（结构版本 <?php echo esc_html( (string) get_option( 'wsa_db_version' ) ); ?>）</span>
                        <?php else : ?>
                            <span style="color:#d63638;font-weight:600;">不完整</span>
                            <span class="description">（结构版本 <?php echo esc_html( (string) get_option( 'wsa_db_version' ) ); ?>）</span>
                            <div style="margin-top:8px;padding:10px 12px;background:#fcf0f0;border-left:4px solid #d63638;">
                                <strong>这很可能就是「订单创建失败」的真正原因。</strong>缺少的字段：
                                <ul style="margin:6px 0 6px 18px;list-style:disc;">
                                    <?php foreach ( $struct as $name => $row ) : ?>
                                        <li>
                                            表 <code>wsa_<?php echo esc_html( $name ); ?></code>：
                                            <?php if ( ! $row['table'] ) : ?>
                                                <strong>整张表都不存在</strong>
                                            <?php else : ?>
                                                <?php foreach ( $row['missing'] as $col ) : ?>
                                                    <code style="color:#d63638;"><?php echo esc_html( $col ); ?></code>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                                修复办法：先点本页底部的「刷新数据库结构」按钮，再到「设置 → 固定链接」点一次“保存更改”。
                                如果点了仍然不完整，请改用最下面「手工 SQL」里给出的语句。
                            </div>
                        <?php endif; ?>
                    </td></tr>
            </table>

            <h3 style="margin-bottom:6px;">数据库修复</h3>
            <p class="description" style="max-width:900px;">
                插件是「覆盖升级」的，如果某次升级时补字段没跑成功，就会表现为功能莫名其妙全部失败。
                这里的按钮会按当前版本的代码重新比对一遍表结构，把缺的表、字段、索引补上
                （<strong>不会删除任何已有数据</strong>）。补完之后请把「设置 → 固定链接」点一次“保存更改”。
            </p>
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="wsa_repair_db" />
                <?php wp_nonce_field( 'wsa_repair_db', 'wsa_repair_nonce' ); ?>
                <button type="submit" class="button button-primary">刷新数据库结构</button>
            </form>

            <?php
            // 显示“上一次点击到底补了什么”，方便确认有没有真的修好
            $repair_report = get_transient( 'wsa_repair_report_' . get_current_user_id() );
            if ( $repair_report ) {
                delete_transient( 'wsa_repair_report_' . get_current_user_id() );
            }
            ?>
            <?php if ( isset( $_GET['wsa_repaired'] ) && is_array( $repair_report ) ) : ?>
                <div class="notice notice-info" style="margin-top:10px;max-width:900px;">
                    <p><strong>本次修复明细</strong></p>
                    <?php echo self::repair_report_html( $repair_report ); // 内部已逐项转义 ?>
                    <?php if ( WSA_DB::structure_is_ok() ) : ?>
                        <p style="color:#008a20;">结构已完整，可以正常下单了。若仍有问题，请核对上面的字段清单是否与本表一致。</p>
                    <?php else : ?>
                        <p style="color:#d63638;">结构仍不完整。请把本段内容和上面的红色提示一起截图发给开发者，
                            或改用下面「手工 SQL」的办法。</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?php $db_error = get_option( 'wsa_last_db_error' ); ?>
            <?php if ( is_array( $db_error ) && ! empty( $db_error['error'] ) ) : ?>
                <h3 style="margin-bottom:6px;">最近一次数据库报错</h3>
                <div class="notice notice-error" style="max-width:900px;">
                    <p class="description" style="margin:0 0 6px;">
                        <?php echo esc_html( $db_error['time'] ?? '' ); ?>
                        <?php if ( ! empty( $db_error['what'] ) ) : ?>
                            · <?php echo esc_html( $db_error['what'] ); ?>
                        <?php endif; ?>
                        <?php if ( ! empty( $db_error['order_no'] ) ) : ?>
                            · 订单 <?php echo esc_html( $db_error['order_no'] ); ?>
                        <?php endif; ?>
                    </p>
                    <p>数据库原话：<code style="word-break:break-all;"><?php echo esc_html( $db_error['error'] ); ?></code></p>
                    <p class="description" style="word-break:break-all;">
                        当时执行的语句：<code><?php echo esc_html( $db_error['query'] ?? '' ); ?></code>
                    </p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="wsa_clear_db_error" />
                        <?php wp_nonce_field( 'wsa_clear_db_error', 'wsa_clear_nonce' ); ?>
                        <button type="submit" class="button button-secondary">问题已解决，清除这条记录</button>
                    </form>
                </div>
            <?php endif; ?>

            <?php $manual_sql = WSA_DB::repair_sql(); ?>
            <?php if ( $manual_sql ) : ?>
                <h3 style="margin-bottom:6px;">手工 SQL（插件补不了时的兜底办法）</h3>
                <p class="description" style="max-width:900px;">
                    如果上面的按钮点了仍然不完整，通常是数据库账号<strong>没有 ALTER 权限</strong>。
                    请把下面这几句复制到
                    <strong>phpMyAdmin</strong>（或宝塔面板 → 数据库 → 管理 → SQL 窗口）里执行一次。
                    它们只做“增加”，不会删除任何数据。
                </p>
                <textarea readonly rows="<?php echo esc_attr( min( 12, count( $manual_sql ) + 1 ) ); ?>"
                    class="large-text code" onclick="this.select();"><?php echo esc_textarea( implode( "\n", $manual_sql ) ); ?></textarea>
            <?php endif; ?>
        </div>
        <?php
    }
}
