<?php
/**
 * 广告管理：站长广告与用户广告的统一读写入口
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 广告管理：站长在后台自定义广告内容、手动上架 / 下架。
 *
 * 站长手动添加的广告与用户花钱买的广告放在同一张表（wsa_user_ads）里，
 * 只用一个 source 字段区分来源：
 *
 *   source = 'user'   用户在收银台下单购买，order_id 指向那笔订单
 *   source = 'admin'  站长在后台「广告管理」里手动添加，order_id / user_id 记为 0
 *
 * 这样做的好处：前台渲染只有一条查询，不需要到处判断“这条广告是谁的”。
 *
 * 状态（status）一共三种：
 *   active  在线（正在展示）
 *   paused  已下架（站长手动撤下，位置会被释放，可以重新上架）
 *   expired 已过期（投放时间结束，由定时任务自动设置）
 */
class WSA_Ad_Manager {

    const SOURCE_USER  = 'user';
    const SOURCE_ADMIN = 'admin';

    /**
     * “永久有效”的到期时间。
     * 表里 expires_at 是 NOT NULL，不能存空值，所以用一个足够远的时间点表示“不设期限”。
     * 选 2099 年既不会溢出 DATETIME，又远到实际使用中永远不会到期。
     */
    const NEVER_EXPIRES = '2099-12-31 23:59:59';

    /** 广告没有记录投放天数时，重新上架默认续期多少天 */
    const DEFAULT_RENEW_DAYS = 30;

    /* ==================================================================
     * 一、一些固定文案
     * ================================================================== */

    /** 全部状态：状态值 => 中文名 */
    public static function statuses() {
        return [
            'active'  => '在线',
            'paused'  => '已下架',
            'expired' => '已过期',
        ];
    }

    /** 状态的中文名 */
    public static function status_label( $status ) {
        $map = self::statuses();
        return isset( $map[ $status ] ) ? $map[ $status ] : (string) $status;
    }

    /** 来源的中文名 */
    public static function source_label( $source ) {
        return $source === self::SOURCE_ADMIN ? '站长添加' : '用户购买';
    }

    /**
     * 这条广告“看起来”是什么状态。
     *
     * 为什么不能直接看 status：定时任务是每小时跑一次的，在它把到期广告改成 expired 之前，
     * 数据库里仍然是 active，但前台其实已经不展示了。后台必须按真实情况显示，
     * 否则站长会看到一条“在线”的广告却在前台找不到。
     */
    public static function effective_status( $ad ) {
        if ( $ad->status === 'active'
            && strtotime( $ad->expires_at . ' UTC' ) <= strtotime( WSA_DB::now() . ' UTC' ) ) {
            return 'expired';
        }
        return $ad->status;
    }

    /** 后台列表的筛选标签：查询参数 => 中文名 */
    public static function views() {
        return [
            ''        => '全部',
            'active'  => '在线',
            'paused'  => '已下架',
            'expired' => '已过期',
            'admin'   => '站长添加',
        ];
    }

    /* ==================================================================
     * 二、查询
     * ================================================================== */

    /**
     * 取广告列表（后台用），带上广告位名称和用户名。
     *
     * @param array $args view（筛选标签）/ slot_id（限定广告位）/ limit / offset
     */
    public static function query( $args = [] ) {
        global $wpdb;

        $args = wp_parse_args( $args, [
            'view'    => '',
            'slot_id' => 0,
            'limit'   => 300,
            'offset'  => 0,
        ] );

        $ads    = WSA_DB::table( 'user_ads' );
        $slots  = WSA_DB::table( 'ad_slots' );
        $now    = WSA_DB::now();
        $where  = [];
        $params = [];

        switch ( $args['view'] ) {
            case 'active':
                // 只算“真的还在线”的：状态是 active 且没过期
                $where[]  = "a.status = 'active' AND a.expires_at > %s";
                $params[] = $now;
                break;
            case 'paused':
                $where[] = "a.status = 'paused'";
                break;
            case 'expired':
                // 已经标记过期的，加上“还没轮到定时任务处理、但实际已经到期”的
                $where[]  = "( a.status = 'expired' OR ( a.status = 'active' AND a.expires_at <= %s ) )";
                $params[] = $now;
                break;
            case 'admin':
                $where[] = "a.source = 'admin'";
                break;
        }

        if ( (int) $args['slot_id'] > 0 ) {
            $where[]  = 'a.slot_id = %d';
            $params[] = (int) $args['slot_id'];
        }

        $sql = "SELECT a.*, s.slot_name, s.slot_key, s.slot_type, u.user_login
                FROM `{$ads}` a
                LEFT JOIN `{$slots}` s ON a.slot_id = s.id
                LEFT JOIN `{$wpdb->users}` u ON a.user_id = u.ID";

        if ( $where ) {
            $sql .= ' WHERE ' . implode( ' AND ', $where );
        }

        // 在线的排前面；同一个广告位内按位置号排，方便一眼看出哪里还空着
        $sql .= " ORDER BY ( a.status = 'active' ) DESC, a.slot_id ASC, a.slot_position ASC, a.id DESC";

        $params[] = max( 1, (int) $args['limit'] );
        $params[] = max( 0, (int) $args['offset'] );
        $sql     .= ' LIMIT %d OFFSET %d';

        return $wpdb->get_results( $wpdb->prepare( $sql, ...$params ) );
    }

    /** 各筛选标签下的广告条数，用于标签上显示数字 */
    public static function counts() {
        global $wpdb;
        $ads = WSA_DB::table( 'user_ads' );
        $now = WSA_DB::now();

        return [
            ''        => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$ads}`" ),
            'active'  => (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM `{$ads}` WHERE status = 'active' AND expires_at > %s", $now
            ) ),
            'paused'  => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$ads}` WHERE status = 'paused'" ),
            'expired' => (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM `{$ads}` WHERE status = 'expired' OR ( status = 'active' AND expires_at <= %s )",
                $now
            ) ),
            'admin'   => (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$ads}` WHERE source = 'admin'" ),
        ];
    }

    /** 取单条广告 */
    public static function get( $id ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            'SELECT * FROM `' . WSA_DB::table( 'user_ads' ) . '` WHERE id = %d',
            (int) $id
        ) );
    }

    /**
     * 某个广告位当前被“在线广告”占着的位置号。
     *
     * @param int $exclude_id 排除某条广告（编辑自己时用，否则会跟自己冲突）
     */
    public static function occupied_positions( $slot_id, $exclude_id = 0 ) {
        global $wpdb;

        $ads    = WSA_DB::table( 'user_ads' );
        $sql    = "SELECT slot_position FROM `{$ads}`
                   WHERE slot_id = %d AND status = 'active' AND expires_at > %s";
        $params = [ (int) $slot_id, WSA_DB::now() ];

        if ( (int) $exclude_id > 0 ) {
            $sql     .= ' AND id <> %d';
            $params[] = (int) $exclude_id;
        }

        $rows = $wpdb->get_col( $wpdb->prepare( $sql, ...$params ) );
        return array_values( array_unique( array_map( 'intval', (array) $rows ) ) );
    }

    /** 这个位置是不是已经有在线广告了 */
    public static function position_conflict( $slot_id, $position, $exclude_id = 0 ) {
        global $wpdb;

        $ads    = WSA_DB::table( 'user_ads' );
        $sql    = "SELECT COUNT(*) FROM `{$ads}`
                   WHERE slot_id = %d AND slot_position = %d AND status = 'active' AND expires_at > %s";
        $params = [ (int) $slot_id, (int) $position, WSA_DB::now() ];

        if ( (int) $exclude_id > 0 ) {
            $sql     .= ' AND id <> %d';
            $params[] = (int) $exclude_id;
        }

        return (int) $wpdb->get_var( $wpdb->prepare( $sql, ...$params ) ) > 0;
    }

    /* ==================================================================
     * 三、写入：新增 / 修改
     * ================================================================== */

    /**
     * 新增或修改一条广告。
     *
     * @param array $data 见下面的字段说明
     * @return int|WP_Error 成功返回广告 ID，失败返回原因
     */
    public static function save( $data ) {
        global $wpdb;

        $id     = absint( $data['id'] ?? 0 );
        $slot   = WSA_Ad_Slots::get_by_id( absint( $data['slot_id'] ?? 0 ) );
        if ( ! $slot ) {
            return new WP_Error( 'invalid_slot', '请选择一个有效的广告位。' );
        }

        $position = absint( $data['slot_position'] ?? 0 );
        if ( $position < 1 ) {
            return new WP_Error( 'invalid_position', '位置序号必须是 1 或更大的整数。' );
        }

        // 类型只允许图片 / 文字两种；写错就按图片处理
        $type = ( ( $data['ad_type'] ?? 'image' ) === 'text' ) ? 'text' : 'image';

        $image_url = trim( (string) ( $data['image_url'] ?? '' ) );
        $text      = trim( (string) ( $data['text_content'] ?? '' ) );
        $link      = trim( (string) ( $data['link_url'] ?? '' ) );
        $note      = trim( (string) ( $data['admin_note'] ?? '' ) );
        $days      = (int) ( $data['duration'] ?? 0 );

        // ---- 内容校验 ----
        if ( $type === 'image' && $image_url === '' ) {
            return new WP_Error( 'missing_image', '图片广告必须填写图片地址。' );
        }
        if ( $type === 'text' && $text === '' ) {
            return new WP_Error( 'missing_text', '文字广告必须填写文字内容。' );
        }

        foreach ( [ '图片地址' => $image_url, '跳转链接' => $link ] as $label => $url ) {
            if ( $url !== '' && ! preg_match( '#^https?://#i', $url ) ) {
                return new WP_Error( 'bad_url', $label . '必须以 http:// 或 https:// 开头。' );
            }
        }

        // ---- 位置冲突校验 ----
        // 同一广告位的同一格，不能同时有两条在线广告；编辑自己时要先把自己排除掉。
        if ( self::position_conflict( $slot->id, $position, $id ) ) {
            return new WP_Error( 'position_taken', sprintf(
                '「%s」的第 %d 格已经有在线广告了。请换一个位置，或先把那一格上的广告下架。',
                $slot->slot_name,
                $position
            ) );
        }

        $now     = WSA_DB::now();
        $table   = WSA_DB::table( 'user_ads' );
        $row     = [
            'slot_id'       => (int) $slot->id,
            'slot_position' => $position,
            'ad_type'       => $type,
            'image_url'     => $image_url,
            'text_content'  => $text,
            'link_url'      => $link,
            'admin_note'    => $note,
        ];
        $formats = [ '%d', '%d', '%s', '%s', '%s', '%s', '%s' ];

        /* ---------------- 修改已存在的广告 ---------------- */
        if ( $id ) {
            $existing = self::get( $id );
            if ( ! $existing ) {
                return new WP_Error( 'not_found', '要修改的广告不存在，可能已经被删除了。' );
            }

            // 只有站长自己添加的广告才允许改投放天数。
            // 用户买的广告归用户，改它的到期时间等于私自改用户的付费权益；内容可以帮用户修正。
            if ( $existing->source === self::SOURCE_ADMIN ) {
                $row['duration']   = $days;
                $row['expires_at'] = self::expiry_from_days( $days, $now );
                $formats[]         = '%d';
                $formats[]         = '%s';
            }

            $ok = $wpdb->update( $table, $row, [ 'id' => (int) $id ], $formats, [ '%d' ] );
            if ( $ok === false ) {
                WSA_Payment::log( '广告保存失败', [ 'id' => $id, 'db_error' => $wpdb->last_error ] );
                return new WP_Error( 'db_error', '保存失败：' . $wpdb->last_error );
            }
            return (int) $id;
        }

        /* ---------------- 新增（一律记为“站长添加”） ---------------- */
        $row['order_id']   = 0;
        $row['user_id']    = 0;
        $row['source']     = self::SOURCE_ADMIN;
        $row['status']     = 'active';
        $row['duration']   = $days;
        $row['started_at'] = $now;
        $row['expires_at'] = self::expiry_from_days( $days, $now );
        $row['created_at'] = $now;
        $formats           = array_merge( $formats, [ '%d', '%d', '%s', '%s', '%d', '%s', '%s', '%s' ] );

        $ok = $wpdb->insert( $table, $row, $formats );
        if ( ! $ok ) {
            WSA_Payment::log( '广告新增失败', [ 'db_error' => $wpdb->last_error ] );
            return new WP_Error( 'db_error', '新增失败：' . $wpdb->last_error );
        }

        return (int) $wpdb->insert_id;
    }

    /* ==================================================================
     * 四、上架 / 下架 / 删除
     * ================================================================== */

    /**
     * 上架或下架一条广告。
     *
     * 上架时如果这条广告已经过期，会自动续期 —— 否则“上架”了也马上就消失，
     * 站长会以为按钮坏了。续期天数用它本来记录的投放天数，没有就按 30 天。
     *
     * @param int    $id
     * @param string $status 'active'（上架）或 'paused'（下架）
     * @return array|WP_Error 成功返回 [ status, renewed, days ]，失败返回原因
     */
    public static function set_status( $id, $status ) {
        global $wpdb;

        $ad = self::get( $id );
        if ( ! $ad ) {
            return new WP_Error( 'not_found', '广告不存在，可能已经被删除了。' );
        }

        $table = WSA_DB::table( 'user_ads' );

        /* ---- 下架 ---- */
        if ( $status === 'paused' ) {
            if ( $ad->status === 'paused' ) {
                return [ 'status' => 'paused', 'renewed' => false, 'days' => 0 ];
            }
            $wpdb->update( $table, [ 'status' => 'paused' ], [ 'id' => (int) $ad->id ], [ '%s' ], [ '%d' ] );
            return [ 'status' => 'paused', 'renewed' => false, 'days' => 0 ];
        }

        if ( $status !== 'active' ) {
            return new WP_Error( 'bad_status', '不支持的状态。' );
        }

        /* ---- 上架 ---- */
        // 先看那一格有没有被别的在线广告占着 —— 占着就上不了，否则会出现两条广告叠在一格
        if ( self::position_conflict( $ad->slot_id, $ad->slot_position, $ad->id ) ) {
            return new WP_Error( 'position_taken', sprintf(
                '无法上架：第 %d 格已经被另一条在线广告占用。请先把那条下架，或把本条广告改到别的格子。',
                $ad->slot_position
            ) );
        }

        $now     = WSA_DB::now();
        $row     = [ 'status' => 'active' ];
        $formats = [ '%s' ];
        $renewed = false;
        $days    = 0;

        // 已经过期 → 顺手续期，不然上架等于没上
        if ( strtotime( $ad->expires_at . ' UTC' ) <= strtotime( $now . ' UTC' ) ) {
            $days              = (int) $ad->duration > 0 ? (int) $ad->duration : self::DEFAULT_RENEW_DAYS;
            $row['duration']   = $days;
            $row['started_at'] = $now;
            $row['expires_at'] = self::expiry_from_days( $days, $now );
            $formats[]         = '%d';
            $formats[]         = '%s';
            $formats[]         = '%s';
            $renewed           = true;
        }

        $wpdb->update( $table, $row, [ 'id' => (int) $ad->id ], $formats, [ '%d' ] );

        return [ 'status' => 'active', 'renewed' => $renewed, 'days' => $days ];
    }

    /**
     * 删除一条广告（从数据库里彻底移除，不可恢复）。
     *
     * 注意：如果这条广告来自用户付费购买，删除后订单记录仍然保留（钱不退），
     * 只是广告不再展示。后台按钮上会提醒站长这一点。
     */
    public static function delete( $id ) {
        global $wpdb;

        $ad = self::get( $id );
        if ( ! $ad ) {
            return new WP_Error( 'not_found', '广告不存在，可能已经被删除了。' );
        }

        $ok = $wpdb->delete( WSA_DB::table( 'user_ads' ), [ 'id' => (int) $ad->id ], [ '%d' ] );
        if ( ! $ok ) {
            return new WP_Error( 'db_error', '删除失败：' . $wpdb->last_error );
        }

        WSA_Payment::log( '广告已删除', [
            'ad_id'  => (int) $ad->id,
            'slot'   => (int) $ad->slot_id,
            'pos'    => (int) $ad->slot_position,
            'source' => $ad->source,
        ] );

        return true;
    }

    /* ==================================================================
     * 五、小工具
     * ================================================================== */

    /**
     * 由“投放天数”算出到期时间。填 0 或负数表示永久有效。
     *
     * 时间运算说明：$from 是站点时区的“墙上时间”字符串（如 2026-09-26 16:12:31）。
     * 这里做的是纯时间加减，与服务器时区无关，所以按 UTC 解释、再按 UTC 输出，
     * 结果依然是同一个时区的墙上时间。
     */
    private static function expiry_from_days( $days, $from ) {
        $days = (int) $days;
        if ( $days <= 0 ) {
            return self::NEVER_EXPIRES;
        }
        return gmdate( 'Y-m-d H:i:s', strtotime( $from . ' UTC' ) + $days * DAY_IN_SECONDS );
    }

    /** 给后台显示用：这条广告还能放多久 / 为什么不在线 */
    public static function expiry_text( $ad ) {
        $effective = self::effective_status( $ad );

        if ( $effective === 'paused' ) {
            return '已下架（前台不显示，位置已释放）';
        }

        if ( $ad->expires_at === self::NEVER_EXPIRES ) {
            return '永久有效';
        }

        $left = strtotime( $ad->expires_at . ' UTC' ) - strtotime( WSA_DB::now() . ' UTC' );
        if ( $left <= 0 ) {
            return $ad->expires_at . '（已过期）';
        }

        $days = (int) floor( $left / DAY_IN_SECONDS );
        $hint = $days >= 1 ? "还剩 {$days} 天" : '不足 1 天';

        return $ad->expires_at . '（' . $hint . '）';
    }
}
