<?php
/**
 * 支付：付款方式与支付通道的注册表、自动选路、发起支付与回调处理
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

/**
 * 支付调度中心。
 *
 * 这里把两个容易混淆的概念拆开：
 *
 *   1) 付款方式（pay_type）—— 用户在收银台看到并选择的，例如「支付宝」「微信支付」。
 *      它只描述“用户想用什么付款”，与后台用哪家服务商收款无关。
 *
 *   2) 支付通道（channel）—— 后台真正对接的第三方接口，例如「支付宝官方直连」「易支付」。
 *      它才决定代码去调用哪个接口、用哪套密钥。
 *
 * 两者是多对多关系：
 *   - 一个付款方式可以由多个通道承接（支付宝既能走支付宝官方，也能走易支付）；
 *   - 一个通道可以支持多个付款方式（易支付同时支持支付宝、微信、QQ 钱包）。
 *
 * 因此下单时的流程是：用户选付款方式 → 系统按通道优先级自动挑一个可用通道 → 调用该通道接口。
 * 优先级规则：数字越小越优先，支付宝官方（10）优先于易支付（20）。
 *
 * 扩展方式：用 wsa_payment_types / wsa_payment_channels 两个过滤器增删条目，
 * 再按 gateway_{handler}() 的命名写一个发起支付的方法即可，其余逻辑无需改动。
 */
class WSA_Payment {

    /** 通道优先级常量：数值越小越优先。支付宝官方先于易支付 */
    const PRIORITY_ALIPAY = 10;
    const PRIORITY_EPAY   = 20;

    /* ==================================================================
     * 一、两张注册表：付款方式 与 支付通道
     * ================================================================== */

    /**
     * 付款方式字典：内部标识 => 界面显示名。
     * 键会存进订单表的 payment_method 字段，改动前请先确认历史数据。
     */
    public static function payment_types() {
        return apply_filters( 'wsa_payment_types', [
            'alipay' => '支付宝',
            'wechat' => '微信支付',
            'qq'     => 'QQ 钱包',
        ] );
    }

    /**
     * 支付通道注册表。每个通道包含：
     *   label    后台显示的名字
     *   priority 优先级，数字越小越优先（决定多个通道都能用时选谁）
     *   handler  方法后缀，对应 gateway_{handler}() / notify_{handler}() / verify_{handler}_sign()
     *   check    配置就绪检查方法名，返回 true 表示这个通道可以对外提供服务
     *   types    支持的付款方式：付款方式 => 该通道协议要求的 type 参数值
     *
     * 想新增通道（比如微信官方直连），只要在这里加一项 + 写一个 gateway_xxx() 即可。
     */
    public static function channels() {
        return apply_filters( 'wsa_payment_channels', [
            'alipay' => [
                'label'    => '支付宝官方',
                'priority' => self::PRIORITY_ALIPAY,
                'handler'  => 'alipay',
                'check'    => 'alipay_is_configured',
                // 支付宝电脑网站支付只有一个产品码，固定走 电脑网站支付
                'types'    => [ 'alipay' => 'FAST_INSTANT_TRADE_PAY' ],
            ],
            'epay' => [
                'label'    => '易支付',
                'priority' => self::PRIORITY_EPAY,
                'handler'  => 'epay',
                'check'    => 'epay_is_configured',
                'types'    => self::epay_type_map(),
            ],
        ] );
    }

    /**
     * 易支付协议本身支持哪些付款方式（与后台勾选无关，用于后台渲染复选框）。
     * 右侧是该付款方式在易支付接口里对应的 type 参数值。
     */
    public static function epay_supported_types() {
        return [
            'alipay' => 'alipay',
            'wechat' => 'wxpay',
            'qq'     => 'qqpay',
        ];
    }

    /**
     * 易支付实际接管的付款方式。
     * 后台可以勾选「本商户开通了哪些」，没勾过的老配置默认给支付宝 + 微信，保证升级后能正常用。
     */
    private static function epay_type_map() {
        $config = get_option( 'wsa_epay_config', [] );
        $picked = isset( $config['types'] )
            ? (array) $config['types']
            : [ 'alipay', 'wechat' ];

        $supported = self::epay_supported_types();
        $map       = [];
        foreach ( $picked as $type ) {
            $type = sanitize_key( $type );
            if ( isset( $supported[ $type ] ) ) {
                $map[ $type ] = $supported[ $type ];
            }
        }
        return $map;
    }

    /** 本商户在易支付里开通了哪几种付款方式，返回协议里的 type 值数组，如 [ 'alipay', 'wxpay' ] */
    public static function epay_enabled_type_codes() {
        return array_values( self::epay_type_map() );
    }

    /* ==================================================================
     * 二、可用性判断与选择逻辑
     * ================================================================== */

    /** 支付宝官方是否已启用且参数填齐 */
    public static function alipay_is_configured() {
        $config  = get_option( 'wsa_alipay_config', [] );
        // 老版本配置里没有 enabled 字段，默认视为启用，避免升级后支付方式突然消失
        $enabled = ! isset( $config['enabled'] ) ? true : ! empty( $config['enabled'] );
        return $enabled && ! empty( $config['app_id'] ) && ! empty( $config['private_key'] );
    }

    /** 易支付是否已启用、参数填齐，且至少开通了一种付款方式 */
    public static function epay_is_configured() {
        $config  = get_option( 'wsa_epay_config', [] );
        $enabled = ! isset( $config['enabled'] ) ? true : ! empty( $config['enabled'] );
        if ( ! $enabled || empty( $config['api_url'] ) || empty( $config['pid'] ) || empty( $config['key'] ) ) {
            return false;
        }
        // 一个付款方式都没开通，这个通道等于没用，不对外暴露
        return self::epay_type_map() !== [];
    }

    /** 某个通道当前是否可用 */
    public static function channel_is_available( $channel ) {
        $channels = self::channels();
        if ( ! isset( $channels[ $channel ] ) ) return false;

        $check = isset( $channels[ $channel ]['check'] ) ? $channels[ $channel ]['check'] : '';
        if ( ! $check || ! method_exists( __CLASS__, $check ) ) return false;

        return (bool) self::$check();
    }

    /**
     * 能承接某个付款方式的可用通道，按优先级从高到低排列。
     * 返回 [ 通道key => 通道配置 ]，空数组表示没人能接。
     */
    public static function channels_for( $pay_type ) {
        $pay_type = sanitize_key( $pay_type );
        $result   = [];

        foreach ( self::channels() as $key => $channel ) {
            if ( ! self::channel_is_available( $key ) ) continue;
            if ( ! isset( $channel['types'][ $pay_type ] ) ) continue;
            $result[ $key ] = $channel;
        }

        // 按优先级排序；优先级相同时按通道名排序，保证结果稳定可预期
        uksort( $result, function ( $a, $b ) use ( $result ) {
            $pa = (int) $result[ $a ]['priority'];
            $pb = (int) $result[ $b ]['priority'];
            return $pa === $pb ? strcmp( $a, $b ) : ( $pa - $pb );
        } );

        return $result;
    }

    /**
     * 为某个付款方式自动挑选通道。
     * 这是「支付宝官方优先、其次易支付」这条规则的唯一实现处。
     *
     * @return string 通道 key；没有任何通道可用时返回空字符串
     */
    public static function resolve_channel( $pay_type ) {
        $list = self::channels_for( $pay_type );
        if ( ! $list ) return '';

        $keys = array_keys( $list );
        return $keys[0];
    }

    /**
     * 用户端可选的付款方式：付款方式标识 => 显示名。
     * 只要有一个可用通道能承接它，就出现在这里——保证「页面能选的」和「系统能调通的」完全一致。
     */
    public static function available_methods() {
        $out = [];
        foreach ( self::payment_types() as $type => $label ) {
            if ( self::resolve_channel( $type ) !== '' ) {
                $out[ $type ] = $label;
            }
        }
        return $out;
    }

    /**
     * 后台自检用：每个付款方式最终会走哪个通道。
     * 返回 [ pay_type => [ 'label', 'picked', 'candidates' ] ]
     */
    public static function routing_table() {
        $types = self::payment_types();
        $rows  = [];

        foreach ( $types as $type => $label ) {
            $candidates = [];
            foreach ( self::channels_for( $type ) as $key => $channel ) {
                $candidates[ $key ] = $channel['label'];
            }
            $rows[ $type ] = [
                'label'      => $label,
                'picked'     => self::resolve_channel( $type ),
                'candidates' => $candidates,
            ];
        }

        return $rows;
    }

    /** 通道显示名 */
    public static function channel_label( $channel ) {
        $channels = self::channels();
        return isset( $channels[ $channel ] ) ? $channels[ $channel ]['label'] : $channel;
    }

    /** 付款方式显示名 */
    public static function type_label( $pay_type ) {
        $types = self::payment_types();
        return isset( $types[ $pay_type ] ) ? $types[ $pay_type ] : $pay_type;
    }

    /* ==================================================================
     * 三、发起支付：按付款方式路由到对应通道
     * ================================================================== */

    /**
     * 发起支付。
     *
     * @param string $order_no 本站订单号
     * @param string $pay_type 用户选择的付款方式（alipay / wechat / ...）
     * @param string $channel  指定通道；传空则按优先级自动选择
     * @return array {redirect: string} 或 {error: string}
     */
    public static function request_payment( $order_no, $pay_type, $channel = '' ) {
        $order = WSA_Orders::get_by_order_no( $order_no );
        if ( ! $order ) return [ 'error' => '订单不存在' ];
        if ( $order->status !== 'pending' ) return [ 'error' => '订单状态异常' ];

        $pay_type = sanitize_key( $pay_type );
        if ( ! isset( self::payment_types()[ $pay_type ] ) ) {
            return [ 'error' => '不支持的支付方式' ];
        }

        // 没指定通道就自动挑，规则与前端展示用的完全是同一套
        $channel = $channel ? sanitize_key( $channel ) : self::resolve_channel( $pay_type );

        $channels = self::channels();
        if ( ! $channel || ! isset( $channels[ $channel ] ) ) {
            return [ 'error' => '该支付方式当前不可用' ];
        }
        if ( ! self::channel_is_available( $channel ) ) {
            return [ 'error' => '该支付方式当前不可用' ];
        }
        if ( ! isset( $channels[ $channel ]['types'][ $pay_type ] ) ) {
            return [ 'error' => '该支付通道不支持所选支付方式' ];
        }

        $type_code = $channels[ $channel ]['types'][ $pay_type ];
        $handler   = $channels[ $channel ]['handler'];
        $method    = 'gateway_' . $handler;

        if ( ! method_exists( __CLASS__, $method ) ) {
            return [ 'error' => '支付通道未实现：' . $channel ];
        }

        return self::$method( $order, $type_code, $channel );
    }

    /* ==================================================================
     * 四、各通道的发起支付实现
     * ================================================================== */

    /** 支付宝官方（电脑网站支付）。$type_code 即产品码 */
    private static function gateway_alipay( $order, $type_code, $channel ) {
        $config = get_option( 'wsa_alipay_config', [] );
        if ( empty( $config['app_id'] ) || empty( $config['private_key'] ) ) {
            return [ 'error' => '支付宝未配置' ];
        }

        $biz = [
            'out_trade_no' => $order->order_no,
            'total_amount' => number_format( $order->amount, 2, '.', '' ),
            'subject'      => '广告位购买 - ' . $order->order_no,
            'product_code' => $type_code ? $type_code : 'FAST_INSTANT_TRADE_PAY',
        ];

        $params = [
            'app_id'      => $config['app_id'],
            'method'      => 'alipay.trade.page.pay',
            'format'      => 'JSON',
            'charset'     => 'utf-8',
            'sign_type'   => 'RSA2',
            'timestamp'   => self::beijing_time(),
            'version'     => '1.0',
            'notify_url'  => home_url( '/wsa-notify/' . $channel ),
            'return_url'  => home_url( '/wsa-return/' . $channel ),
            'biz_content' => wp_json_encode( $biz ),
        ];

        $private_key = self::load_private_key( $config['private_key'] );
        if ( ! $private_key ) {
            return [ 'error' => '应用私钥格式不正确（应为 RSA 私钥，PKCS#8 或 PKCS#1 均可）' ];
        }

        $signature = '';
        if ( ! openssl_sign( self::build_sign_string( $params ), $signature, $private_key, OPENSSL_ALGO_SHA256 ) ) {
            return [ 'error' => '生成签名失败' ];
        }

        $params['sign'] = base64_encode( $signature );

        return [ 'redirect' => 'https://openapi.alipay.com/gateway.do?' . http_build_query( $params ) ];
    }

    /* ------------------------------------------------------------------
     * 易支付：两种接口形态都要能跑
     *
     * 各家“易支付”服务商的接口并不完全一样，市面上主要有两代：
     *
     *   A. 收银台接口（新一代，如网程PAY 的 mapi.php）
     *      流程：服务器 POST 过去 → 服务商返回 JSON（code / msg / payurl）→ 我们拿到 payurl。
     *      好处：配置不对时它会直接返回一句人话错误，我们能把这句话原样告诉用户。
     *
     *   B. 页面跳转接口（老一代，submit.php）
     *      流程：把参数拼在网址后面，直接把用户的浏览器送过去。
     *      坏处：出错时报错页面在服务商那边，本站看不见，用户只会看到一片乱码般的 JSON。
     *
     * 插件默认「自动」：优先走 A；如果服务商没有 mapi.php（返回的不是 JSON），
     * 自动退回 B，这样无论新老服务商都能用。
     * ------------------------------------------------------------------ */

    /** 易支付的接口模式：auto（自动）/ api（只用收银台接口）/ page（只用页面跳转） */
    public static function epay_mode() {
        $config = get_option( 'wsa_epay_config', [] );
        $mode   = isset( $config['mode'] ) ? sanitize_key( $config['mode'] ) : 'auto';
        return in_array( $mode, [ 'auto', 'api', 'page' ], true ) ? $mode : 'auto';
    }

    /**
     * 由站长填的「接口地址」推导出两个真正的接口地址。
     *
     * 站长可能这样填（都兼容）：
     *    https://pay.xxx.com            → base=https://pay.xxx.com
     *    https://pay.xxx.com/           → 同上
     *    https://pay.xxx.com/mapi.php   → 同上（自动去掉文件名）
     *    https://pay.xxx.com/submit.php → 同上
     *    https://pay.xxx.com/api/       → base=https://pay.xxx.com/api
     *
     * @return array {base, api, page}
     */
    public static function epay_endpoints( $api_url = null ) {
        if ( $api_url === null ) {
            $config  = get_option( 'wsa_epay_config', [] );
            $api_url = isset( $config['api_url'] ) ? $config['api_url'] : '';
        }

        $api_url = rtrim( trim( (string) $api_url ), '/' );
        // 去掉结尾的 xxx.php 文件名，只保留根地址
        $base = preg_replace( '#/[^/]+\.php$#i', '', $api_url );
        $base = rtrim( (string) $base, '/' );

        if ( $base === '' || ! preg_match( '#^https?://#i', $base ) ) {
            return [ 'base' => '', 'api' => '', 'page' => '' ];
        }

        return [
            'base' => $base,
            'api'  => $base . '/mapi.php',
            'page' => $base . '/submit.php',
        ];
    }

    /** 商户「通道 ID」的值：新版字段 tdid，兼容上一版的 cid */
    private static function epay_channel_id() {
        $config = get_option( 'wsa_epay_config', [] );
        if ( ! empty( $config['tdid'] ) ) return (string) $config['tdid'];
        if ( ! empty( $config['cid'] ) )  return (string) $config['cid'];
        return '';
    }

    /**
     * 通道 ID 在请求里的参数名。
     * 网程PAY 等平台用 tdid；部分易支付服务商用 cid。站长可在后台选。
     */
    private static function epay_channel_id_param() {
        $config = get_option( 'wsa_epay_config', [] );
        $param  = isset( $config['tdid_param'] ) ? sanitize_key( $config['tdid_param'] ) : 'tdid';
        return $param === 'cid' ? 'cid' : 'tdid';
    }

    /**
     * 构造易支付下单参数（含 MD5 签名）。
     * 正式下单与后台「接口自检」共用这一个方法，保证自检结果能代表真实下单行为。
     */
    private static function build_epay_params( $channel, $type_code, $order_no, $name, $money ) {
        $config = get_option( 'wsa_epay_config', [] );

        $params = [
            'pid'          => $config['pid'],
            'type'         => $type_code,
            'out_trade_no' => $order_no,
            'notify_url'   => home_url( '/wsa-notify/' . $channel ),
            'return_url'   => home_url( '/wsa-return/' . $channel ),
            'name'         => $name,
            'money'        => number_format( (float) $money, 2, '.', '' ),
        ];

        // 部分服务商要求指定「商户通道 ID」来选定具体收款通道。留空时完全不传这个参数，
        // 对不需要它的服务商没有任何影响。
        $tdid = self::epay_channel_id();
        if ( $tdid !== '' ) {
            $params[ self::epay_channel_id_param() ] = $tdid;
        }

        $params['sign']      = self::epay_sign( $params, isset( $config['key'] ) ? $config['key'] : '' );
        $params['sign_type'] = 'MD5';

        return $params;
    }

    /**
     * 易支付签名：剔除 sign / sign_type → 按参数名字母升序 → key=value 用 & 连接 → 末尾拼商户密钥 → MD5。
     * 与网程PAY 官方文档给的 PHP 示例完全一致。
     */
    private static function epay_sign( $params, $key ) {
        unset( $params['sign'], $params['sign_type'] );
        return md5( self::build_sign_string( $params ) . $key );
    }

    /**
     * 易支付发起支付。
     * $type_code 决定用户实际用什么付款：alipay / wxpay / qqpay
     */
    private static function gateway_epay( $order, $type_code, $channel ) {
        $config = get_option( 'wsa_epay_config', [] );
        if ( empty( $config['api_url'] ) || empty( $config['pid'] ) || empty( $config['key'] ) ) {
            return [ 'error' => '易支付未配置' ];
        }

        $eps  = self::epay_endpoints( $config['api_url'] );
        $mode = self::epay_mode();

        if ( $eps['base'] === '' ) {
            return [ 'error' => '易支付接口地址格式不正确：' . $config['api_url'] ];
        }

        $name  = '广告位购买-' . $order->order_no;
        $money = $order->amount;

        // ---------- 路线 A：收银台接口（推荐） ----------
        if ( $mode !== 'page' ) {
            $result = self::epay_create_order( $eps['api'], $channel, $type_code, $order->order_no, $name, $money );

            if ( ! empty( $result['payurl'] ) ) {
                $payurl = $result['payurl'];

                // 先由服务器探一次收银台：配置不对时它会直接回一段 JSON 错误，
                // 这样我们能在自己的弹窗里把原因说清楚，而不是把用户扔到一个满是 JSON 的空白页。
                $precheck = self::epay_cashier_precheck( $payurl );
                if ( ! empty( $precheck['blocker'] ) ) {
                    self::log( '易支付收银台预检未通过', [
                        'order_no' => $order->order_no,
                        'type'     => $type_code,
                        'reason'   => $precheck['blocker'],
                    ] );
                    return [ 'error' => $precheck['blocker'] ];
                }
                if ( ! empty( $precheck['payurl'] ) ) {
                    $payurl = $precheck['payurl'];
                }

                self::log( '易支付发起支付成功', [
                    'order_no' => $order->order_no,
                    'type'     => $type_code,
                    'channel'  => $channel,
                    'mode'     => 'api',
                ] );

                return [ 'redirect' => $payurl ];
            }

            // 服务商明确给出了失败原因，直接原样带回（这就是排查时最需要的那句话）
            if ( ! empty( $result['error'] ) ) {
                self::log( '易支付下单被拒绝', [
                    'order_no' => $order->order_no,
                    'type'     => $type_code,
                    'error'    => $result['error'],
                ] );
                return [ 'error' => $result['error'] ];
            }

            // 服务商没有 mapi.php（不是 JSON 响应）→ 老式易支付，自动改走页面跳转
            self::log( '易支付收银台接口不可用，自动改用页面跳转', [
                'order_no' => $order->order_no,
                'url'      => $eps['api'],
            ] );

            if ( $mode === 'api' ) {
                return [ 'error' => '服务商没有收银台接口（mapi.php）。请到「支付设置 → 易支付 → 接口模式」改为“页面跳转”后重试。' ];
            }
        }

        // ---------- 路线 B：页面跳转 ----------
        $params = self::build_epay_params( $channel, $type_code, $order->order_no, $name, $money );

        self::log( '易支付发起支付（页面跳转）', [
            'order_no' => $order->order_no,
            'type'     => $type_code,
            'channel'  => $channel,
            'mode'     => 'page',
        ] );

        return [ 'redirect' => $eps['page'] . '?' . http_build_query( $params ) ];
    }

    /**
     * 调用易支付的收银台接口（mapi.php）下单，返回 payurl。
     *
     * @return array 三种可能：
     *   ['payurl' => '...']  成功，拿到收银台地址
     *   ['error'  => '...']  服务商明确拒绝，error 就是它给的原话
     *   ['not_json' => true] 这个地址返回的不是 JSON，说明该服务商没有这个接口
     */
    private static function epay_create_order( $url, $channel, $type_code, $order_no, $name, $money ) {
        if ( $url === '' ) {
            return [ 'not_json' => true ];
        }

        $params = self::build_epay_params( $channel, $type_code, $order_no, $name, $money );

        $response = wp_remote_post( $url, [
            'timeout' => 20,
            'body'    => $params,
            'headers' => [ 'Accept' => 'application/json' ],
        ] );

        if ( is_wp_error( $response ) ) {
            return [ 'error' => '连接易支付失败：' . $response->get_error_message() ];
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $body   = (string) wp_remote_retrieve_body( $response );
        $json   = json_decode( trim( $body ), true );

        if ( ! is_array( $json ) ) {
            // 不是 JSON：可能是 404 页面，也可能是这家的 mapi 直接吐出收银台 HTML
            self::log( '易支付收银台接口返回非 JSON', [
                'url'     => $url,
                'status'  => $status,
                'excerpt' => substr( wp_strip_all_tags( $body ), 0, 200 ),
            ] );
            return [ 'not_json' => true, 'status' => $status ];
        }

        $code = isset( $json['code'] ) ? (int) $json['code'] : 0;
        $msg  = self::epay_clean_msg( isset( $json['msg'] ) ? $json['msg'] : '' );

        if ( $code === 1 && ! empty( $json['payurl'] ) ) {
            return [ 'payurl' => (string) $json['payurl'], 'msg' => $msg ];
        }

        return [ 'error' => $msg !== '' ? $msg : '易支付下单失败（服务商没有返回支付地址）' ];
    }

    /**
     * 收银台预检：先用服务器看一眼 payurl。
     *
     * 网程PAY 这类平台在「商户没开通对应通道」时，收银台地址返回的不是网页而是一段 JSON 错误。
     * 如果直接把用户送过去，用户看到的是一屏乱码，站长也拿不到任何线索。
     * 这里先取一次：
     *   - 返回 JSON 错误 → 把 msg 原样带出来，在站内弹窗提示，用户不会被扔到服务商页面
     *   - 返回 JSON 且又给了新 payurl → 用新的地址
     *   - 返回正常网页 → 什么都不做，照常跳转
     *
     * 判断标准很保守：只有「响应体是 JSON」时才干预，正常收银台页面一律不拦。
     *
     * @return array {blocker: string} 或 {payurl: string}，都没有表示正常
     */
    private static function epay_cashier_precheck( $payurl ) {
        if ( ! preg_match( '#^https?://#i', (string) $payurl ) ) {
            return [];
        }

        $response = wp_remote_get( $payurl, [
            'timeout'     => 15,
            'redirection' => 3,
        ] );

        if ( is_wp_error( $response ) ) {
            // 本站连不上服务商收银台很正常（服务商可能只允许买家网络访问），不做拦截
            return [];
        }

        $body = trim( (string) wp_remote_retrieve_body( $response ) );
        $json = json_decode( $body, true );

        if ( ! is_array( $json ) ) {
            return [];   // 是正常页面，说明配置没问题
        }

        $code = isset( $json['code'] ) ? (int) $json['code'] : 0;
        if ( $code === 1 && ! empty( $json['payurl'] ) ) {
            return [ 'payurl' => (string) $json['payurl'] ];
        }

        $msg = self::epay_clean_msg( isset( $json['msg'] ) ? $json['msg'] : '' );
        return [ 'blocker' => $msg !== '' ? $msg : '易支付收银台暂时无法打开，请稍后重试或联系服务商。' ];
    }

    /**
     * 清理服务商返回的提示文字：
     * 网程PAY 的习惯是在句尾重复贴品牌名（形如「…-网程PAY-网程PAY」），去掉重复的那一份。
     */
    private static function epay_clean_msg( $msg ) {
        $msg = trim( (string) $msg );
        if ( $msg === '' ) return '';
        return preg_replace( '#(-[^\-，,]{2,15})\1+\s*$#u', '$1', $msg );
    }

    /* ==================================================================
     * 四之二、易支付接口自检（用来排查“微信/支付宝调不起来”）
     * ================================================================== */

    /**
     * 用一笔 0.01 元的探测订单，真实请求一次易支付服务商，把对方的原话带回来。
     *
     * 为什么需要它：插件只是把浏览器“送”到易支付的收银台，
     * 真正决定“能不能用微信付款”的是服务商那一侧，
     * 它的报错只显示在服务商返回的页面上，插件这边看不见（浏览器已经离开本站了）。
     * 自检就是把那个页面提前取回来，直接看真因。
     *
     * 注意：探测只发起请求、不会自动付款，也不会影响本站订单数据。
     *
     * @param string $only_type 只探测某一种付款方式（协议 type 值）；留空则探测本商户开通的全部
     * @return array { ok:bool, error?:string, types:array }
     */
    public static function probe_epay( $only_type = '' ) {
        $config = get_option( 'wsa_epay_config', [] );

        if ( empty( $config['api_url'] ) || empty( $config['pid'] ) || empty( $config['key'] ) ) {
            return [ 'ok' => false, 'error' => '易支付参数未填写完整（接口地址 / 商户 ID / 商户密钥）。' ];
        }

        $eps = self::epay_endpoints( $config['api_url'] );
        if ( $eps['base'] === '' ) {
            return [ 'ok' => false, 'error' => '接口地址格式不正确：' . $config['api_url'] ];
        }

        // 要探测哪几种付款方式
        $codes = self::epay_enabled_type_codes();
        if ( $only_type !== '' ) {
            $codes = [ $only_type ];
        }
        if ( ! $codes ) {
            return [ 'ok' => false, 'error' => '还没勾选任何「支持的付款方式」，请先在易支付配置里勾选后再自检。' ];
        }

        $type_labels = [];
        foreach ( $codes as $code ) {
            $type_labels[ $code ] = self::epay_type_label( $code );
        }

        $tests = [];
        foreach ( $codes as $code ) {
            // 每次单号都不同，避免服务商对重复单号直接回“订单已存在”
            $order_no = 'WSAPROBE' . gmdate( 'YmdHis' ) . wp_rand( 1000, 9999 );
            $tests[ $code ] = self::probe_epay_one( $eps, $code, $order_no );
        }

        return [
            'ok'     => true,
            'base'   => $eps['base'],
            'api'    => $eps['api'],
            'page'   => $eps['page'],
            'labels' => $type_labels,
            'tests'  => $tests,
        ];
    }

    /** 探测单个付款方式：收银台接口 + 页面跳转接口各问一次 */
    private static function probe_epay_one( $eps, $type_code, $order_no ) {
        $out = [];

        // ① 收银台接口 mapi.php（平台推荐，POST）
        $result  = self::epay_create_order( $eps['api'], 'epay', $type_code, $order_no, '接口自检', 0.01 );
        $check   = [
            'name'    => '收银台接口 mapi.php',
            'url'     => $eps['api'],
            'status'  => '',
            'code'    => '',
            'verdict' => '',
            'raw'     => '',
        ];

        if ( ! empty( $result['payurl'] ) ) {
            $check['status'] = '';
            $check['code']   = 1;
            $check['raw']    = 'payurl = ' . $result['payurl'];

            // 再顺着 payurl 探一次，这才是买家真正会看到的页面
            $pre = self::epay_cashier_precheck( $result['payurl'] );
            if ( ! empty( $pre['blocker'] ) ) {
                $check['verdict'] = '接口通了，但收银台拒绝了这个付款方式';
                $check['raw']    .= "\n收银台返回：" . $pre['blocker'];
            } else {
                $check['verdict'] = '正常：能下单，收银台也可打开';
            }
        } elseif ( ! empty( $result['error'] ) ) {
            $check['status']  = '';
            $check['code']    = 0;
            $check['verdict'] = '接口通了，但被服务商拒绝';
            $check['raw']     = $result['error'];
        } else {
            $check['status']  = isset( $result['status'] ) ? (int) $result['status'] : '';
            $check['verdict'] = '这个服务商没有 mapi.php（返回的不是接口数据），插件会自动改用页面跳转';
        }
        $out['api'] = $check;

        // ② 页面跳转接口 submit.php（老一代做法，GET）
        $params  = self::build_epay_params( 'epay', $type_code, $order_no . 'P', '接口自检', 0.01 );
        $page_url = $eps['page'] . '?' . http_build_query( $params );
        $response = wp_remote_get( $page_url, [ 'timeout' => 15, 'redirection' => 3 ] );

        $check2 = [
            'name'    => '页面跳转接口 submit.php',
            'url'     => $eps['page'],
            'status'  => '',
            'code'    => '',
            'verdict' => '',
            'raw'     => '',
        ];

        if ( is_wp_error( $response ) ) {
            $check2['status']  = 0;
            $check2['verdict'] = '连不上：' . $response->get_error_message();
        } else {
            $status = (int) wp_remote_retrieve_response_code( $response );
            $body   = (string) wp_remote_retrieve_body( $response );
            $json   = json_decode( trim( $body ), true );

            $check2['status'] = $status;

            if ( is_array( $json ) ) {
                $code = isset( $json['code'] ) ? (int) $json['code'] : 0;
                $msg  = self::epay_clean_msg( isset( $json['msg'] ) ? $json['msg'] : '' );
                $check2['code'] = $code;
                $check2['raw']  = $msg;

                if ( $code === 1 ) {
                    $check2['verdict'] = ! empty( $json['payurl'] )
                        ? '正常：能下单，并返回了收银台地址'
                        : '接口通了，但没返回支付地址';
                } else {
                    $check2['verdict'] = '被服务商拒绝';
                }
            } elseif ( $status === 404 ) {
                $check2['verdict'] = '这个服务商没有 submit.php（404）';
            } elseif ( trim( $body ) === '' ) {
                $check2['verdict'] = '返回空白内容';
            } else {
                $check2['verdict'] = '返回了网页（不是接口数据）';
                $check2['raw']     = substr( wp_strip_all_tags( $body ), 0, 200 );
            }
        }
        $out['page'] = $check2;

        return $out;
    }

    /** 把易支付的 type 编码翻译成中文，仅用于自检结果展示 */
    public static function epay_type_label( $type_code ) {
        $map = array_flip( self::epay_supported_types() );
        $key = isset( $map[ $type_code ] ) ? $map[ $type_code ] : '';
        $all = self::payment_types();
        return isset( $all[ $key ] ) ? $all[ $key ] : $type_code;
    }

    /**
     * 根据服务商的原话给出人话结论（供后台展示，帮助站长判断该做什么）。
     */
    public static function judge_epay_message( $msg ) {
        $msg = trim( (string) $msg );
        if ( $msg === '' ) return '';

        $plain = strtolower( $msg );

        if ( strpos( $plain, '没有查到可用的支付通道' ) !== false || strpos( $plain, '未开通' ) !== false
             || strpos( $plain, 'not open' ) !== false ) {
            return '商户后台没有开通这个付款方式。请登录易支付商户中心 → 支付通道 → 检查该通道是否已启用，以及它的支付方式是否包含这一种。';
        }
        if ( strpos( $plain, '签名' ) !== false || strpos( $plain, 'sign' ) !== false ) {
            return '签名校验不通过。请核对商户密钥（注意别多复制了空格或换行），并确认商户 ID 填的是本商户的。';
        }
        if ( strpos( $plain, '未绑定' ) !== false || strpos( $plain, '域名' ) !== false || strpos( $plain, 'domain' ) !== false ) {
            return '域名校验不通过。请到易支付商户后台确认本站域名已登记。';
        }
        if ( strpos( $plain, '商户不存在' ) !== false || strpos( $plain, 'pid' ) !== false ) {
            return '商户 ID（pid）不对。请到易支付商户中心 → 支付通道 → API接口信息 核对。';
        }
        if ( strpos( $plain, '金额' ) !== false || strpos( $plain, 'money' ) !== false ) {
            return '金额不符合服务商要求（部分通道有最低金额限制）。';
        }
        if ( strpos( $plain, '订单' ) !== false ) {
            return '这句话是服务商在处理订单时报的错，通常是通道侧的问题：'
                 . '① 该通道没有启用或已欠费；② 码支付类通道要保证手机 APP / 电脑监听软件在线；'
                 . '③ 部分通道有最低金额限制。请登录易支付商户中心 → 订单管理，看这笔探测单的具体状态。';
        }
        return '';
    }

    /* ==================================================================
     * 五、回调入口分发
     * ================================================================== */

    /**
     * 异步通知入口。$channel 来自回调地址里的通道名，例如 /wsa-notify/alipay。
     * 按通道找到对应的 notify_xxx() 处理，新增通道时这里无需改动。
     */
    public static function handle_notify( $channel ) {
        $channels = self::channels();
        if ( ! isset( $channels[ $channel ] ) ) {
            status_header( 404 );
            exit;
        }

        $method = 'notify_' . $channels[ $channel ]['handler'];
        if ( method_exists( __CLASS__, $method ) ) {
            self::$method( $channel );
        }

        status_header( 404 );
        exit;
    }

    /**
     * 同步跳转入口（用户付完款后浏览器跳回来的页面）。
     * 只负责展示结果，不发放权益——权益一律以异步通知为准。
     */
    public static function handle_return( $channel ) {
        $channels = self::channels();
        if ( ! isset( $channels[ $channel ] ) ) {
            wp_die( '无效的支付通道', '支付结果', [ 'response' => 404 ] );
        }

        $handler  = $channels[ $channel ]['handler'];
        $params   = wp_unslash( array_merge( $_GET, $_POST ) );
        $order_no = isset( $params['out_trade_no'] ) ? sanitize_text_field( $params['out_trade_no'] ) : '';

        // 同步返回也可能被伪造，必须验签后才采信。
        // 注意：买家没付款就点了返回，平台只会带几个基础字段、不带签名——这不算“验签失败”，
        // 只当作“尚不能确认支付结果”处理即可。
        $has_sign = ! empty( $params['sign'] );
        $verified = false;
        if ( $has_sign ) {
            $verify_method = 'verify_' . $handler . '_sign';
            $verified      = method_exists( __CLASS__, $verify_method ) ? self::$verify_method( $params ) : false;
            if ( ! $verified ) {
                self::log( "{$channel} 同步返回验签失败", [ 'order_no' => $order_no ] );
            }
        }

        $order = $order_no ? WSA_Orders::get_by_order_no( $order_no ) : null;
        // 只能看自己的订单（管理员除外），防止拿订单号去探测别人的信息
        $own = $order && ( (int) $order->user_id === get_current_user_id() || current_user_can( 'manage_options' ) );

        if ( $verified && $own && $order->status === 'paid' ) {
            $msg = '支付成功，广告已开通！';
        } elseif ( $verified && $own && $order->status === 'pending' ) {
            $msg = '支付结果正在确认中，请稍后刷新查看。';
        } elseif ( $verified && $own && $order->status === 'review' ) {
            $msg = '支付已收到，正在人工核对，请耐心等待。';
        } else {
            $msg = '支付结果已收到，请登录后在订单中查看。';
        }

        $msg .= '<br><br><a href="' . esc_url( home_url( '/' ) ) . '">返回首页</a>';

        wp_die( $msg, '支付结果', [ 'response' => 200 ] );
    }

    /* ==================================================================
     * 六、各通道的回调处理
     * ================================================================== */

    /** 支付宝异步通知 */
    private static function notify_alipay( $channel ) {
        $config = get_option( 'wsa_alipay_config', [] );
        $post   = wp_unslash( $_POST );

        if ( empty( $post['sign'] ) ) {
            self::fail( $channel, '缺少 sign 参数' );
        }
        if ( ! self::verify_alipay_sign( $post ) ) {
            self::fail( $channel, '验签失败' );
        }

        // 商户身份核对：确认这条通知确实是发给本站应用的，而不是别家商户的
        $app_id = isset( $post['app_id'] ) ? (string) $post['app_id'] : '';
        if ( ! empty( $config['app_id'] ) && $app_id !== (string) $config['app_id'] ) {
            self::fail( $channel, 'app_id 不匹配：' . $app_id );
        }

        $trade_status = isset( $post['trade_status'] ) ? $post['trade_status'] : '';
        if ( ! in_array( $trade_status, [ 'TRADE_SUCCESS', 'TRADE_FINISHED' ], true ) ) {
            // 非成功状态直接确认收到，避免平台无意义地重复通知
            echo 'success';
            exit;
        }

        self::settle(
            $channel,
            sanitize_text_field( isset( $post['out_trade_no'] ) ? $post['out_trade_no'] : '' ),
            sanitize_text_field( isset( $post['trade_no'] ) ? $post['trade_no'] : '' ),
            isset( $post['total_amount'] ) ? $post['total_amount'] : null
        );
    }

    /** 易支付异步通知 */
    private static function notify_epay( $channel ) {
        // 易支付不同服务商的实现不一样，有的用 GET 有的用 POST，这里两者都接收
        $params = wp_unslash( array_merge( $_GET, $_POST ) );

        if ( empty( $params['sign'] ) ) {
            self::fail( $channel, '缺少 sign 参数' );
        }
        if ( ! self::verify_epay_sign( $params ) ) {
            self::fail( $channel, '验签失败' );
        }

        // 商户身份核对
        $config = get_option( 'wsa_epay_config', [] );
        $pid    = isset( $params['pid'] ) ? (string) $params['pid'] : '';
        if ( ! empty( $config['pid'] ) && $pid !== (string) $config['pid'] ) {
            self::fail( $channel, 'pid 不匹配：' . $pid );
        }

        $trade_status = isset( $params['trade_status'] ) ? $params['trade_status'] : '';
        if ( $trade_status !== 'TRADE_SUCCESS' ) {
            echo 'success';
            exit;
        }

        self::settle(
            $channel,
            sanitize_text_field( isset( $params['out_trade_no'] ) ? $params['out_trade_no'] : '' ),
            sanitize_text_field( isset( $params['trade_no'] ) ? $params['trade_no'] : '' ),
            isset( $params['money'] ) ? $params['money'] : null
        );
    }

    /* ==================================================================
     * 七、内部工具
     * ================================================================== */

    /**
     * 验签通过后的统一“记账”动作：交给订单模块发放权益，并按需决定是否让平台重试。
     */
    private static function settle( $gateway, $order_no, $trade_no, $amount ) {
        $result = WSA_Orders::mark_paid( $order_no, $trade_no, $amount );

        if ( ! is_wp_error( $result ) ) {
            self::log( "{$gateway} 回调处理成功", [ 'order_no' => $order_no, 'trade_no' => $trade_no ] );
            echo 'success';
            exit;
        }

        $code = $result->get_error_code();
        self::log( "{$gateway} 回调处理失败", [
            'order_no' => $order_no,
            'trade_no' => $trade_no,
            'code'     => $code,
            'message'  => $result->get_error_message(),
        ] );

        // 订单暂时查不到 / 写库失败：可能是瞬时问题，回 fail 让平台稍后重试
        // 金额不符 / 位置冲突：业务上无法自动解决，回 success 停止重试，转由管理员人工处理
        $retryable = in_array( $code, [ 'order_not_found', 'db_error', 'ad_insert_failed' ], true );
        echo $retryable ? 'fail' : 'success';
        exit;
    }

    /** 校验没通过：记录日志并回 fail */
    private static function fail( $gateway, $reason ) {
        self::log( "{$gateway} 回调校验未通过", [ 'reason' => $reason ] );
        echo 'fail';
        exit;
    }

    /** 支付宝验签（RSA2） */
    private static function verify_alipay_sign( $params ) {
        $config = get_option( 'wsa_alipay_config', [] );
        $sign   = isset( $params['sign'] ) ? (string) $params['sign'] : '';
        if ( $sign === '' ) return false;

        $data = $params;
        unset( $data['sign'], $data['sign_type'] );

        $public_key = self::load_public_key( isset( $config['alipay_public_key'] ) ? $config['alipay_public_key'] : '' );
        if ( ! $public_key ) return false;

        return openssl_verify(
            self::build_sign_string( $data ),
            base64_decode( $sign ),
            $public_key,
            OPENSSL_ALGO_SHA256
        ) === 1;
    }

    /** 易支付验签（MD5） */
    private static function verify_epay_sign( $params ) {
        $config = get_option( 'wsa_epay_config', [] );
        $sign   = isset( $params['sign'] ) ? (string) $params['sign'] : '';
        $key    = isset( $config['key'] ) ? (string) $config['key'] : '';
        if ( $sign === '' || $key === '' ) return false;

        return hash_equals( self::epay_sign( $params, $key ), $sign );
    }

    /** 待签名串：参数按字典序排序，剔除空值，用 & 连接 */
    private static function build_sign_string( $params ) {
        ksort( $params );
        $parts = [];
        foreach ( $params as $k => $v ) {
            if ( $v === '' || $v === null ) continue;
            $parts[] = $k . '=' . $v;
        }
        return implode( '&', $parts );
    }

    /**
     * 载入 RSA 私钥。
     * 支付宝开放平台下载的是 PKCS#8（BEGIN PRIVATE KEY）；不少在线工具生成的是 PKCS#1（BEGIN RSA PRIVATE KEY）。
     * 这里两种都尝试一遍，避免直接报“私钥格式错误”。
     */
    private static function load_private_key( $raw ) {
        $raw = trim( (string) $raw );
        if ( $raw === '' ) return false;

        if ( strpos( $raw, '-----BEGIN' ) !== false ) {
            $key = openssl_pkey_get_private( $raw );
            if ( $key ) return $key;
        }

        $body = preg_replace( '/-----[^-]+-----/', '', $raw );
        $body = wordwrap( preg_replace( '/\s+/', '', $body ), 64, "\n", true );

        foreach ( [ 'PRIVATE KEY', 'RSA PRIVATE KEY' ] as $type ) {
            $key = openssl_pkey_get_private( "-----BEGIN {$type}-----\n{$body}\n-----END {$type}-----" );
            if ( $key ) return $key;
        }
        return false;
    }

    /** 载入支付宝公钥（用于验签） */
    private static function load_public_key( $raw ) {
        $raw = trim( (string) $raw );
        if ( $raw === '' ) return false;

        if ( strpos( $raw, '-----BEGIN' ) !== false ) {
            return openssl_pkey_get_public( $raw );
        }

        $body = wordwrap( preg_replace( '/\s+/', '', $raw ), 64, "\n", true );
        return openssl_pkey_get_public( "-----BEGIN PUBLIC KEY-----\n{$body}\n-----END PUBLIC KEY-----" );
    }

    /** 支付宝要求时间戳为北京时间（GMT+8），与站点/服务器时区无关 */
    private static function beijing_time() {
        return gmdate( 'Y-m-d H:i:s', time() + 8 * HOUR_IN_SECONDS );
    }

    /**
     * 支付日志。
     * 支付是涉及“钱”的流程，出了问题必须能查，所以这里不用 WP_DEBUG 开关，默认就记录。
     */
    public static function log( $message, $context = [] ) {
        $line = '[WSA] ' . $message;
        if ( ! empty( $context ) ) {
            $line .= ' ' . wp_json_encode( $context );
        }
        error_log( $line );
    }
}
