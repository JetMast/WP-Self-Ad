<?php
/**
 * 版权与联系方式 —— 全插件唯一的数据来源
 *
 * 想改版权信息，只需要改两个地方：
 *   ① 本文件的常量（后台「关于插件」页、后台页脚都从这里取）
 *   ② wp-self-ad.php 最顶部的插件头（WordPress 插件列表页读的是那里，PHP 注释里写不了变量）
 *
 * @author    墨桅 (JetMast)
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */

if ( ! defined( 'ABSPATH' ) ) exit;

class WSA_About {

    /* ==================================================================
     * 一、版权信息（改这里）
     * ================================================================== */

    /** 中文笔名 */
    const NAME_CN = '墨桅';
    /** 英文名 */
    const NAME_EN = 'JetMast';
    /** QQ 号 */
    const QQ = '910049360';
    /** 微信号 */
    const WECHAT = 'JetMast';
    /** 联系邮箱 */
    const EMAIL = 'Email@5so.cc';
    /** 博客主页 */
    const BLOG = 'https://jetmast.com';
    /** 授权协议（与 wp-self-ad.php 插件头保持一致） */
    const LICENSE = 'GPL-2.0+';

    /**
     * 完整信息。
     * 其它地方要显示版权信息，一律用这个方法取，不要在别处再写一遍名字和号码，
     * 否则以后改联系方式就会漏掉几处。
     */
    public static function info() {
        return [
            'name_cn' => self::NAME_CN,
            'name_en' => self::NAME_EN,
            'author'  => self::NAME_CN . '（' . self::NAME_EN . '）',
            'qq'      => self::QQ,
            'wechat'  => self::WECHAT,
            'email'   => self::EMAIL,
            'blog'    => self::BLOG,
            'license' => self::LICENSE,
        ];
    }

    /** 一行式署名，用于后台页脚这类地方：墨桅 · JetMast */
    public static function signature() {
        return self::NAME_CN . ' · ' . self::NAME_EN;
    }

    /** 点一下就打开 QQ 临时会话的链接（比自己复制号码去搜索方便） */
    public static function qq_url() {
        return 'https://wpa.qq.com/msgrd?v=3&uin=' . rawurlencode( self::QQ ) . '&site=qq&menu=yes';
    }

    /** 博客主页（过滤掉非法值，坏值时返回空串而不是给用户一个死链） */
    public static function blog_url() {
        $url = esc_url_raw( self::BLOG );
        return $url ? $url : '';
    }

    /* ==================================================================
     * 二、后台页脚署名
     * ================================================================== */

    public static function init() {
        // 只在「自助广告」自己的几个页面加页脚署名，不打扰站长的其它后台页面
        add_filter( 'admin_footer_text', [ __CLASS__, 'admin_footer_text' ] );
    }

    /** 当前是不是本插件的后台页面（page 参数以 wsa- 开头） */
    public static function is_plugin_screen() {
        $page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
        return strpos( $page, 'wsa-' ) === 0;
    }

    /**
     * 后台页脚的版权行。
     * WordPress 允许这里返回 HTML，所以可以放链接。
     */
    public static function admin_footer_text( $text ) {
        if ( ! self::is_plugin_screen() ) {
            return $text;
        }

        $about_url = admin_url( 'admin.php?page=wsa-about' );

        return sprintf(
            'WP Self Ad v%1$s · 作者 %2$s · <a href="%3$s">版权与联系方式</a>',
            esc_html( WSA_VERSION ),
            esc_html( self::signature() ),
            esc_url( $about_url )
        );
    }

    /* ==================================================================
     * 三、「关于插件」页面
     * ================================================================== */

    /** 渲染一行信息：左边标题、右边内容 */
    private static function row( $label, $html ) {
        echo '<tr><th scope="row" style="width:130px;">' . esc_html( $label ) . '</th><td>' . $html . '</td></tr>';
    }

    public static function render_page() {
        $info = self::info();
        $blog = self::blog_url();
        ?>
        <div class="wrap">
            <h1>关于插件</h1>

            <div class="card" style="max-width:900px;padding:22px 26px;">
                <p style="font-size:16px;margin:0 0 8px;">
                    <strong>WP Self Ad — 自助广告系统</strong>
                    <span class="description" style="font-size:13px;">版本 v<?php echo esc_html( WSA_VERSION ); ?></span>
                </p>
                <p style="margin:0;font-size:14px;">
                    作者：<strong><?php echo esc_html( $info['name_cn'] ); ?></strong>
                    <span class="description">（<?php echo esc_html( $info['name_en'] ); ?>）</span>
                </p>
            </div>

            <h2>联系方式</h2>
            <table class="form-table" role="presentation">
                <?php
                self::row( '中文笔名', esc_html( $info['name_cn'] ) );
                self::row( '英文名', esc_html( $info['name_en'] ) );

                self::row( 'QQ', sprintf(
                    '%s &nbsp;<a class="button button-small" href="%s" target="_blank" rel="noopener">发起会话</a>',
                    esc_html( $info['qq'] ),
                    esc_url( self::qq_url() )
                ) );

                self::row( '微信', esc_html( $info['wechat'] ) );

                self::row( '邮箱', sprintf(
                    '<a href="mailto:%s">%s</a>',
                    esc_attr( $info['email'] ),
                    esc_html( $info['email'] )
                ) );

                self::row( '博客主页', $blog
                    ? sprintf(
                        '<a href="%s" target="_blank" rel="noopener">%s</a>',
                        esc_url( $blog ),
                        esc_html( $blog )
                    )
                    : '<span class="description">未填写</span>'
                );
                ?>
            </table>

            <h2>版本与协议</h2>
            <table class="form-table" role="presentation">
                <?php
                self::row( '插件版本', 'v' . esc_html( WSA_VERSION ) );
                self::row( '数据结构版本', esc_html( WSA_DB_VERSION ) );
                self::row( '最低 PHP 版本', '7.4' );
                self::row( '授权协议', esc_html( $info['license'] )
                    . ' &nbsp;<span class="description">（详见插件文件头部的 License 声明）</span>' );
                ?>
            </table>

            <h2>版权声明</h2>
            <div class="card" style="max-width:900px;padding:18px 22px;">
                <p style="margin-top:0;">
                    本插件（WP Self Ad — 自助广告系统）由
                    <strong><?php echo esc_html( $info['name_cn'] ); ?></strong>
                    （<?php echo esc_html( $info['name_en'] ); ?>）独立开发并持有版权。
                </p>
                <p>
                    插件按文件头部声明的 <strong><?php echo esc_html( $info['license'] ); ?></strong>
                    协议发布。协议允许自由使用与再分发，但
                    <strong>请保留本版权信息与作者署名</strong>，不要去除后再分发。
                </p>
                <p style="margin-bottom:0;">
                    使用中遇到问题，欢迎通过上面的 QQ、微信或邮箱联系作者；也可以到博客
                    <?php if ( $blog ) : ?>
                        <a href="<?php echo esc_url( $blog ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $blog ); ?></a>
                    <?php else : ?>
                        （未填写）
                    <?php endif; ?>
                    留言。
                </p>
            </div>
        </div>
        <?php
    }
}
