<?php
/**
 * 广告位：配置读取、位置容量计算、前台短代码渲染
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class WSA_Ad_Slots {

    public static function init() {
        add_shortcode( 'wsa_ad', [ __CLASS__, 'render_shortcode' ] );
    }

    /** 获取所有广告位配置 */
    public static function get_all() {
        global $wpdb;
        $table = WSA_DB::table( 'ad_slots' );
        return $wpdb->get_results( "SELECT * FROM {$table} ORDER BY sort_order ASC" );
    }

    /** 根据 id 获取广告位 */
    public static function get_by_id( $id ) {
        global $wpdb;
        $table = WSA_DB::table( 'ad_slots' );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d", $id
        ) );
    }

    /** 根据 key 获取广告位 */
    public static function get_by_key( $key ) {
        global $wpdb;
        $table = WSA_DB::table( 'ad_slots' );
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE slot_key = %s", $key
        ) );
    }

    /** 解析广告位允许的投放天数，永远返回一个非空数组 */
    public static function duration_options( $slot ) {
        $options = json_decode( $slot->duration_options, true );
        $options = is_array( $options ) ? array_filter( array_map( 'intval', $options ) ) : [];
        // 后台被误清空时兜底，避免前端下拉框变成空、导致该广告位彻底卖不出去
        return $options ? array_values( $options ) : [ 7, 30, 90 ];
    }

    /**
     * 价格计算：金额 = 月单价 × 天数 ÷ 30。
     * 抽成公共方法，前端展示与实际下单都调用它，避免两边各算一份、算法不一致。
     */
    public static function calc_amount( $slot, $duration ) {
        return round( (float) $slot->price * (int) $duration / 30, 2 );
    }

    /**
     * 某个广告位当前“应该显示多少个位置”。
     * 规则：至少留一个空位可售；刚好卖满一行时，再补一整行空位。
     * 短代码渲染与下单校验共用这一个方法，保证“页面上能点的位置”和“后端允许下单的位置”完全一致。
     *
     * @param object $slot    广告位
     * @param int    $sold    已占用 / 已预占的位置总数
     * @param int    $highest 已被占用的最大位置序号
     *
     * 第 3 个参数是为「站长在后台手动添加广告」准备的：
     * 站长可以把广告放到比较靠后的格子（例如第 5 格），这时页面就必须至少显示到第 5 格，
     * 否则那条广告会“看不见”，而它的位置又确实被占着，页面和后端就对不上了。
     * 注意：这里不能把“用户请求的位置”也并进 $highest，否则任何越界的位置都会被算成合法。
     */
    public static function max_position( $slot, $sold, $highest = 0 ) {
        $max     = max( 1, (int) $slot->max_items );
        $highest = max( 0, (int) $highest );

        // 方块横幅是“一整行 6 格”的固定排布。站长手动放到更靠后的格子时按实际需要放宽，
        // 但不补整行 —— 补整行会凭空多出一堆格子，反而更乱。
        if ( $slot->slot_key === 'banner_block' ) {
            return max( $max, $highest );
        }

        $base = (int) ceil( max( (int) $sold + 1, $max ) / $max ) * $max;

        // 站长手动添加的广告可能落在更靠后的格子（例如每行 2 格的广告位放到了第 7 格），
        // 页面必须至少显示到那一格，否则那条广告会“看不见”，而它的位置又确实被占着。
        // 这里顺便补满整行，免得最后一行只剩半截、同一行宽窄不一。
        if ( $highest > $base ) {
            $base = (int) ceil( $highest / $max ) * $max;
        }

        return $base;
    }

    /** 获取某广告位的所有活跃广告 */
    public static function get_active_ads( $slot_id ) {
        global $wpdb;
        $table = WSA_DB::table( 'user_ads' );
        // 时间比较统一用站点时区，不能用 MySQL 的 NOW()（它取的是数据库服务器时区，两者可能差好几个小时）
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table}
              WHERE slot_id = %d AND status = 'active' AND expires_at > %s
              ORDER BY slot_position ASC",
            $slot_id, WSA_DB::now()
        ) );
    }

    /** 短代码渲染：[wsa_ad slot="banner_large"] */
    public static function render_shortcode( $atts ) {
        $atts = shortcode_atts( [ 'slot' => 'banner_large' ], $atts );
        $key  = sanitize_key( $atts['slot'] );
        $slot = self::get_by_key( $key );

        if ( ! $slot || ! $slot->is_enabled ) {
            // 默认静默返回；管理员登录时留一行注释，方便发现短代码写错了
            if ( current_user_can( 'manage_options' ) ) {
                return '<!-- WSA: 广告位 ' . esc_html( $key ) . ' 不存在或已停用 -->';
            }
            return '';
        }

        $ads = self::get_active_ads( $slot->id );

        // 已被占用的最大位置序号：站长可能在后台手动把广告放到了比较靠后的格子，
        // 页面必须至少显示到那一格，否则那条广告就永远看不见了。
        $highest = 0;
        foreach ( $ads as $ad ) {
            $highest = max( $highest, (int) $ad->slot_position );
        }

        $total     = self::max_position( $slot, count( $ads ), $highest );
        $is_text   = $slot->slot_type === 'text';
        $slot_id   = (int) $slot->id;
        $slot_key  = esc_attr( $slot->slot_key );
        $slot_name = esc_html( $slot->slot_name );
        $price     = esc_html( $slot->price );

        // 构建位置数组：按实际购买的位置序号映射，空位置显示招租
        $items  = [];
        $by_pos = [];
        foreach ( $ads as $ad ) {
            $by_pos[ (int) $ad->slot_position ] = $ad;
        }
        for ( $i = 1; $i <= $total; $i++ ) {
            if ( isset( $by_pos[ $i ] ) ) {
                $items[] = [ 'type' => 'ad', 'data' => $by_pos[ $i ] ];
            } else {
                $items[] = [ 'type' => 'empty', 'pos' => $i ];
            }
        }

        ob_start();
        ?>
        <div class="wsa-slot wsa-slot-<?php echo $slot_key; ?> <?php echo $is_text ? 'wsa-slot-text' : ''; ?>"
             data-slot-id="<?php echo $slot_id; ?>"
             data-slot-key="<?php echo $slot_key; ?>"
             data-slot-name="<?php echo $slot_name; ?>"
             data-price="<?php echo $price; ?>">
            <div class="wsa-slot-inner">
                <?php foreach ( $items as $item ) : ?>
                    <?php if ( $item['type'] === 'ad' ) : ?>
                        <?php
                        $ad = $item['data'];

                        // 没有跳转链接时不要套 <a>：否则会渲染出一个 href="" 的空链接，
                        // 点一下会把用户带回当前页顶部，体验很怪。这种情况整块只作展示。
                        $link  = trim( (string) $ad->link_url );
                        $tag   = ( $link !== '' ) ? 'a' : 'span';
                        $attrs = ( $link !== '' )
                            ? ' href="' . esc_url( $link ) . '" target="_blank" rel="sponsored nofollow noopener"'
                            : '';
                        ?>
                        <?php if ( $is_text ) : ?>
                            <<?php echo $tag; ?> class="wsa-text-item"<?php echo $attrs; ?>>
                                <?php echo esc_html( $ad->text_content ); ?>
                            </<?php echo $tag; ?>>
                        <?php else : ?>
                            <<?php echo $tag; ?> class="wsa-img-item"<?php echo $attrs; ?>>
                                <img src="<?php echo esc_url( $ad->image_url ); ?>"
                                     alt="<?php echo esc_attr( $slot_name ); ?>"
                                     loading="lazy" />
                            </<?php echo $tag; ?>>
                        <?php endif; ?>
                    <?php else : ?>
                        <div class="wsa-empty-item" data-position="<?php echo $item['pos']; ?>">
                            <span class="wsa-empty-text"><?php echo $slot_name; ?>招租</span>
                            <span class="wsa-empty-price">¥<?php echo $price; ?>/月起</span>
                        </div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
