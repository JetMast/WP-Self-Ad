<?php
/**
 * 前台接口：广告位数据、下单
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class WSA_Ajax {

    public static function init() {
        // 获取广告位配置
        add_action( 'wp_ajax_nopriv_wsa_get_slot', [ __CLASS__, 'get_slot' ] );
        add_action( 'wp_ajax_wsa_get_slot', [ __CLASS__, 'get_slot' ] );
        // 提交订单并发起支付
        add_action( 'wp_ajax_wsa_create_order', [ __CLASS__, 'create_order' ] );
    }

    /** 获取广告位详情（弹窗用） */
    public static function get_slot() {
        check_ajax_referer( 'wsa_frontend_nonce', 'nonce' );

        $slot_id = absint( $_POST['slot_id'] ?? 0 );
        $slot    = WSA_Ad_Slots::get_by_id( $slot_id );
        if ( ! $slot || ! $slot->is_enabled ) wp_send_json_error( '广告位不存在' );

        // 价格一律由服务端算好发给前端，前端只负责显示。
        // 这样前端被改也影响不了真实金额，将来调整计费规则也只需要改一处。
        $options = [];
        foreach ( WSA_Ad_Slots::duration_options( $slot ) as $days ) {
            $options[] = [
                'days'  => $days,
                'price' => WSA_Ad_Slots::calc_amount( $slot, $days ),
            ];
        }

        // 该广告位当前还有哪些位置可以买（与页面渲染用的是同一套规则）
        $ads = WSA_Ad_Slots::get_active_ads( $slot->id );
        $taken = [];
        foreach ( $ads as $ad ) {
            $taken[] = (int) $ad->slot_position;
        }

        wp_send_json_success( [
            'id'        => (int) $slot->id,
            'name'      => esc_html( $slot->slot_name ),
            'type'      => esc_html( $slot->slot_type ),
            'price'     => (float) $slot->price,
            'max_items' => (int) $slot->max_items,
            'options'   => $options,
            'taken'     => $taken,
            'methods'   => WSA_Payment::available_methods(),
        ] );
    }

    /** 创建订单并返回支付跳转地址 */
    public static function create_order() {
        check_ajax_referer( 'wsa_frontend_nonce', 'nonce' );

        if ( ! is_user_logged_in() ) {
            wp_send_json_error( [ 'code' => 'not_logged', 'message' => '请先登录' ] );
        }

        // 关键：WordPress 会给 $_POST 里的内容自动加反斜杠，必须先 unslash 再做过滤，
        // 否则用户输入的引号等内容会残留反斜杠。
        $post = wp_unslash( $_POST );

        $user_id       = get_current_user_id();
        $slot_id       = absint( $post['slot_id'] ?? 0 );
        $slot_position = absint( $post['slot_position'] ?? 1 );
        $duration      = absint( $post['duration'] ?? 0 );
        $pay_type      = sanitize_key( $post['payment'] ?? '' );
        $image_url     = esc_url_raw( $post['image_url'] ?? '' );
        $link_url      = esc_url_raw( $post['link_url'] ?? '' );
        $text_content  = sanitize_text_field( $post['text_content'] ?? '' );

        if ( $slot_id < 1 ) {
            wp_send_json_error( '无效的广告位' );
        }

        // 1) 用户选的付款方式必须是当前可对外提供的，不信任前端传来的值
        $methods = WSA_Payment::available_methods();
        if ( ! isset( $methods[ $pay_type ] ) ) {
            wp_send_json_error( '该支付方式当前不可用，请刷新页面后重试' );
        }

        // 2) 按优先级自动挑选承接这个付款方式的通道，并把结果固定下来存进订单。
        //    这样“用户看到的付款方式”和“实际调用的接口”一定是同一套规则算出来的。
        $channel = WSA_Payment::resolve_channel( $pay_type );
        if ( ! $channel ) {
            wp_send_json_error( '该支付方式当前不可用，请刷新页面后重试' );
        }

        // 防 XSS：过滤 URL 协议
        if ( $image_url && ! preg_match( '#^https?://#i', $image_url ) ) {
            wp_send_json_error( '图片链接必须以 http(s):// 开头' );
        }
        if ( $link_url && ! preg_match( '#^https?://#i', $link_url ) ) {
            wp_send_json_error( '跳转链接必须以 http(s):// 开头' );
        }

        $ad_content = [
            'type'         => $text_content ? 'text' : 'image',
            'image_url'    => $image_url,
            'link_url'     => $link_url,
            'text_content' => $text_content,
        ];

        // 时长、位置、金额等校验都在订单模块内部完成（含“时长必须是后台设定的可选项”）
        $order_no = WSA_Orders::create(
            $user_id, $slot_id, $slot_position, $duration, $pay_type, $channel, $ad_content
        );
        if ( is_wp_error( $order_no ) ) {
            wp_send_json_error( $order_no->get_error_message() );
        }

        // 按已经确定好的通道发起支付，避免中途配置变化导致前后不一致
        $payment_result = WSA_Payment::request_payment( $order_no, $pay_type, $channel );
        if ( ! empty( $payment_result['error'] ) ) {
            // 支付没能发起来（例如服务商不接受这个付款方式），这笔订单用户根本没机会付款，
            // 立刻关掉并释放位置；否则位置会被白占 30 分钟，用户换个付款方式重试反而被自己挡住。
            WSA_Orders::close_pending( $order_no );
            WSA_Payment::log( '发起支付失败，订单已关闭并释放位置', [
                'order_no' => $order_no,
                'pay_type' => $pay_type,
                'channel'  => $channel,
                'error'    => $payment_result['error'],
            ] );
            wp_send_json_error( $payment_result['error'] );
        }

        wp_send_json_success( [
            'order_no' => $order_no,
            'method'   => $pay_type,
            'channel'  => $channel,
            'redirect' => $payment_result['redirect'],
        ] );
    }
}
