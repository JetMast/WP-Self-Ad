<?php
/**
 * 订单：创建与占位校验、支付成功后的权益发放、超时关闭
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class WSA_Orders {

    /**
     * 未支付订单的“占位有效期”（秒）。
     * 下单后 30 分钟内没付款，该位置允许被别人重新购买；超过 30 分钟由定时任务自动关闭订单。
     */
    const PENDING_TTL = 1800;

    /**
     * 创建订单。
     * 整个过程放在事务里，并先锁住广告位那一行：
     * 同一个广告位的并发下单会在这里排队执行，从根本上避免“同一个位置卖给两个人”。
     *
     * @param string $payment_method  用户选择的付款方式（alipay / wechat ...）
     * @param string $payment_channel 实际要走的支付通道（alipay / epay ...），由支付模块按优先级算出
     */
    public static function create( $user_id, $slot_id, $slot_position, $duration, $payment_method, $payment_channel, $ad_content ) {
        global $wpdb;

        $wpdb->query( 'START TRANSACTION' );

        $slot = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . WSA_DB::table( 'ad_slots' ) . " WHERE id = %d FOR UPDATE",
            $slot_id
        ) );

        $result = self::do_create( $slot, $user_id, $slot_position, $duration, $payment_method, $payment_channel, $ad_content );

        if ( is_wp_error( $result ) ) {
            $wpdb->query( 'ROLLBACK' );
            return $result;
        }

        $wpdb->query( 'COMMIT' );
        return $result;
    }

    /** 真正干活的部分，被 create() 包在事务里调用 */
    private static function do_create( $slot, $user_id, $slot_position, $duration, $payment_method, $payment_channel, $ad_content ) {
        global $wpdb;

        $orders_table = WSA_DB::table( 'orders' );
        $ads_table    = WSA_DB::table( 'user_ads' );

        $slot_position = (int) $slot_position;
        $duration      = (int) $duration;

        if ( ! $slot || ! $slot->is_enabled ) {
            return new WP_Error( 'invalid_slot', '广告位不可用' );
        }

        // 1) 位置序号必须是正整数
        if ( $slot_position < 1 ) {
            return new WP_Error( 'invalid_position', '无效的广告位置' );
        }

        // 2) 投放时长必须是站长在后台设定的可选项，防止前端被篡改成任意天数
        $options = WSA_Ad_Slots::duration_options( $slot );
        if ( ! in_array( $duration, $options, true ) ) {
            return new WP_Error( 'invalid_duration', '无效的投放时长' );
        }

        $now = WSA_DB::now();

        // 3) 统计该广告位当前已占用 / 已预占的位置数，用于推算“当前位置上限”
        $pending_since = WSA_DB::time_offset( - self::PENDING_TTL );

        $occupied_total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ads_table}
              WHERE slot_id = %d AND status = 'active' AND expires_at > %s",
            $slot->id, $now
        ) );
        $pending_total = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$orders_table}
              WHERE slot_id = %d AND status = 'pending' AND created_at > %s",
            $slot->id, $pending_since
        ) );

        // 已经被占用的“最大位置序号”。
        // 站长可以在后台手动把广告放到比较靠后的格子，页面上就会一直显示到那一格；
        // 这里必须把同样的口径算进来，否则页面上能点的格子后端却会拒绝。
        // 注意：不要把我们这次请求的 $slot_position 也算进去，否则越界的请求也会被当成合法。
        $highest_ads = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT MAX(slot_position) FROM {$ads_table}
              WHERE slot_id = %d AND status = 'active' AND expires_at > %s",
            $slot->id, $now
        ) );
        $highest_pending = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT MAX(slot_position) FROM {$orders_table}
              WHERE slot_id = %d AND status = 'pending' AND created_at > %s",
            $slot->id, $pending_since
        ) );

        // 与短代码渲染用的是同一个方法，页面上出现过的位置，后端就一定允许下单
        $capacity = WSA_Ad_Slots::max_position(
            $slot,
            $occupied_total + $pending_total,
            max( $highest_ads, $highest_pending )
        );
        if ( $slot_position > $capacity ) {
            return new WP_Error( 'invalid_position', '无效的广告位置' );
        }

        // 4) 该位置是否已经有一条在线广告
        $occupied = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ads_table}
              WHERE slot_id = %d AND slot_position = %d AND status = 'active' AND expires_at > %s",
            $slot->id, $slot_position, $now
        ) );
        if ( $occupied > 0 ) {
            return new WP_Error( 'slot_occupied', '该位置已被购买，请选择其他位置' );
        }

        // 5) 该位置是否正被“还没付款但没超时”的订单占着（防止一个人下单未付、另一个人买到同一位置）
        $reserved = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$orders_table}
              WHERE slot_id = %d AND slot_position = %d AND status = 'pending' AND created_at > %s",
            $slot->id, $slot_position, WSA_DB::time_offset( - self::PENDING_TTL )
        ) );
        if ( $reserved > 0 ) {
            return new WP_Error( 'slot_reserved', '该位置正在被其他用户下单，请稍后重试或换个位置' );
        }

        // 6) 金额由服务端唯一计算
        $amount = WSA_Ad_Slots::calc_amount( $slot, $duration );

        // 7) 订单号：时间 + 8 位随机数，降低“同一秒内订单号撞车”的概率
        $order_no = 'WSA' . gmdate( 'YmdHis' ) . wp_rand( 1000, 9999 ) . wp_rand( 1000, 9999 );

        $inserted = $wpdb->insert( $orders_table, [
            'order_no'        => $order_no,
            'user_id'         => $user_id,
            'slot_id'         => $slot->id,
            'slot_position'   => $slot_position,
            'amount'          => $amount,
            'duration'        => $duration,
            'payment_method'  => $payment_method,
            'payment_channel' => $payment_channel,
            'status'          => 'pending',
            'ad_content'      => wp_json_encode( $ad_content ),
            'created_at'      => $now,
        ], [ '%s', '%d', '%d', '%d', '%f', '%d', '%s', '%s', '%s', '%s', '%s' ] );

        if ( ! $inserted ) {
            // 关键：把数据库给出的真实原因记下来。
            // 这里最常见的两种情况是「订单表整张不存在」和「插件升级后表结构没跟上」，
            // 例如订单表少了一个 payment_channel 字段。用户只会看到一句笼统的
            // “订单创建失败”，所以必须把数据库的原话留存下来，后台才能一眼看明白。
            self::log_db_error( '订单写入数据库失败', $order_no );
            return new WP_Error( 'db_error', self::db_error_message() );
        }

        return $order_no;
    }

    /**
     * 关闭一笔还没付款的订单，把它占着的位置释放出来。
     *
     * 用在下单成功但“发起支付”失败的时候（例如服务商不接受该付款方式）：
     * 这种订单用户根本没机会付钱，如果不关掉，它会白占位置 30 分钟，
     * 用户换个付款方式重试反而会被自己上一笔订单挡住。
     *
     * 只处理 pending 订单，已支付 / 已过期的一律不动，所以不会误伤已有权益。
     *
     * @return bool 是否成功关闭（订单本来就不是 pending 时返回 false）
     */
    public static function close_pending( $order_no ) {
        global $wpdb;

        $updated = $wpdb->update(
            WSA_DB::table( 'orders' ),
            [ 'status' => 'closed' ],
            [ 'order_no' => $order_no, 'status' => 'pending' ],
            [ '%s' ],
            [ '%s', '%s' ]
        );

        return $updated === 1;
    }

    /** 根据订单号获取订单 */
    public static function get_by_order_no( $order_no ) {
        global $wpdb;
        return $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM " . WSA_DB::table( 'orders' ) . " WHERE order_no = %s",
            $order_no
        ) );
    }

    /**
     * 标记订单已支付，并发放广告权益。
     * 这是“支付成功 → 权益发放”的唯一入口，全部动作放在一个事务里：
     * 要么订单变成已支付且广告成功上线，要么整体回滚当作没发生过，不会出现“钱付了广告没上”。
     *
     * @param string     $order_no    本站订单号
     * @param string     $trade_no    支付平台流水号
     * @param float|null $paid_amount 支付平台回传的金额，用于核对
     * @return true|WP_Error
     */
    public static function mark_paid( $order_no, $trade_no, $paid_amount = null ) {
        global $wpdb;

        $orders_table = WSA_DB::table( 'orders' );
        $ads_table    = WSA_DB::table( 'user_ads' );
        $slots_table  = WSA_DB::table( 'ad_slots' );

        $wpdb->query( 'START TRANSACTION' );

        // 先按订单号读出订单（暂不加锁），目的是拿到它属于哪个广告位
        $order = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$orders_table} WHERE order_no = %s", $order_no
        ) );
        if ( ! $order ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'order_not_found', '订单不存在：' . $order_no );
        }

        // 加锁顺序必须与下单时一致（先锁广告位、再锁订单），否则两个流程可能互相等待形成死锁
        $wpdb->get_row( $wpdb->prepare(
            "SELECT id FROM {$slots_table} WHERE id = %d FOR UPDATE", $order->slot_id
        ) );
        $order = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$orders_table} WHERE order_no = %s FOR UPDATE", $order_no
        ) );
        if ( ! $order ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'order_not_found', '订单不存在：' . $order_no );
        }

        // 幂等：已经处理过的订单直接返回成功，支付平台重复通知不会重复发放
        if ( $order->status === 'paid' ) {
            $wpdb->query( 'ROLLBACK' );
            return true;
        }
        if ( $order->status !== 'pending' ) {
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'invalid_status', '订单状态异常：' . $order->status );
        }

        // 金额核对：支付平台回传的金额必须与下单时算出的金额一致
        if ( $paid_amount !== null && abs( (float) $paid_amount - (float) $order->amount ) > 0.01 ) {
            self::flag_review( $order->id, $trade_no, 'amount_mismatch' );
            $wpdb->query( 'COMMIT' );
            return new WP_Error( 'amount_mismatch', sprintf(
                '支付金额不符：订单应付 %s，实际回传 %s', $order->amount, $paid_amount
            ) );
        }

        // 发放前再查一次位置：极端情况下（例如超时未付被别人买走）不能重复发放
        $occupied = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$ads_table}
              WHERE slot_id = %d AND slot_position = %d AND status = 'active' AND expires_at > %s AND order_id <> %d",
            $order->slot_id, $order->slot_position, WSA_DB::now(), $order->id
        ) );
        if ( $occupied > 0 ) {
            self::flag_review( $order->id, $trade_no, 'slot_conflict' );
            $wpdb->query( 'COMMIT' );
            return new WP_Error( 'slot_conflict', '该位置已被其他订单占用，订单已标记为待人工核对：' . $order_no );
        }

        $paid_at = WSA_DB::now();
        $expires = WSA_DB::time_offset( (int) $order->duration * DAY_IN_SECONDS );

        $updated = $wpdb->update( $orders_table, [
            'status'           => 'paid',
            'payment_trade_no' => $trade_no,
            'paid_at'          => $paid_at,
            'expires_at'       => $expires,
        ], [ 'id' => $order->id ], [ '%s', '%s', '%s', '%s' ], [ '%d' ] );

        if ( $updated === false ) {
            self::log_db_error( '订单状态更新失败', $order_no );
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'db_error', '订单状态更新失败' );
        }

        $ad_content = json_decode( $order->ad_content, true );
        if ( ! is_array( $ad_content ) ) $ad_content = [];

        $inserted = $wpdb->insert( $ads_table, [
            'order_id'      => $order->id,
            'user_id'       => $order->user_id,
            'slot_id'       => $order->slot_id,
            'slot_position' => $order->slot_position,
            'source'        => 'user', // 用户花钱买的；站长在后台手动添加的记 'admin'
            'ad_type'       => isset( $ad_content['type'] ) ? $ad_content['type'] : 'image',
            'image_url'     => isset( $ad_content['image_url'] ) ? $ad_content['image_url'] : '',
            'text_content'  => isset( $ad_content['text_content'] ) ? $ad_content['text_content'] : '',
            'link_url'      => isset( $ad_content['link_url'] ) ? $ad_content['link_url'] : '',
            'status'        => 'active',
            // 投放天数在这里记一份，便于广告到期后“重新上架”时按同样天数自动续期
            'duration'      => (int) $order->duration,
            'started_at'    => $paid_at,
            'expires_at'    => $expires,
            'created_at'    => $paid_at,
        ], [ '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ] );

        // 广告没写进去就整体回滚，绝不能留下“已支付但没广告”的订单
        if ( ! $inserted ) {
            self::log_db_error( '广告写入失败（已回滚）', $order_no );
            $wpdb->query( 'ROLLBACK' );
            return new WP_Error( 'ad_insert_failed', '广告写入失败，订单已回滚：' . $order_no );
        }

        $wpdb->query( 'COMMIT' );
        return true;
    }

    /**
     * 把数据库报的原始错误记录下来，避免只剩下一句笼统的“失败”。
     *
     * 记两份：
     *   1) 写进 PHP 错误日志（给会看服务器日志的人）；
     *   2) 存进 wp_options（给后台看）——站长多半拿不到服务器日志，
     *      而后台首页会直接把这句话显示出来，一眼就知道是哪个字段出了问题。
     */
    private static function log_db_error( $what, $order_no ) {
        global $wpdb;

        $error = (string) $wpdb->last_error;
        $query = (string) $wpdb->last_query;

        if ( class_exists( 'WSA_Payment' ) ) {
            WSA_Payment::log( $what, [
                'order_no' => $order_no,
                'db_error' => $error,
                'query'    => $query,
            ] );
        }

        update_option( 'wsa_last_db_error', [
            'time'     => WSA_DB::now(),
            'what'     => $what,
            'order_no' => $order_no,
            'error'    => $error,
            'query'    => $query,
        ], false );
    }

    /**
     * 数据库写入失败时给用户看到的话。
     *
     * 对普通用户只给一句不泄露细节的提示；如果当前登录的正好是管理员（多半是站长本人在测试），
     * 就顺手告诉他去哪儿看详细原因 —— 否则他只拿到“订单创建失败”四个字，无从下手。
     */
    private static function db_error_message() {
        $message = '订单创建失败';
        if ( function_exists( 'current_user_can' ) && current_user_can( 'manage_options' ) ) {
            $message .= '（您是管理员：真实原因已记录到「自助广告系统 → 支付设置 → 数据库结构」）';
        }
        return $message;
    }

    /** 把订单标记为“待人工核对”，供管理员在后台看到并处理（退款 / 手动补发） */
    private static function flag_review( $order_id, $trade_no, $reason ) {
        global $wpdb;
        $wpdb->update( WSA_DB::table( 'orders' ), [
            'status'           => 'review',
            'payment_trade_no' => $trade_no,
            'paid_at'          => WSA_DB::now(),
        ], [ 'id' => $order_id ], [ '%s', '%s', '%s' ], [ '%d' ] );

        if ( class_exists( 'WSA_Payment' ) ) {
            WSA_Payment::log( '订单转入待人工核对', [ 'order_id' => $order_id, 'trade_no' => $trade_no, 'reason' => $reason ] );
        }
    }

    /**
     * 获取用户订单。
     * 说明：本轮暂未被调用，是给下一轮「我的广告」用户中心页面预留的接口。
     */
    public static function get_user_orders( $user_id, $limit = 20 ) {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . WSA_DB::table( 'orders' ) . "
              WHERE user_id = %d ORDER BY created_at DESC LIMIT %d",
            $user_id, $limit
        ) );
    }
}
