<?php
/**
 * 数据层：表结构定义、建表补字段、数据迁移与结构自检
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class WSA_DB {

    /** 统一的“当前时间”，一律使用 WordPress 站点时区 */
    public static function now() {
        return current_time( 'mysql' );
    }

    /**
     * 在“现在”的基础上偏移若干秒，返回同样格式的时间字符串。
     * 说明：current_time('timestamp') 得到的是“站点时区时间换算成的秒数”，
     * 再用 gmdate 输出即可保持时区一致（这里不能用 date()，它用的是服务器时区）。
     */
    public static function time_offset( $seconds ) {
        return gmdate( 'Y-m-d H:i:s', current_time( 'timestamp' ) + (int) $seconds );
    }

    /* ==================================================================
     * 一、表结构定义：这里是唯一的“标准答案”
     * ================================================================== */

    /**
     * 返回三张表的完整结构定义。
     *
     * 每个表分三部分：
     *   create  —— 建表语句（表不存在时用）
     *   columns —— 字段名 => 字段定义（缺哪个补哪个）
     *   keys    —— 索引名 => 索引定义（缺哪个补哪个）
     *
     * ⚠️ 重要：这里的 SQL 只能用 $wpdb->query() 直接执行，千万不要交给 dbDelta()。
     *
     * 原因（这就是 v1.2.2 及以前“订单创建失败”的真凶）：
     * dbDelta() 用正则 `CREATE TABLE ([^ ]*)` 去猜表名，它只取 "CREATE TABLE " 之后的
     * 第一个空格分隔片段。遇到 "CREATE TABLE IF NOT EXISTS `wp_wsa_orders`"，猜出来的
     * 表名是 "IF"，接着它会执行 `DESCRIBE IF;`，这句在 MySQL 里直接语法报错、返回空，
     * dbDelta 便认为“这张表不需要处理”，然后 continue 掉 —— 整条建表语句被静默丢弃。
     *
     * 结果是：表永远建不出来，字段永远补不上，日志里一句报错都没有，
     * 最后只表现为用户点“确认支付”时一句莫名其妙的「订单创建失败」。
     *
     * @return array 表名 => 结构定义
     */
    private static function schema() {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $p       = $wpdb->prefix;

        return [

            // 广告位表
            'ad_slots' => [
                'create'  => "CREATE TABLE IF NOT EXISTS `{$p}wsa_ad_slots` (
                    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `slot_key` VARCHAR(50) NOT NULL,
                    `slot_name` VARCHAR(100) NOT NULL,
                    `slot_type` VARCHAR(20) NOT NULL DEFAULT 'image',
                    `is_enabled` TINYINT(1) NOT NULL DEFAULT 1,
                    `price` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                    `duration_options` TEXT,
                    `max_items` TINYINT UNSIGNED NOT NULL DEFAULT 1,
                    `sort_order` TINYINT UNSIGNED NOT NULL DEFAULT 0,
                    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `slot_key` (`slot_key`)
                ) {$charset};",
                'columns' => [
                    'id'               => '`id` INT UNSIGNED NOT NULL AUTO_INCREMENT',
                    'slot_key'         => '`slot_key` VARCHAR(50) NOT NULL',
                    'slot_name'        => '`slot_name` VARCHAR(100) NOT NULL',
                    'slot_type'        => "`slot_type` VARCHAR(20) NOT NULL DEFAULT 'image'",
                    'is_enabled'       => '`is_enabled` TINYINT(1) NOT NULL DEFAULT 1',
                    'price'            => '`price` DECIMAL(10,2) NOT NULL DEFAULT 0.00',
                    'duration_options' => '`duration_options` TEXT',
                    'max_items'        => '`max_items` TINYINT UNSIGNED NOT NULL DEFAULT 1',
                    'sort_order'       => '`sort_order` TINYINT UNSIGNED NOT NULL DEFAULT 0',
                    'created_at'       => '`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
                ],
                'keys'    => [
                    'slot_key' => 'UNIQUE KEY `slot_key` (`slot_key`)',
                ],
            ],

            // 订单表
            // payment_method  = 用户选择的付款方式（alipay / wechat ...）
            // payment_channel = 实际调用哪家支付通道（alipay=支付宝官方 / epay=易支付）
            'orders' => [
                'create'  => "CREATE TABLE IF NOT EXISTS `{$p}wsa_orders` (
                    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `order_no` VARCHAR(64) NOT NULL,
                    `user_id` BIGINT UNSIGNED NOT NULL,
                    `slot_id` INT UNSIGNED NOT NULL,
                    `slot_position` INT UNSIGNED NOT NULL DEFAULT 1,
                    `amount` DECIMAL(10,2) NOT NULL,
                    `duration` INT UNSIGNED NOT NULL,
                    `payment_method` VARCHAR(20) NOT NULL,
                    `payment_channel` VARCHAR(20) DEFAULT NULL,
                    `payment_trade_no` VARCHAR(128) DEFAULT NULL,
                    `status` VARCHAR(20) NOT NULL DEFAULT 'pending',
                    `ad_content` TEXT,
                    `paid_at` DATETIME DEFAULT NULL,
                    `expires_at` DATETIME DEFAULT NULL,
                    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    UNIQUE KEY `order_no` (`order_no`),
                    KEY `user_id` (`user_id`),
                    KEY `slot_id` (`slot_id`),
                    KEY `status` (`status`),
                    KEY `slot_position` (`slot_id`,`slot_position`,`status`)
                ) {$charset};",
                'columns' => [
                    'id'               => '`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT',
                    'order_no'         => '`order_no` VARCHAR(64) NOT NULL',
                    'user_id'          => '`user_id` BIGINT UNSIGNED NOT NULL',
                    'slot_id'          => '`slot_id` INT UNSIGNED NOT NULL',
                    // 早期版本这里是 TINYINT，只能存到 255；而“卖满一行补一整行”的规则
                    // 会让位置序号一直增长，所以必须是 INT。下面 widen_columns() 负责把老表改过来。
                    'slot_position'    => '`slot_position` INT UNSIGNED NOT NULL DEFAULT 1',
                    'amount'           => '`amount` DECIMAL(10,2) NOT NULL',
                    'duration'         => '`duration` INT UNSIGNED NOT NULL',
                    'payment_method'   => '`payment_method` VARCHAR(20) NOT NULL',
                    'payment_channel'  => '`payment_channel` VARCHAR(20) DEFAULT NULL',
                    'payment_trade_no' => '`payment_trade_no` VARCHAR(128) DEFAULT NULL',
                    'status'           => "`status` VARCHAR(20) NOT NULL DEFAULT 'pending'",
                    'ad_content'       => '`ad_content` TEXT',
                    'paid_at'          => '`paid_at` DATETIME DEFAULT NULL',
                    'expires_at'       => '`expires_at` DATETIME DEFAULT NULL',
                    'created_at'       => '`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
                ],
                'keys'    => [
                    'order_no'      => 'UNIQUE KEY `order_no` (`order_no`)',
                    'user_id'       => 'KEY `user_id` (`user_id`)',
                    'slot_id'       => 'KEY `slot_id` (`slot_id`)',
                    'status'        => 'KEY `status` (`status`)',
                    'slot_position' => 'KEY `slot_position` (`slot_id`,`slot_position`,`status`)',
                ],
            ],

            // 广告表（站长手动添加的广告与用户购买的广告共用这一张表，用 source 区分）
            //   source = 'user'  用户在收银台下单购买，order_id 指向那笔订单
            //   source = 'admin' 站长在后台「广告管理」里手动添加，order_id / user_id 记为 0
            // 共用一张表的好处：前台渲染只有一条查询，不需要判断广告是从哪来的。
            // 注意：slot_position 由 TINYINT 改为 INT，理由同上
            'user_ads' => [
                'create'  => "CREATE TABLE IF NOT EXISTS `{$p}wsa_user_ads` (
                    `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
                    `order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    `user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0,
                    `slot_id` INT UNSIGNED NOT NULL,
                    `slot_position` INT UNSIGNED NOT NULL DEFAULT 1,
                    `source` VARCHAR(20) NOT NULL DEFAULT 'user',
                    `ad_type` VARCHAR(20) NOT NULL DEFAULT 'image',
                    `image_url` VARCHAR(500) DEFAULT NULL,
                    `text_content` VARCHAR(200) DEFAULT NULL,
                    `link_url` VARCHAR(500) DEFAULT NULL,
                    `status` VARCHAR(20) NOT NULL DEFAULT 'active',
                    `duration` INT UNSIGNED NOT NULL DEFAULT 0,
                    `admin_note` VARCHAR(255) DEFAULT NULL,
                    `started_at` DATETIME NOT NULL,
                    `expires_at` DATETIME NOT NULL,
                    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    PRIMARY KEY (`id`),
                    KEY `user_id` (`user_id`),
                    KEY `slot_id` (`slot_id`),
                    KEY `status` (`status`),
                    KEY `source` (`source`),
                    KEY `expires_at` (`expires_at`),
                    KEY `slot_occupancy` (`slot_id`,`slot_position`,`status`)
                ) {$charset};",
                'columns' => [
                    'id'            => '`id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT',
                    'order_id'      => '`order_id` BIGINT UNSIGNED NOT NULL DEFAULT 0',
                    'user_id'       => '`user_id` BIGINT UNSIGNED NOT NULL DEFAULT 0',
                    'slot_id'       => '`slot_id` INT UNSIGNED NOT NULL',
                    'slot_position' => '`slot_position` INT UNSIGNED NOT NULL DEFAULT 1',
                    'source'        => "`source` VARCHAR(20) NOT NULL DEFAULT 'user'",
                    'ad_type'       => "`ad_type` VARCHAR(20) NOT NULL DEFAULT 'image'",
                    'image_url'     => '`image_url` VARCHAR(500) DEFAULT NULL',
                    'text_content'  => '`text_content` VARCHAR(200) DEFAULT NULL',
                    'link_url'      => '`link_url` VARCHAR(500) DEFAULT NULL',
                    'status'        => "`status` VARCHAR(20) NOT NULL DEFAULT 'active'",
                    'duration'      => '`duration` INT UNSIGNED NOT NULL DEFAULT 0',
                    'admin_note'    => '`admin_note` VARCHAR(255) DEFAULT NULL',
                    'started_at'    => '`started_at` DATETIME NOT NULL',
                    'expires_at'    => '`expires_at` DATETIME NOT NULL',
                    'created_at'    => '`created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP',
                ],
                'keys'    => [
                    'user_id'        => 'KEY `user_id` (`user_id`)',
                    'slot_id'        => 'KEY `slot_id` (`slot_id`)',
                    'status'         => 'KEY `status` (`status`)',
                    'source'         => 'KEY `source` (`source`)',
                    'expires_at'     => 'KEY `expires_at` (`expires_at`)',
                    'slot_occupancy' => 'KEY `slot_occupancy` (`slot_id`,`slot_position`,`status`)',
                ],
            ],

        ];
    }

    /* ==================================================================
     * 二、结构同步：建表 / 补字段 / 补索引
     * ================================================================== */

    /**
     * 把数据库结构对齐到 schema() 的定义：缺表建表、缺字段补字段、缺索引补索引。
     *
     * 本方法只做加法，永远不会删除或改写已有数据（除了下面一个唯一的例外：
     * 把 slot_position 从 TINYINT 放大成 INT —— 这只是把取值范围变大，不会丢数）。
     *
     * @return array 本次实际做了什么：created / columns / keys / errors
     */
    public static function sync_structure() {
        global $wpdb;

        $report = [ 'created' => [], 'columns' => [], 'keys' => [], 'errors' => [] ];

        // 结构修复期间不要往页面上打印数据库报错，我们自己收集起来给后台看
        $prev_suppress = $wpdb->suppress_errors( true );

        foreach ( self::schema() as $name => $def ) {
            $table = self::table( $name );

            // 1) 表不存在 → 直接建表
            if ( ! self::table_exists( $table ) ) {
                $wpdb->query( $def['create'] );
                if ( $wpdb->last_error ) {
                    $report['errors'][] = "建表 {$table} 失败：{$wpdb->last_error}";
                    continue; // 表都没建起来，后面的字段比对没有意义
                }
                $report['created'][] = $table;
            }

            // 2) 缺字段就补字段
            $have = self::existing_columns( $table );
            foreach ( $def['columns'] as $column => $definition ) {
                if ( in_array( $column, $have, true ) ) continue;

                // 给已存在的表追加 AUTO_INCREMENT 字段时，MySQL 要求它必须同时是索引，
                // 这里去掉 AUTO_INCREMENT 以保证语句能执行成功（这种情况说明表已经很不正常了，
                // 补上字段至少能让下单不再直接失败）。
                $sql_def = str_ireplace( ' AUTO_INCREMENT', '', $definition );

                $wpdb->query( "ALTER TABLE `{$table}` ADD COLUMN {$sql_def}" );
                if ( $wpdb->last_error ) {
                    $report['errors'][] = "补字段 {$name}.{$column} 失败：{$wpdb->last_error}";
                } else {
                    $report['columns'][] = "{$name}.{$column}";
                }
            }

            // 3) 缺索引就补索引（只影响查询速度，失败不影响功能，所以放在最后）
            $keys = self::existing_keys( $table );
            foreach ( $def['keys'] as $key_name => $definition ) {
                if ( in_array( $key_name, $keys, true ) ) continue;

                $wpdb->query( "ALTER TABLE `{$table}` ADD {$definition}" );
                if ( $wpdb->last_error ) {
                    $report['errors'][] = "补索引 {$name}.{$key_name} 失败：{$wpdb->last_error}";
                } else {
                    $report['keys'][] = "{$name}.{$key_name}";
                }
            }
        }

        // 4) 修正历史遗留的字段类型
        $report['widened'] = self::widen_columns();

        $wpdb->suppress_errors( $prev_suppress );

        return $report;
    }

    /**
     * 兼容旧调用点：建表 + 补字段（激活钩子、后台修复按钮都在用）。
     *
     * @return array 同步报告
     */
    public static function create_tables() {
        return self::sync_structure();
    }

    /**
     * 把“取值范围太小”的老字段放大。
     *
     * 背景：v1.0.0 的 wsa_orders/wsa_user_ads 里 slot_position 是 TINYINT（上限 255），
     * 而广告位“卖满一行补一整行”的规则会让位置序号持续增长，
     * 一旦超过 255，MySQL 会拒绝写入，下单又会变成一句「订单创建失败」。
     * 这里只做“由小改大”，不会丢数据。
     *
     * @return array 本次调整过的字段
     */
    private static function widen_columns() {
        global $wpdb;

        // 表名 => [ 字段名 => 应该是的完整定义 ]
        $targets = [
            'orders'   => [ 'slot_position' => '`slot_position` INT UNSIGNED NOT NULL DEFAULT 1' ],
            'user_ads' => [ 'slot_position' => '`slot_position` INT UNSIGNED NOT NULL DEFAULT 1' ],
        ];

        $fixed = [];

        foreach ( $targets as $name => $columns ) {
            $table = self::table( $name );
            if ( ! self::table_exists( $table ) ) continue;

            $types = self::existing_column_types( $table );
            foreach ( $columns as $column => $definition ) {
                if ( ! isset( $types[ $column ] ) ) continue;

                // 只关心“还是 TINYINT”的老表；已经是 INT/BIGINT 的一律不动
                if ( stripos( $types[ $column ], 'tinyint' ) === false ) continue;

                $wpdb->query( "ALTER TABLE `{$table}` MODIFY COLUMN {$definition}" );
                if ( ! $wpdb->last_error ) {
                    $fixed[] = "{$name}.{$column}（{$types[ $column ]} → int unsigned）";
                }
            }
        }

        return $fixed;
    }

    /**
     * 结构巡检 + 兜底升级。
     *
     * 插件被“覆盖升级”时不会触发激活钩子，表结构变化就会悄悄失效；
     * 所以每次版本号对不上、或者每天一次的例行巡检，都会走一遍结构同步。
     *
     * 另外还防了一个更隐蔽的情况：版本号对得上、但字段其实没补上
     * （例如上次升级时 ALTER 被数据库权限拦截了）。此时单看版本号是查不出来的，
     * 必须真的去比对字段，所以会定期巡检。
     */
    public static function maybe_upgrade() {
        $installed = (string) get_option( 'wsa_db_version' );
        $changed   = ( $installed !== (string) WSA_DB_VERSION );

        // 版本没变、且刚巡检过 → 什么都不用做，避免每个请求都去查库
        if ( ! $changed && get_transient( 'wsa_structure_checked' ) === '1' ) return;

        $report = self::sync_structure();
        self::seed_default_slots();
        self::migrate();

        if ( self::structure_is_ok() ) {
            update_option( 'wsa_db_version', WSA_DB_VERSION );
            // 结构完好 → 一天只巡检一次，几乎零成本
            set_transient( 'wsa_structure_checked', '1', DAY_IN_SECONDS );
        } else {
            // 结构仍有问题（例如数据库账号没有 ALTER 权限）→ 15 分钟后重试，
            // 同时保留后台的红色警告，不假装一切正常。
            set_transient( 'wsa_structure_checked', '1', 15 * MINUTE_IN_SECONDS );
        }

        if ( $report['created'] || $report['columns'] || $report['keys'] || ! empty( $report['widened'] ) ) {
            if ( class_exists( 'WSA_Payment' ) ) {
                WSA_Payment::log( '数据库结构已自动同步', $report );
            }
        }

        // 结构变化后一并刷新回调地址，确保支付回调地址可用
        if ( function_exists( 'wsa_register_rewrite_rules' ) ) {
            wsa_register_rewrite_rules();
        }
        flush_rewrite_rules();
    }

    /**
     * 老数据升级。
     *
     * 三条原则：
     *   1) 不依赖版本号，而是靠“是否真的还有老数据”自行判断，因此跑第二遍不会做任何事；
     *      即使版本号曾经被错误地写成最新，也能正确补上。
     *   2) 每一步都各自检查自己需要的字段是否存在 —— 不能因为前一步的字段缺失就 return，
     *      否则后面的回填会被一起跳过（这是 v1.2.2 及以前踩过的坑）。
     *   3) 只做“填补空白”，绝不覆盖用户已经有的值。
     */
    private static function migrate() {
        global $wpdb;

        $orders = self::table( 'orders' );
        $ads    = self::table( 'user_ads' );

        // ---- 1) 订单表：把「付款方式」和「支付通道」拆成两个字段 ----
        // 旧版只有一个 payment_method，值可能是 alipay 或 epay：
        //   - payment_method = 'alipay' → 走的是支付宝官方
        //   - payment_method = 'epay'   → 走的是易支付，且当年写死用支付宝付款
        // 所以先把原值原样拷贝到 payment_channel 作为通道，再把 epay 那批的付款方式改回 alipay。
        if ( in_array( 'payment_channel', self::existing_columns( $orders ), true ) ) {
            $need = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM `{$orders}` WHERE payment_channel IS NULL OR payment_channel = ''"
            );
            if ( $need ) {
                $wpdb->query(
                    "UPDATE `{$orders}`
                     SET payment_channel = payment_method
                     WHERE payment_channel IS NULL OR payment_channel = ''"
                );
                $wpdb->query(
                    "UPDATE `{$orders}` SET payment_method = 'alipay' WHERE payment_method = 'epay'"
                );
            }
        }

        // ---- 2) 广告表：source 回填 ----
        // v1.3.0 新增了这个字段，用来区分「站长手动添加」和「用户购买」。
        // 升级前存在的广告全部是用户付费买的，所以统一补成 'user'。
        if ( in_array( 'source', self::existing_columns( $ads ), true ) ) {
            $wpdb->query( "UPDATE `{$ads}` SET source = 'user' WHERE source IS NULL OR source = ''" );
        }

        // ---- 3) 广告表：duration 回填 ----
        // 投放天数是 v1.3.0 新增的，老广告没有。它只用于“过期后重新上架时自动续期多少天”，
        // 所以从对应订单里取一次即可（订单表本来就有 duration）。
        // 只更新还是 0 的行，跑第二遍不会重复做任何事；order_id = 0 的是站长广告，跳过。
        if ( in_array( 'duration', self::existing_columns( $ads ), true )
            && in_array( 'duration', self::existing_columns( $orders ), true ) ) {
            $wpdb->query(
                "UPDATE `{$ads}` a
                 JOIN `{$orders}` o ON a.order_id = o.id
                 SET a.duration = o.duration
                 WHERE a.duration = 0 AND a.order_id > 0"
            );
        }
    }

    /** 写入 5 个默认广告位 */
    public static function seed_default_slots() {
        global $wpdb;
        $table = self::table( 'ad_slots' );

        // 表必须存在，否则下面的 insert 只会白白报错
        if ( ! self::table_exists( $table ) ) return;

        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM `{$table}`" );
        if ( $count > 0 ) return;

        // 字段顺序：key、名称、类型、每行容量(max_items)、月单价、可购买天数
        $defaults = [
            [ 'banner_large', '大横幅广告',   'image', 1, 10.00, [ 7, 30, 90 ] ],
            [ 'banner_small', '小横幅广告',   'image', 2, 10.00, [ 7, 30, 90 ] ],
            [ 'banner_mini',  '迷你横幅广告', 'image', 3, 10.00, [ 7, 30, 90 ] ],
            [ 'banner_block', '方块横幅广告', 'image', 6, 10.00, [ 7, 30, 90 ] ],
            [ 'text_ad',      '文字广告位',   'text',  4, 10.00, [ 7, 30, 90 ] ],
        ];

        foreach ( $defaults as $i => $s ) {
            $wpdb->insert( $table, [
                'slot_key'         => $s[0],
                'slot_name'        => $s[1],
                'slot_type'        => $s[2],
                'is_enabled'       => 1,
                'price'            => $s[4],
                'duration_options' => wp_json_encode( $s[5] ),
                'max_items'        => $s[3],
                'sort_order'       => $i,
            ], [ '%s', '%s', '%s', '%d', '%f', '%s', '%d', '%d' ] );
        }
    }

    /** 获取表名 */
    public static function table( $name ) {
        global $wpdb;
        return $wpdb->prefix . 'wsa_' . $name;
    }

    /* ==================================================================
     * 三、结构查询：给自检与后台展示用
     * ================================================================== */

    /** 表是否存在 */
    public static function table_exists( $table ) {
        global $wpdb;
        $suppress = $wpdb->suppress_errors( true );
        $found    = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
        $wpdb->suppress_errors( $suppress );
        return ! empty( $found );
    }

    /** 某个表当前真实存在的字段名 */
    public static function existing_columns( $table ) {
        global $wpdb;
        $suppress = $wpdb->suppress_errors( true );
        $rows     = $wpdb->get_results( "DESCRIBE `{$table}`" );
        $wpdb->suppress_errors( $suppress );

        $out = [];
        foreach ( (array) $rows as $row ) {
            if ( isset( $row->Field ) ) $out[] = (string) $row->Field;
        }
        return $out;
    }

    /** 某个表当前真实存在的字段及类型：字段名 => 类型 */
    public static function existing_column_types( $table ) {
        global $wpdb;
        $suppress = $wpdb->suppress_errors( true );
        $rows     = $wpdb->get_results( "DESCRIBE `{$table}`" );
        $wpdb->suppress_errors( $suppress );

        $out = [];
        foreach ( (array) $rows as $row ) {
            if ( isset( $row->Field, $row->Type ) ) {
                $out[ (string) $row->Field ] = (string) $row->Type;
            }
        }
        return $out;
    }

    /** 某个表当前真实存在的索引名 */
    public static function existing_keys( $table ) {
        global $wpdb;
        $suppress = $wpdb->suppress_errors( true );
        $rows     = $wpdb->get_results( "SHOW INDEX FROM `{$table}`" );
        $wpdb->suppress_errors( $suppress );

        $out = [];
        foreach ( (array) $rows as $row ) {
            if ( isset( $row->Key_name ) ) $out[] = (string) $row->Key_name;
        }
        return array_values( array_unique( $out ) );
    }

    /**
     * 数据库结构自检：逐表比对“代码需要的字段”与“数据库里真实存在的字段”。
     *
     * 为什么需要它：插件是覆盖升级的，如果某次升级时补字段没成功，
     * 就会表现为“功能莫名其妙全部失败”（比如下单直接报错），
     * 而错误信息里完全看不出是数据库少了列。这里把这种情况一次性查出来。
     *
     * @return array 表名 => [ 'table'=>bool 表是否存在, 'missing'=>array 缺少的字段 ]
     */
    public static function column_check() {
        $report = [];

        foreach ( self::schema() as $name => $def ) {
            $table = self::table( $name );

            if ( ! self::table_exists( $table ) ) {
                $report[ $name ] = [ 'table' => false, 'missing' => array_keys( $def['columns'] ) ];
                continue;
            }

            $report[ $name ] = [
                'table'   => true,
                'missing' => array_values( array_diff( array_keys( $def['columns'] ), self::existing_columns( $table ) ) ),
            ];
        }

        return $report;
    }

    /** 结构自检是否全部通过（后台用来决定要不要报警） */
    public static function structure_is_ok() {
        foreach ( self::column_check() as $row ) {
            if ( ! $row['table'] || $row['missing'] ) return false;
        }
        return true;
    }

    /**
     * 生成一份“纯 SQL”版的修复语句。
     *
     * 用途：万一插件自己补不了（例如数据库账号没有 ALTER 权限），
     * 站长可以把这几句复制到 phpMyAdmin / 宝塔面板的 SQL 窗口里手工执行。
     *
     * @return array SQL 语句列表（缺什么才生成什么，结构完好时返回空数组）
     */
    public static function repair_sql() {
        $schema = self::schema();
        $lines  = [];

        foreach ( self::column_check() as $name => $row ) {
            if ( ! isset( $schema[ $name ] ) ) continue;

            if ( ! $row['table'] ) {
                $lines[] = $schema[ $name ]['create'];
                continue;
            }

            foreach ( $row['missing'] as $column ) {
                if ( empty( $schema[ $name ]['columns'][ $column ] ) ) continue;
                $lines[] = 'ALTER TABLE `' . self::table( $name ) . '` ADD COLUMN '
                    . str_ireplace( ' AUTO_INCREMENT', '', $schema[ $name ]['columns'][ $column ] ) . ';';
            }
        }

        return $lines;
    }
}
