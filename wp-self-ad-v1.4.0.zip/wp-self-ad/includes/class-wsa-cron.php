<?php
/**
 * 定时任务：广告到期自动下线
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

class WSA_Cron {

    /** 每小时执行：过期广告下线 + 超时未支付订单关闭 */
    public static function check_expired() {
        global $wpdb;

        $now = WSA_DB::now();

        // 1) 到期的广告自动下线
        $expired_ads = (int) $wpdb->query( $wpdb->prepare(
            "UPDATE " . WSA_DB::table( 'user_ads' ) . "
             SET status = 'expired'
             WHERE status = 'active' AND expires_at <= %s",
            $now
        ) );

        // 2) 到期的订单置为已过期
        $expired_orders = (int) $wpdb->query( $wpdb->prepare(
            "UPDATE " . WSA_DB::table( 'orders' ) . "
             SET status = 'expired'
             WHERE status = 'paid' AND expires_at <= %s",
            $now
        ) );

        // 3) 下单后长时间没付款的订单自动关闭，把位置释放出来给别人买
        $closed_orders = (int) $wpdb->query( $wpdb->prepare(
            "UPDATE " . WSA_DB::table( 'orders' ) . "
             SET status = 'closed'
             WHERE status = 'pending' AND created_at <= %s",
            WSA_DB::time_offset( - WSA_Orders::PENDING_TTL )
        ) );

        // 4) 记录一次执行结果，方便日后排查“广告为什么没下线”
        WSA_Payment::log( 'cron 到期检查完成', [
            'expired_ads'    => $expired_ads,
            'expired_orders' => $expired_orders,
            'closed_orders'  => $closed_orders,
        ] );
    }
}
