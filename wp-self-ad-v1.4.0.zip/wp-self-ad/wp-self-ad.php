<?php
/**
 * Plugin Name: WP Self Ad - 自助广告系统
 * Plugin URI:  https://jetmast.com
 * Description: 适配子比主题的自助广告位插件。支持多种付款方式（支付宝、微信等），可按优先级自动路由到支付宝官方 / 易支付等支付通道；用户可自助购买广告位，站长也可在后台自定义广告内容并手动上架 / 下架。
 * Version: 1.4.0
 * Author: 墨桅（JetMast）
 * Author URI: https://jetmast.com
 * Requires PHP: 7.4
 * License: GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * ============================ 版权信息 ============================
 * 中文笔名：墨桅            英文名：JetMast
 * QQ：910049360             微信：JetMast
 * 邮箱：Email@5so.cc        博客主页：https://jetmast.com
 *
 * 注：上面几行是给「看代码的人」看的；插件后台显示的那一份在
 * WSA_About 类里（后台菜单「自助广告 → 关于插件」可直接查看），
 * 改联系方式时两处都要改。
 * ==================================================================
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'ABSPATH' ) ) exit;

define( 'WSA_VERSION', '1.3.9' );
// 数据结构版本号：只要“表结构”有改动就 +1，插件会据此自动补表 / 升级数据 / 刷新回调地址
define( 'WSA_DB_VERSION', '5' );
define( 'WSA_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WSA_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WSA_PLUGIN_FILE', __FILE__ );

// 自动加载
spl_autoload_register( function ( $class ) {
    if ( strpos( $class, 'WSA_' ) !== 0 ) return;
    $name = strtolower( str_replace( '_', '-', $class ) );
    // 优先在 includes/ 查找
    $file = WSA_PLUGIN_DIR . 'includes/class-' . $name . '.php';
    if ( file_exists( $file ) ) { require_once $file; return; }
    // 后台管理类位于 admin/ 目录
    $file = WSA_PLUGIN_DIR . 'admin/class-' . $name . '.php';
    if ( file_exists( $file ) ) require_once $file;
});

/**
 * 注册支付回调地址的 rewrite 规则。
 * 单独抽成函数，是因为「初始化」和「插件激活」两个时机都需要先注册、再刷新。
 *
 * 地址里的通道名不写死，走的是「支付通道注册表」里的键，
 * 将来新增通道（如微信官方）无需改动这里。
 */
function wsa_register_rewrite_rules() {
    add_rewrite_rule( '^wsa-notify/([a-z0-9_\-]+)/?$', 'index.php?wsa_notify=$matches[1]', 'top' );
    add_rewrite_rule( '^wsa-return/([a-z0-9_\-]+)/?$', 'index.php?wsa_return=$matches[1]', 'top' );
}

// 激活：建表 + 写入默认广告位 + 定时任务 + 刷新回调地址
register_activation_hook( __FILE__, function () {
    $report = WSA_DB::sync_structure();
    WSA_DB::seed_default_slots();

    // 只有结构真的补齐了才把版本号写进去。
    // 如果这里因为数据库权限等原因没补成，就不要假装成功 —— 否则以后每次巡检
    // 都会认为“版本号一致、无需处理”，问题永远修不掉。
    if ( WSA_DB::structure_is_ok() ) {
        update_option( 'wsa_db_version', WSA_DB_VERSION );
    }

    WSA_Payment::log( '插件已激活，数据库结构同步完成', $report );

    if ( ! wp_next_scheduled( 'wsa_expire_check' ) ) {
        wp_schedule_event( time(), 'hourly', 'wsa_expire_check' );
    }

    // 关键：先把规则注册进来再刷新，否则 /wsa-notify/alipay 会一直 404，支付永远回调不进来
    wsa_register_rewrite_rules();
    flush_rewrite_rules();
});

// 停用：清掉定时任务，并把刚才注册的规则一并清理掉
register_deactivation_hook( __FILE__, function () {
    wp_clear_scheduled_hook( 'wsa_expire_check' );
    flush_rewrite_rules();
});

// 初始化
add_action( 'init', function () {
    wsa_register_rewrite_rules();
    // 插件覆盖升级时不会触发激活钩子，所以这里做一次兜底检查：结构版本不一致就自动补表 + 刷新规则
    WSA_DB::maybe_upgrade();
});

add_filter( 'query_vars', function ( $vars ) {
    $vars[] = 'wsa_notify';
    $vars[] = 'wsa_return';
    return $vars;
});

add_action( 'template_redirect', function () {
    $type = get_query_var( 'wsa_notify' );
    if ( $type ) { WSA_Payment::handle_notify( $type ); exit; }
    $type = get_query_var( 'wsa_return' );
    if ( $type ) { WSA_Payment::handle_return( $type ); exit; }
});

// 业务模块挂载
add_action( 'plugins_loaded', function () {
    WSA_Ad_Slots::init();
    WSA_Ajax::init();
    if ( is_admin() ) {
        WSA_Admin::init();
        // 后台页脚署名（只在本插件自己的页面上显示，具体判断在 WSA_About::is_plugin_screen()）
        WSA_About::init();
    }
});

// 前端资源
add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style( 'wsa-frontend', WSA_PLUGIN_URL . 'assets/css/wsa-frontend.css', [], WSA_VERSION );
    wp_enqueue_script( 'wsa-frontend', WSA_PLUGIN_URL . 'assets/js/wsa-frontend.js', [ 'jquery' ], WSA_VERSION, true );

    $permalink = get_permalink();
    wp_localize_script( 'wsa-frontend', 'wsaData', [
        'ajaxUrl'    => admin_url( 'admin-ajax.php' ),
        'nonce'      => wp_create_nonce( 'wsa_frontend_nonce' ),
        'isLogged'   => is_user_logged_in() ? 1 : 0,
        'loginUrl'   => wp_login_url( $permalink ? $permalink : home_url() ),
        // 只把「已启用且已配置好」的支付方式发给前端，避免用户选了却报「未配置」
        'payMethods' => WSA_Payment::available_methods(),
    ]);
});

// 定时任务
add_action( 'wsa_expire_check', [ 'WSA_Cron', 'check_expired' ] );
