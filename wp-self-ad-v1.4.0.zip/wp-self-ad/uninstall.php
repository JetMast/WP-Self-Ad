<?php
/**
 * 卸载：删除数据表与插件配置
 *
 * @author    墨桅 (JetMast) <Email@5so.cc>
 * @copyright 2026 墨桅 (JetMast)
 * @link      https://jetmast.com
 */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) exit;

/**
 * 清理单个站点的数据。
 * 抽成函数是因为多站点环境下需要对每个子站点各执行一次。
 */
function wsa_uninstall_site() {
    global $wpdb;

    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wsa_user_ads" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wsa_orders" );
    $wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}wsa_ad_slots" );

    delete_option( 'wsa_alipay_config' );
    delete_option( 'wsa_epay_config' );
    delete_option( 'wsa_db_version' );

    wp_clear_scheduled_hook( 'wsa_expire_check' );
}

if ( is_multisite() ) {
    // 多站点：每个子站点都有自己的数据表和选项，必须逐个清理，否则会留下无主数据
    $site_ids = get_sites( [ 'fields' => 'ids', 'number' => 0 ] );
    foreach ( $site_ids as $site_id ) {
        switch_to_blog( $site_id );
        wsa_uninstall_site();
        restore_current_blog();
    }
} else {
    wsa_uninstall_site();
}
