/**
 * 自助广告系统 - 后台「广告管理」页的交互
 *
 * 只做三件小事：
 *   1) 点「从媒体库选择」调用 WordPress 自带的图片选择器
 *   2) 切换「图片广告 / 文字广告」时，只显示对应的输入框
 *   3) 删除这类危险按钮，先让站长确认一次
 */
(function ($) {
    'use strict';

    $(function () {

        /* ---------- 1) 媒体库选图 ---------- */
        var frame = null;

        $(document).on('click', '.wsa-pick-image', function (e) {
            e.preventDefault();

            // 媒体库由 WordPress 提供，正常情况下一定存在；万一没有就提示一下，别静默失败
            if (!window.wp || !wp.media) {
                window.alert('媒体库没有加载成功，请把图片地址直接粘贴到输入框里。');
                return;
            }

            var text = window.wsaAdmin || {};

            if (frame) {
                frame.open();
                return;
            }

            frame = wp.media({
                title: text.pickTitle || '选择图片',
                button: { text: text.pickButton || '使用这张图片' },
                multiple: false
            });
            frame.on('select', function () {
                var attachment = frame.state().get('selection').first().toJSON();
                if (!attachment || !attachment.url) return;

                $('.wsa-image-url').val(attachment.url);

                // 用 DOM API 构造 img 并只设置 src，天然不会被注入
                var $img = $('<img alt="">').attr('src', attachment.url)
                    .css({ maxWidth: '200px', height: 'auto', marginTop: '6px', border: '1px solid #ddd', borderRadius: '4px' });
                $('.wsa-image-preview').empty().append($img);
            });

            frame.open();
        });

        /* ---------- 2) 广告类型切换 ---------- */
        function syncType() {
            var type = $('.wsa-ad-type').val();
            $('.wsa-row-image').toggle(type !== 'text');
            $('.wsa-row-text').toggle(type === 'text');
        }

        $('.wsa-ad-type').on('change', syncType);
        syncType();

        /* ---------- 3) 危险操作二次确认 ---------- */
        $(document).on('click', '.wsa-confirm', function () {
            var message = $(this).data('confirm') || '确定要执行这个操作吗？';
            // 返回 false 会阻止跳转
            return window.confirm(message);
        });
    });
})(jQuery);
