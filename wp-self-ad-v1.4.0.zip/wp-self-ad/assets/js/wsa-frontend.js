(function($) {
    'use strict';

    // 转义 HTML 特殊字符，防止把用户输入直接拼进 HTML 时被注入
    function escAttr(str) {
        return String(str == null ? '' : str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }

    // 后端返回的错误可能是字符串，也可能是 {code, message} 对象
    function errText(data) {
        if (!data) return '操作失败，请重试';
        if (typeof data === 'string') return data;
        return data.message || '操作失败，请重试';
    }

    // 点击空广告位 → 打开购买弹窗
    $(document).on('click', '.wsa-empty-item', function() {
        if (!wsaData.isLogged) {
            window.location.href = wsaData.loginUrl;
            return;
        }

        // 没有可用的支付方式时直接提示，避免用户填完资料才报错
        if (!wsaData.payMethods || $.isEmptyObject(wsaData.payMethods)) {
            alert('站长尚未配置可用的支付方式，暂时无法购买。');
            return;
        }

        var $slot = $(this).closest('.wsa-slot');
        var slotId = $slot.data('slot-id');
        var position = $(this).data('position');
        var $item = $(this);

        $item.css('opacity', '0.6');
        $.post(wsaData.ajaxUrl, {
            action: 'wsa_get_slot',
            nonce: wsaData.nonce,
            slot_id: slotId
        }).done(function(res) {
            if (!res || !res.success) {
                alert(errText(res && res.data));
                return;
            }
            openModal(res.data, position);
        }).fail(function() {
            alert('获取广告位信息失败，请检查网络后重试');
        }).always(function() {
            $item.css('opacity', '');
        });
    });

    function openModal(slot, position) {
        // 先移除旧弹窗，避免重复点击叠加出多个
        $('.wsa-modal-overlay').remove();

        var isText = slot.type === 'text';
        var opts = slot.options || [];

        if (!opts.length) {
            alert('该广告位暂时没有可选的投放时长，请联系站长。');
            return;
        }

        var html = '<div class="wsa-modal-overlay"><div class="wsa-modal">';
        html += '<h3>购买「' + escAttr(slot.name) + '」- 位置 ' + escAttr(position) + '</h3>';
        html += '<input type="hidden" id="wsa-slot-id" value="' + escAttr(slot.id) + '">';
        html += '<input type="hidden" id="wsa-position" value="' + escAttr(position) + '">';

        // 投放时长：平铺成可点选的卡片，点一下即选中
        // 价格由服务端算好并随选项一起返回，前端只负责显示，不参与计算
        html += '<div class="wsa-form-group"><label>投放时长</label>';
        html += '<div class="wsa-durations" id="wsa-duration-list" role="radiogroup" aria-label="投放时长">';
        // 默认选中第一个（与原来下拉框的默认项一致）。
        // 同样用一个独立的"是否第一项"开关来判断，不能用选择器去数已拼出来的卡片 ——
        // 此时这段 HTML 还没 append 到页面里，选择器恒为空、会导致每一张都被当成第一张。
        var isFirstDuration = true;
        $.each(opts, function(i, o) {
            var checked = isFirstDuration;
            isFirstDuration = false;

            html += '<button type="button" class="wsa-duration' + (checked ? ' checked' : '') + '" '
                 +  'data-value="' + escAttr(o.days) + '" role="radio" aria-checked="' + (checked ? 'true' : 'false') + '">'
                 +  '<span class="wsa-duration-days">' + escAttr(o.days) + ' 天</span>'
                 +  '<span class="wsa-duration-price">¥' + escAttr(o.price) + '</span>'
                 +  '<span class="wsa-duration-check" aria-hidden="true"></span>'
                 +  '</button>';
        });
        html += '</div></div>';

        // 广告内容
        if (isText) {
            html += '<div class="wsa-form-group"><label>文字内容</label>';
            html += '<input type="text" id="wsa-text" maxlength="50" placeholder="请输入广告文字"></div>';
        } else {
            html += '<div class="wsa-form-group"><label>图片链接</label>';
            html += '<input type="url" id="wsa-image" placeholder="https://example.com/ad.jpg">';
            html += '</div>';
        }
        html += '<div class="wsa-form-group"><label>跳转链接</label>';
        html += '<input type="url" id="wsa-link" placeholder="https://example.com">';
        html += '</div>';

        // 预览
        html += '<div class="wsa-preview" id="wsa-preview">预览区域</div>';

        // 支付方式：平铺成可点选的卡片，点一下即选中
        // 这里仍然只列出后台已启用的付款方式，选项来源与原来的下拉框完全一致
        html += '<div class="wsa-form-group"><label>支付方式</label>';
        html += '<div class="wsa-pay-methods" id="wsa-payment-list" role="radiogroup" aria-label="支付方式">';
        // 默认选中第一个（与原来下拉框的默认项一致），选中态直接用 checked 属性标在卡片上，
        // 提交时从 .checked 的卡片上取值，不依赖点击事件，避免"没点过就拿不到值"
        //
        // 注意：这里必须用一个独立的"是否第一项"开关来判断，不能用
        //   $('#wsa-payment-list').find('.wsa-pay-method').length
        // 去数已经拼出来的卡片 —— 此时整段 HTML 还只是一堆字符串，
        // 并没有插入到页面里（要到下面 $('body').append(html) 才进 DOM），
        // 所以那种写法每次查到的都是空的，length 永远是 0，
        // "是不是第一张"就永远成立，结果每张卡片都被加上 checked（整组全部选中）。
        var isFirstPayMethod = true;
        $.each(wsaData.payMethods, function(value, label) {
            var checked = isFirstPayMethod;
            isFirstPayMethod = false;

            html += '<button type="button" class="wsa-pay-method' + (checked ? ' checked' : '') + '" '
                 +  'data-value="' + escAttr(value) + '" role="radio" aria-checked="' + (checked ? 'true' : 'false') + '">'
                 +  '<span class="wsa-pay-method-name">' + escAttr(label) + '</span>'
                 +  '<span class="wsa-pay-method-check" aria-hidden="true"></span>'
                 +  '</button>';
        });
        html += '</div></div>';

        html += '<button class="wsa-btn" id="wsa-submit">确认支付</button>';
        html += '<button class="wsa-btn wsa-btn-close" id="wsa-close">取消</button>';
        html += '</div></div>';

        $('body').append(html);

        // 实时预览
        $('#wsa-image, #wsa-text').on('input', function() {
            var img = $('#wsa-image').val();
            var txt = $('#wsa-text').val();
            var $preview = $('#wsa-preview');
            $preview.empty();
            if (img) {
                // 用 DOM API 设置属性，天然不会被注入
                var $im = $('<img alt="预览">').attr('src', img);
                $im.on('error', function() { $(this).hide(); });
                $preview.append($im);
            } else if (txt) {
                $preview.text(txt);
            } else {
                $preview.text('预览区域');
            }
        });

        // 点选投放时长：同一组里只允许一个处于选中态
        $('#wsa-duration-list').on('click', '.wsa-duration', function() {
            var $list = $('#wsa-duration-list');
            $list.find('.wsa-duration')
                .removeClass('checked')
                .attr('aria-checked', 'false');
            $(this).addClass('checked').attr('aria-checked', 'true');
        });

        // 点选支付方式：同一组里只允许一个处于选中态
        $('#wsa-payment-list').on('click', '.wsa-pay-method', function() {
            var $list = $('#wsa-payment-list');
            $list.find('.wsa-pay-method')
                .removeClass('checked')
                .attr('aria-checked', 'false');
            $(this).addClass('checked').attr('aria-checked', 'true');
        });

        // 关闭
        var close = function() { $('.wsa-modal-overlay').remove(); };
        $('#wsa-close').on('click', close);
        $('.wsa-modal-overlay').on('click', function(e) {
            if (e.target === this) close();
        });

        // 提交
        $('#wsa-submit').on('click', function() {
            var imageUrl = $('#wsa-image').val() || '';
            var textContent = ($('#wsa-text').val() || '').trim();
            var linkUrl = $('#wsa-link').val() || '';
            // 从选中的卡片上取投放天数（原来是从下拉框取，取到的值完全一样）
            var duration = $('#wsa-duration-list .wsa-duration.checked').data('value');
            // 从选中的卡片上取付款方式（原来是从下拉框取，取到的值完全一样）
            var payment = $('#wsa-payment-list .wsa-pay-method.checked').data('value');

            // 提交前先在本地做一次基础校验，省去一次无意义的请求
            if (!duration) { alert('请选择投放时长'); return; }
            if (!payment) { alert('请选择支付方式'); return; }
            if (isText && !textContent) { alert('请填写广告文字内容'); return; }
            if (!isText && !imageUrl) { alert('请填写图片链接'); return; }
            if (!linkUrl) { alert('请填写点击后要跳转的链接'); return; }

            var $btn = $(this).prop('disabled', true).text('处理中...');
            var restore = function() { $btn.prop('disabled', false).text('确认支付'); };

            $.post(wsaData.ajaxUrl, {
                action: 'wsa_create_order',
                nonce: wsaData.nonce,
                slot_id: $('#wsa-slot-id').val(),
                slot_position: $('#wsa-position').val(),
                duration: duration,
                payment: payment,
                image_url: imageUrl,
                text_content: textContent,
                link_url: linkUrl
            }).done(function(res) {
                if (res && res.success && res.data && res.data.redirect) {
                    window.location.href = res.data.redirect;
                    return;
                }
                alert(errText(res && res.data));
                restore();
            }).fail(function() {
                alert('请求失败，请重试');
                restore();
            });
        });
    }
})(jQuery);
